DamageLifeProfiles = DamageLifeProfiles or {}
local Profiles = DamageLifeProfiles

local excluded = {
    stats = true, totalSaves = true, bestStreak = true,
    bgSaveCount = true, bgSessionId = true,
}

local function encode(value)
    return (tostring(value):gsub("([^%w%-%_%.])", function(character)
        return string.format("%%%02X", string.byte(character))
    end))
end

local function decode(value)
    return (tostring(value or ""):gsub("%%(%x%x)", function(hex)
        return string.char(tonumber(hex, 16))
    end))
end

local function encodeKey(key)
    if type(key) == "number" then return "#" .. tostring(key) end
    return "$" .. encode(key)
end

local function decodeKey(key)
    if string.sub(key, 1, 1) == "#" then return tonumber(string.sub(key, 2)) end
    if string.sub(key, 1, 1) == "$" then return decode(string.sub(key, 2)) end
    return decode(key)
end

local function collect(source, path, output, depth)
    if depth > 8 then return end
    local keys = {}
    for key in pairs(source) do
        if depth > 0 or not excluded[key] then keys[#keys + 1] = key end
    end
    table.sort(keys, function(a, b) return tostring(a) < tostring(b) end)
    for _, key in ipairs(keys) do
        local value = source[key]
        local kind = type(value)
        local childPath = path == "" and encodeKey(key) or path .. "/" .. encodeKey(key)
        if kind == "table" then
            collect(value, childPath, output, depth + 1)
        elseif kind == "boolean" then
            output[#output + 1] = childPath .. "=b:" .. (value and "1" or "0")
        elseif kind == "number" then
            output[#output + 1] = childPath .. "=n:" .. tostring(value)
        elseif kind == "string" then
            output[#output + 1] = childPath .. "=s:" .. encode(value)
        end
    end
end

function Profiles:Export()
    local output = { "LS1" }
    collect(DamageLifeDB or {}, "", output, 0)
    return table.concat(output, "|")
end

local function setPath(target, path, value)
    local parts = {}
    for part in string.gmatch(path, "[^/]+") do parts[#parts + 1] = decodeKey(part) end
    if #parts == 0 or excluded[parts[1]] then return end
    local current = target
    for index = 1, #parts - 1 do
        local key = parts[index]
        if type(current[key]) ~= "table" then current[key] = {} end
        current = current[key]
    end
    current[parts[#parts]] = value
end

function Profiles:Import(text)
    text = tostring(text or ""):gsub("%s+", "")
    if string.sub(text, 1, 4) ~= "LS1|" and text ~= "LS1" then return false, "Неверный код профиля." end
    local imported = 0
    for item in string.gmatch(string.sub(text, 5), "[^|]+") do
        local path, kind, raw = string.match(item, "^([^=]+)=([bns]):(.*)$")
        if path then
            local value
            if kind == "b" then value = raw == "1"
            elseif kind == "n" then value = tonumber(raw)
            else value = decode(raw) end
            if value ~= nil then setPath(DamageLifeDB, path, value); imported = imported + 1 end
        end
    end
    if imported == 0 then return false, "Профиль не содержит настроек." end
    return true, "Импортировано настроек: " .. imported .. ". Выполните /reload."
end
