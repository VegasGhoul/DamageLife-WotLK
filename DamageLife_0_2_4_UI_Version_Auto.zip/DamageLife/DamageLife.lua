local ADDON = "DamageLife"
DamageLife = DamageLife or {}
-- SavedVariables are nil on a first installation until the addon creates the
-- table. Settings.lua is loaded before ADDON_LOADED, so initialise the shell
-- early and let deepDefaults fill it when loading completes.
DamageLifeDB = DamageLifeDB or {}
local LS = DamageLife
local frame = CreateFrame("Frame")

local defaultPhrases = {
    "давит на {target} с помощью {spell}!",
    "начинает бурст по {target}: {spell}!",
    "атакует {target} — {spell}!",
    "усиливает давление на {target}: {spell}!",
    "{target} под угрозой — {spell}!",
    "добивает {target} с помощью {spell}!",
}

local defaultStreakNames = {
    "DAMAGE DEALT!", "DOUBLE HIT!", "TRIPLE HIT!", "DAMAGE SPREE!",
    "CRITICAL HIT!", "BURST ATTACK!", "MASSIVE DAMAGE!", "UNSTOPPABLE DPS!",
    "PRESSURE!", "LEGENDARY STRIKE!", "DAMAGE x11!", "DAMAGE x12!",
    "DAMAGE x13!", "DAMAGE x14!", "IMMORTAL DPS!",
}

local defaults = {
    enabled = true, debug = false,
    lowPercent = 5, safePercent = 50, rescueWindow = 12,
    countMode = "STRICT", contributionPercent = 60,
    includeSelf = false, includePets = false, pvpOnly = false,
    allowWorld = true, allowBattlegrounds = true, allowArenas = true,
    allowDungeons = true, allowRaids = true,
    streakWindow = 20, resetStreakOnDeath = true, resetStreakOutOfCombat = false,
    emoteEnabled = true, localChatEnabled = false, screenEnabled = true,
    combatSoundEnabled = { CRITICAL = true, BURST = true, EXECUTE = true, CONTROL = true },
    targetNotifications = { enabled = true, vulnerable = true, lastDefense = true, defenseRegained = true, execute = true, priority = true, lowHP = false, chat = false, sound = true, executePercent = 20, cooldown = 2 },
    groupEmotesOnly = true, emoteCooldown = 3, targetCooldown = 10,
    widgetScale = 0.6, widgetLocked = true, widgetPoint = "TOP", widgetRelativePoint = "TOP", widgetX = 0, widgetY = -276,
    widgetR = 1, widgetG = 0.65, widgetB = 0.08, widgetDesignVersion = 3,
    selectedClassTab = "PRIEST", selectedAbilityTabs = {}, selectedControlTab = "SAP", language = "ruRU", fontKey = "FRITZ",
    controlAlertsEnabled = true, controlSapEnabled = true, controlHammerOfJusticeEnabled = true,
    controlCycloneEnabled = true, controlFearEnabled = true, controlPsychicScreamEnabled = true,
    controlCounterspellSilenceEnabled = true, controlSilenceEnabled = true, controlStrangulateEnabled = true,
    controlPsychicHorrorEnabled = true, controlRepentanceEnabled = true, controlSeductionEnabled = true,
    controlSpellLockEnabled = true, controlPolymorphEnabled = true, controlHexEnabled = true, controlBlindEnabled = true, controlAlertChannel = "SAY",
    controlAlerts = { enabled = true, channel = "SAY", effects = {
        SAP = true, HAMMER_OF_JUSTICE = true, CYCLONE = true, FEAR = true,
        PSYCHIC_SCREAM = true, COUNTERSPELL_SILENCE = true, SILENCE = true, STRANGULATE = true,
        PSYCHIC_HORROR = true, REPENTANCE = true, SEDUCTION = true, SPELL_LOCK = true,
        POLYMORPH = true, HEX = true, BLIND = true,
    }, channels = {}, interrupt = {
        enabled = true, message = "Мне сбили {spell} с помощью {interrupt}!", say = true, group = false,
    } },
    priestBuffsEnabled = true, paladinBuffsEnabled = true,
    druidBuffsEnabled = true, shamanBuffsEnabled = true,
    warriorDpsEnabled = true, paladinDpsEnabled = true, hunterDpsEnabled = true, rogueDpsEnabled = true,
    priestDpsEnabled = true, shamanDpsEnabled = true, mageDpsEnabled = true, warlockDpsEnabled = true,
    druidDpsEnabled = true, deathKnightDpsEnabled = true,
    painSuppressionEnabled = true, guardianSpiritEnabled = true,
    powerInfusionEnabled = true, fearWardEnabled = true, levitateEnabled = true, hymnOfHopeEnabled = true, divineHymnEnabled = true,
    priestBuffChatEnabled = true,
    priestBuffWhisperEnabled = true,
    priestBuffPhrases = {}, priestBuffPhraseEnabled = {},
    layOnHandsEnabled = true, beaconOfLightEnabled = true, handOfProtectionEnabled = true,
    divineInterventionEnabled = true, handOfFreedomEnabled = true, handOfSacrificeEnabled = true,
    paladinBuffChatEnabled = true, paladinBuffWhisperEnabled = true,
    paladinBuffPhrases = {}, paladinBuffPhraseEnabled = {},
    innervateEnabled = true, tranquilityEnabled = true, rebirthEnabled = true,
    druidBuffChatEnabled = true, druidBuffWhisperEnabled = true,
    earthShieldEnabled = true, bloodlustEnabled = true, manaTideEnabled = true,
    shamanBuffChatEnabled = true, shamanBuffWhisperEnabled = true,
    abilitySettings = {},
    voiceRescueEnabled = true, voiceHymnOfHopeEnabled = true,
    voiceDivineHymnEnabled = true, voiceAllyDeathEnabled = true,
    bgSaveCount = 0, bgSessionId = "",
    phrases = {}, phraseEnabled = {}, streakNames = {},
    stats = { totalDamageEvents = 0, abilityCasts = 0, criticalHits = 0, categoryEvents = { CRITICAL = 0, BURST = 0, EXECUTE = 0, CONTROL = 0 }, byTarget = {}, bySpell = {} }, totalSaves = 0, bestStreak = 0,
    combatCategories = { critical = true, burst = true, execute = true, control = true },
    targetAnalysisEnabled = true, targetWindowCount = 1, targetWindowScale = 0.90, targetWindowLocked = false,
    targetWindowPoint = "CENTER", targetWindowRelativePoint = "CENTER", targetWindowX = 0, targetWindowY = -120,
    targetWindowPositions = {},
}

local defensiveSpells = {
    [33206] = "PRIEST", [47788] = "PRIEST",
    [6940] = "PALADIN", [1022] = "PALADIN", [5599] = "PALADIN", [10278] = "PALADIN",
    [22812] = "DRUID", [61336] = "DRUID",
    [974] = "SHAMAN", [32593] = "SHAMAN", [32594] = "SHAMAN", [49284] = "SHAMAN", [49283] = "SHAMAN",
}

-- Собственные поглощающие эффекты. Щит земли является лечением, а не
-- поглощением, поэтому он намеренно не входит в эту таблицу.
local absorbSpells = {
    [17] = true, [592] = true, [600] = true, [3747] = true, [6065] = true, [6066] = true,
    [10898] = true, [10899] = true, [10900] = true, [10901] = true, [25217] = true,
    [25218] = true, [48065] = true, [48066] = true, -- Слово силы: Щит
    [47753] = true, -- Божественное покровительство
}
local defensiveSpellSettings = { [33206] = "painSuppressionEnabled", [47788] = "guardianSpiritEnabled" }
local priestTrackedSpells = {
    [33206] = "painSuppressionEnabled",
    [10060] = "powerInfusionEnabled",
    [47788] = "guardianSpiritEnabled",
    [6346] = "fearWardEnabled",
}
local paladinTrackedSpells = {
    [633] = "layOnHandsEnabled", [2800] = "layOnHandsEnabled", [10310] = "layOnHandsEnabled", [27154] = "layOnHandsEnabled", [48788] = "layOnHandsEnabled",
    [53563] = "beaconOfLightEnabled",
    [1022] = "handOfProtectionEnabled", [5599] = "handOfProtectionEnabled", [10278] = "handOfProtectionEnabled",
    [19752] = "divineInterventionEnabled", [1044] = "handOfFreedomEnabled", [6940] = "handOfSacrificeEnabled",
}
local druidTrackedSpells = {
    [29166] = "innervateEnabled",
    [740] = "tranquilityEnabled", [8918] = "tranquilityEnabled", [9862] = "tranquilityEnabled", [9863] = "tranquilityEnabled",
    [26983] = "tranquilityEnabled", [48446] = "tranquilityEnabled", [48447] = "tranquilityEnabled",
    [20484] = "rebirthEnabled", [20739] = "rebirthEnabled", [20742] = "rebirthEnabled", [20747] = "rebirthEnabled",
    [20748] = "rebirthEnabled", [26994] = "rebirthEnabled", [48477] = "rebirthEnabled",
}
local shamanTrackedSpells = {
    [974] = "earthShieldEnabled", [32593] = "earthShieldEnabled", [32594] = "earthShieldEnabled", [49283] = "earthShieldEnabled", [49284] = "earthShieldEnabled",
    [2825] = "bloodlustEnabled", [32182] = "bloodlustEnabled",
    [16190] = "manaTideEnabled",
}
defensiveSpellSettings[6940] = "handOfSacrificeEnabled"
defensiveSpellSettings[1022], defensiveSpellSettings[5599], defensiveSpellSettings[10278] = "handOfProtectionEnabled", "handOfProtectionEnabled", "handOfProtectionEnabled"
defensiveSpellSettings[974], defensiveSpellSettings[32593], defensiveSpellSettings[32594] = "earthShieldEnabled", "earthShieldEnabled", "earthShieldEnabled"
defensiveSpellSettings[49283], defensiveSpellSettings[49284] = "earthShieldEnabled", "earthShieldEnabled"
local classSetting = { PRIEST = "priestBuffsEnabled", PALADIN = "paladinBuffsEnabled", DRUID = "druidBuffsEnabled", SHAMAN = "shamanBuffsEnabled" }
local tracked, unitsByGUID, ownAuras, lastTargetAnnouncement = {}, {}, {}, {}
local playerGUID, streak, lastSaveAt, lastEmoteAt, lastPhraseIndex = nil, 0, 0, 0, nil
local recentAbilityAnnouncements, lastAbilityPhraseIndex = {}, {}
local elapsedSinceScan, inCombat, currentInstanceType, lastEnteredInstanceType = 0, false, "none", "none"
local sessionStats = { saves = 0, attempts = 0, failures = 0, healing = 0, prevented = 0 }
local combatStats = { saves = 0, attempts = 0, failures = 0 }
local battlegroundStats = { saves = 0, attempts = 0, failures = 0 }

local function battlegroundSessionId()
    if currentInstanceType ~= "pvp" and currentInstanceType ~= "arena" then return "" end
    local zone = GetRealZoneText and GetRealZoneText() or "Battleground"
    local runtime = GetBattlefieldInstanceRunTime and GetBattlefieldInstanceRunTime() or 0
    if (tonumber(runtime) or 0) <= 0 and DamageLifeDB and DamageLifeDB.bgSessionId and DamageLifeDB.bgSessionId ~= "" then
        return DamageLifeDB.bgSessionId
    end
    local started = (time and time() or 0) - math.floor((tonumber(runtime) or 0) / 1000)
    return tostring(zone) .. ":" .. tostring(math.floor(started / 30))
end

local function refreshBattlegroundCounter()
    local identity = battlegroundSessionId()
    if identity == "" then
        DamageLifeDB.bgSessionId, DamageLifeDB.bgSaveCount = "", 0
        return
    end
    if DamageLifeDB.bgSessionId ~= identity then
        DamageLifeDB.bgSessionId, DamageLifeDB.bgSaveCount = identity, 0
        battlegroundStats = { saves = 0, attempts = 0, failures = 0 }
    end
end
local defaultPriestBuffPhrases = {
    "защищает {target} с помощью {spell}!",
    "дарует {target} защиту: {spell}!",
    "призывает {spell}, чтобы уберечь {target}!",
    "не позволяет {target} погибнуть — {spell}!",
    "окружает {target} божественной защитой: {spell}!",
    "встаёт между смертью и {target}, применяя {spell}!",
}
local defaultPaladinBuffPhrases = {
    "защищает {target} с помощью {spell}!",
    "озаряет {target} силой {spell}!",
    "призывает Свет и применяет {spell} к {target}!",
    "не оставляет {target} без защиты — {spell}!",
    "дарует {target} благословение: {spell}!",
    "направляет священную силу на {target}: {spell}!",
}

local defaultNatureBuffPhrases = {
    "поддерживает {target} с помощью {spell}!",
    "дарует {target} силу природы: {spell}!",
    "призывает {spell}, чтобы помочь {target}!",
    "укрепляет {target}, применяя {spell}!",
    "окружает {target} природной энергией: {spell}!",
    "направляет {spell} на {target}!",
}
local defaultGroupBuffPhrases = {
    "призывает {spell} для всей группы!",
    "наполняет союзников силой: {spell}!",
    "ведёт группу в бой с помощью {spell}!",
    "пробуждает боевой дух союзников: {spell}!",
    "обрушивает на поле боя мощь {spell}!",
    "дарует группе неудержимую силу: {spell}!",
}

local defaultHymnPhrases = {
    "{spell}! Поддерживаю всю группу!",
    "Держитесь! Начинаю {spell}!",
    "Соберитесь вместе — применяю {spell}!",
    "Не сдавайтесь! Сейчас прозвучит {spell}!",
    "Помогаю всей группе с помощью {spell}!",
    "Всем приготовиться — {spell}!",
}

local defaultTranquilityPhrases = {
    "{spell}! Исцеляю всю группу!",
    "Соберитесь рядом — начинаю {spell}!",
    "Призываю силы природы: {spell}!",
    "Держитесь! Сейчас применяю {spell}!",
    "Помогаю всей группе с помощью {spell}!",
    "Всем приготовиться — {spell}!",
}

local defaultRebirthPhrases = {
    "возвращает {target} к жизни с помощью {spell}!",
    "призывает {target} обратно в бой — {spell}!",
    "не отпускает {target} в мир духов: {spell}!",
    "дарует {target} новое дыхание жизни — {spell}!",
    "возрождает {target} силой природы: {spell}!",
    "поднимает {target} на ноги с помощью {spell}!",
}

local defaultLevitatePhrases = {
    "На вас наложена {spell}.",
    "Вы получили {spell} — осторожнее с высотой!",
    "Дарую вам лёгкость: {spell}.",
    "Теперь вы парите — на вас действует {spell}.",
    "Используйте {spell}, чтобы безопасно спуститься.",
    "Над землёй вас удерживает {spell}.",
}

DamageLifeAbilityDefinitions = {
    { key = "PRIEST_PAIN", class = "PRIEST", label = "Подавление боли", setting = "painSuppressionEnabled", spellId = 33206, spellIds = { 33206 }, icon = "Interface\\Icons\\Spell_Holy_PainSupression", defaults = defaultPriestBuffPhrases, legacy = "PRIEST" },
    { key = "PRIEST_POWER", class = "PRIEST", label = "Придание сил", setting = "powerInfusionEnabled", spellId = 10060, spellIds = { 10060 }, icon = "Interface\\Icons\\Spell_Holy_PowerInfusion", defaults = defaultPriestBuffPhrases, legacy = "PRIEST" },
    { key = "PRIEST_GUARDIAN", class = "PRIEST", label = "Оберегающий дух", setting = "guardianSpiritEnabled", spellId = 47788, spellIds = { 47788 }, icon = "Interface\\Icons\\Spell_Holy_GuardianSpirit", defaults = defaultPriestBuffPhrases, legacy = "PRIEST" },
    { key = "PRIEST_FEAR_WARD", class = "PRIEST", label = "Защита от страха", setting = "fearWardEnabled", spellId = 6346, spellIds = { 6346 }, icon = "Interface\\Icons\\Spell_Holy_Excorcism", defaults = defaultPriestBuffPhrases, legacy = "PRIEST" },
    { key = "PRIEST_LEVITATE", class = "PRIEST", label = "Левитация", setting = "levitateEnabled", spellId = 1706, spellIds = { 1706 }, icon = "Interface\\Icons\\Spell_Holy_LayOnHands", defaults = defaultLevitatePhrases, whisperOnly = true },
    { key = "PRIEST_HOPE", class = "PRIEST", label = "Гимн надежды", setting = "hymnOfHopeEnabled", spellId = 64901, spellIds = { 64901 }, icon = "Interface\\Icons\\Spell_Holy_SymbolOfHope", defaults = defaultHymnPhrases, groupWide = true, announcementChannel = "YELL" },
    { key = "PRIEST_DIVINE", class = "PRIEST", label = "Божественный гимн", setting = "divineHymnEnabled", spellId = 64843, spellIds = { 64843 }, icon = "Interface\\Icons\\Spell_Holy_DivineHymn", defaults = defaultHymnPhrases, groupWide = true, announcementChannel = "YELL" },
    { key = "PALADIN_HANDS", class = "PALADIN", label = "Возложение рук", setting = "layOnHandsEnabled", spellId = 48788, spellIds = { 633, 2800, 10310, 27154, 48788 }, icon = "Interface\\Icons\\Spell_Holy_LayOnHands", defaults = defaultPaladinBuffPhrases, legacy = "PALADIN" },
    { key = "PALADIN_BEACON", class = "PALADIN", label = "Частица Света", setting = "beaconOfLightEnabled", spellId = 53563, spellIds = { 53563 }, icon = "Interface\\Icons\\Ability_Paladin_BeaconofLight", defaults = defaultPaladinBuffPhrases, legacy = "PALADIN" },
    { key = "PALADIN_PROTECTION", class = "PALADIN", label = "Длань защиты", setting = "handOfProtectionEnabled", spellId = 10278, spellIds = { 1022, 5599, 10278 }, icon = "Interface\\Icons\\Spell_Holy_SealOfProtection", defaults = defaultPaladinBuffPhrases, legacy = "PALADIN" },
    { key = "PALADIN_INTERVENTION", class = "PALADIN", label = "Божественное вмешательство", setting = "divineInterventionEnabled", spellId = 19752, spellIds = { 19752 }, icon = "Interface\\Icons\\Spell_Nature_TimeStop", defaults = defaultPaladinBuffPhrases, legacy = "PALADIN" },
    { key = "PALADIN_FREEDOM", class = "PALADIN", label = "Длань свободы", setting = "handOfFreedomEnabled", spellId = 1044, spellIds = { 1044 }, icon = "Interface\\Icons\\Spell_Holy_SealOfValor", defaults = defaultPaladinBuffPhrases, legacy = "PALADIN" },
    { key = "PALADIN_SACRIFICE", class = "PALADIN", label = "Длань жертвенности", setting = "handOfSacrificeEnabled", spellId = 6940, spellIds = { 6940 }, icon = "Interface\\Icons\\Spell_Holy_SealOfSacrifice", defaults = defaultPaladinBuffPhrases, legacy = "PALADIN" },
    { key = "DRUID_INNERVATE", class = "DRUID", label = "Озарение", setting = "innervateEnabled", spellId = 29166, spellIds = { 29166 }, icon = "Interface\\Icons\\Spell_Nature_Lightning", defaults = defaultNatureBuffPhrases, legacy = "DRUID" },
    { key = "DRUID_TRANQUILITY", class = "DRUID", label = "Спокойствие", setting = "tranquilityEnabled", spellId = 48447, spellIds = { 740, 8918, 9862, 9863, 26983, 48446, 48447 }, icon = "Interface\\Icons\\Spell_Nature_Tranquility", defaults = defaultTranquilityPhrases, legacy = "DRUID", groupWide = true, announcementChannel = "YELL" },
    { key = "DRUID_REBIRTH", class = "DRUID", label = "Возрождение", setting = "rebirthEnabled", spellId = 48477, spellIds = { 20484, 20739, 20742, 20747, 20748, 26994, 48477 }, icon = "Interface\\Icons\\Spell_Nature_Reincarnation", defaults = defaultRebirthPhrases, legacy = "DRUID", announceOnCast = true },
    { key = "SHAMAN_EARTH", class = "SHAMAN", label = "Щит земли", setting = "earthShieldEnabled", spellId = 49284, spellIds = { 974, 32593, 32594, 49283, 49284 }, icon = "Interface\\Icons\\Spell_Nature_SkinofEarth", defaults = defaultNatureBuffPhrases, legacy = "SHAMAN" },
    { key = "SHAMAN_BLOODLUST", class = "SHAMAN", label = "Жажда крови / Героизм", setting = "bloodlustEnabled", spellId = 2825, spellIds = { 2825, 32182 }, icon = "Interface\\Icons\\Spell_Nature_BloodLust", defaults = defaultGroupBuffPhrases, legacy = "SHAMAN", groupWide = true, announcementChannel = "YELL" },
    { key = "SHAMAN_MANA_TIDE", class = "SHAMAN", label = "Тотем прилива маны", setting = "manaTideEnabled", spellId = 16190, spellIds = { 16190 }, icon = "Interface\\Icons\\Spell_Frost_SummonWaterElemental", defaults = defaultGroupBuffPhrases, legacy = "SHAMAN", groupWide = true, announcementChannel = "YELL" },
}
local abilityBySpellId = {}
for _, definition in ipairs(DamageLifeAbilityDefinitions) do for _, spellId in ipairs(definition.spellIds) do abilityBySpellId[spellId] = definition end end

local function chat(message)
    DEFAULT_CHAT_FRAME:AddMessage("|cff33ff99DamageLife:|r " .. message)
end

local function debugChat(message)
    if DamageLifeDB and DamageLifeDB.debug then chat("|cffaaaaaa[проверка]|r " .. message) end
end

local function truncateUtf8Characters(text, maximum)
    text = text or ""
    local position, count, bytes = 1, 0, #text
    while position <= bytes and count < maximum do
        local first = string.byte(text, position)
        local length = first < 128 and 1 or (first < 224 and 2 or (first < 240 and 3 or 4))
        if position + length - 1 > bytes then break end
        position, count = position + length, count + 1
    end
    return string.sub(text, 1, position - 1)
end

local function deepDefaults()
    if not DamageLifeDB then DamageLifeDB = {} end
    local previousWidgetDesign = DamageLifeDB.widgetDesignVersion or 0
    for key, value in pairs(defaults) do if DamageLifeDB[key] == nil then DamageLifeDB[key] = value end end
    if previousWidgetDesign < 2 then
        DamageLifeDB.widgetR, DamageLifeDB.widgetG, DamageLifeDB.widgetB = 1, 0.65, 0.08
    end
    if previousWidgetDesign < 3 then
        DamageLifeDB.widgetPoint, DamageLifeDB.widgetRelativePoint = "TOP", "TOP"
        DamageLifeDB.widgetX, DamageLifeDB.widgetY, DamageLifeDB.widgetScale = 0, -276, 0.6
        DamageLifeDB.widgetDesignVersion = 3
    end
    -- Удалённые фильтры больше не должны скрыто влиять на подсчёт.
    DamageLifeDB.includeSelf, DamageLifeDB.includePets, DamageLifeDB.pvpOnly = false, false, false
    -- Удалённая система критических целей не оставляет скрытых настроек в базе.
    for _, key in ipairs({ "criticalAlertEnabled", "criticalAlertSound", "crisisTrackerEnabled", "crisisTrackerLocked",
        "crisisTrackerScale", "crisisTrackerPoint", "crisisTrackerRelativePoint", "crisisTrackerX", "crisisTrackerY",
        "crisisTrackerMaxRows" }) do
        DamageLifeDB[key] = nil
    end
    -- Сброс серии после смерти и выхода с поля боя является базовым поведением.
    DamageLifeDB.resetStreakOnDeath, DamageLifeDB.resetStreakOutOfCombat = true, false
    DamageLifeDB.targetWindowCount = math.max(1, math.min(5, math.floor(tonumber(DamageLifeDB.targetWindowCount) or 1)))
    if type(DamageLifeDB.targetWindowPositions) ~= "table" then DamageLifeDB.targetWindowPositions = {} end
    if type(DamageLifeDB.targetNotifications) ~= "table" then DamageLifeDB.targetNotifications = {} end
    local tn = DamageLifeDB.targetNotifications
    if tn.enabled == nil then tn.enabled = true end
    if tn.vulnerable == nil then tn.vulnerable = true end
    if tn.lastDefense == nil then tn.lastDefense = true end
    if tn.defenseRegained == nil then tn.defenseRegained = true end
    if tn.execute == nil then tn.execute = true end
    if tn.priority == nil then tn.priority = true end
    if tn.lowHP == nil then tn.lowHP = false end
    if tn.chat == nil then tn.chat = false end
    if tn.sound == nil then tn.sound = true end
    tn.executePercent = math.max(5, math.min(50, tonumber(tn.executePercent) or 20))
    tn.cooldown = math.max(0.5, math.min(10, tonumber(tn.cooldown) or 2))
    -- Вкладка выбора режима подсчёта удалена. Старое сохранённое значение
    -- DECISIVE/CONTRIBUTION не должно продолжать скрыто менять правила зачёта.
    DamageLifeDB.countMode = "STRICT"
    DamageLifeDB.stats = DamageLifeDB.stats or {}
    DamageLifeDB.stats.totalDamageEvents = tonumber(DamageLifeDB.stats.totalDamageEvents) or 0
    DamageLifeDB.stats.abilityCasts = tonumber(DamageLifeDB.stats.abilityCasts) or 0
    DamageLifeDB.stats.criticalHits = tonumber(DamageLifeDB.stats.criticalHits) or 0
    DamageLifeDB.stats.categoryEvents = DamageLifeDB.stats.categoryEvents or {}
    DamageLifeDB.stats.categoryBySpell = DamageLifeDB.stats.categoryBySpell or {}
    DamageLifeDB.stats.categoryByTarget = DamageLifeDB.stats.categoryByTarget or {}
    for _, category in ipairs({ "CRITICAL", "BURST", "EXECUTE", "CONTROL" }) do
        DamageLifeDB.stats.categoryEvents[category] = tonumber(DamageLifeDB.stats.categoryEvents[category]) or 0
        DamageLifeDB.stats.categoryBySpell[category] = DamageLifeDB.stats.categoryBySpell[category] or {}
        DamageLifeDB.stats.categoryByTarget[category] = DamageLifeDB.stats.categoryByTarget[category] or {}
    end
    DamageLifeDB.combatCategories = DamageLifeDB.combatCategories or {}
    for _, category in ipairs({ "critical", "burst", "execute", "control" }) do if DamageLifeDB.combatCategories[category] == nil then DamageLifeDB.combatCategories[category] = true end end
    DamageLifeDB.stats.byTarget = DamageLifeDB.stats.byTarget or {}
    DamageLifeDB.stats.bySpell = DamageLifeDB.stats.bySpell or {}
    local s = DamageLifeDB.stats
    s.totalSaves = s.totalSaves or DamageLifeDB.totalSaves or 0
    s.bestStreak = s.bestStreak or DamageLifeDB.bestStreak or 0
    s.attempts = s.attempts or 0; s.failures = s.failures or 0
    s.lethalPreventions = s.lethalPreventions or 0
    s.effectiveHealing = s.effectiveHealing or 0; s.prevented = s.prevented or 0
    s.byTarget = s.byTarget or {}; s.bySpell = s.bySpell or {}; s.byClass = s.byClass or {}
    s.buffCasts = s.buffCasts or 0; s.buffBySpell = s.buffBySpell or {}; s.buffByTarget = s.buffByTarget or {}
    for i = 1, #defaultPhrases do
        if DamageLifeDB.phrases[i] == nil then DamageLifeDB.phrases[i] = defaultPhrases[i] end
        DamageLifeDB.phrases[i] = truncateUtf8Characters(DamageLifeDB.phrases[i], 100)
        if DamageLifeDB.phraseEnabled[i] == nil then DamageLifeDB.phraseEnabled[i] = true end
    end
    for i = 1, #defaultStreakNames do
        if DamageLifeDB.streakNames[i] == nil then DamageLifeDB.streakNames[i] = defaultStreakNames[i] end
    end
    for i = 1, #defaultPriestBuffPhrases do
        if DamageLifeDB.priestBuffPhrases[i] == nil then DamageLifeDB.priestBuffPhrases[i] = defaultPriestBuffPhrases[i] end
        if i > 1 and DamageLifeDB.priestBuffPhraseEnabled[i] == nil then DamageLifeDB.priestBuffPhraseEnabled[i] = true end
    end
    for i = 1, #defaultPaladinBuffPhrases do
        if DamageLifeDB.paladinBuffPhrases[i] == nil then DamageLifeDB.paladinBuffPhrases[i] = defaultPaladinBuffPhrases[i] end
        if i > 1 and DamageLifeDB.paladinBuffPhraseEnabled[i] == nil then DamageLifeDB.paladinBuffPhraseEnabled[i] = true end
    end
    DamageLifeDB.abilitySettings = DamageLifeDB.abilitySettings or {}
    for _, definition in ipairs(DamageLifeAbilityDefinitions) do
        local config = DamageLifeDB.abilitySettings[definition.key]
        if not config then config = {}; DamageLifeDB.abilitySettings[definition.key] = config end
        local oldEmote, oldWhisper, oldPhrases, oldPhraseEnabled
        if definition.legacy == "PRIEST" then
            oldEmote, oldWhisper = DamageLifeDB.priestBuffChatEnabled, DamageLifeDB.priestBuffWhisperEnabled
            oldPhrases, oldPhraseEnabled = DamageLifeDB.priestBuffPhrases, DamageLifeDB.priestBuffPhraseEnabled
        elseif definition.legacy == "PALADIN" then
            oldEmote, oldWhisper = DamageLifeDB.paladinBuffChatEnabled, DamageLifeDB.paladinBuffWhisperEnabled
            oldPhrases, oldPhraseEnabled = DamageLifeDB.paladinBuffPhrases, DamageLifeDB.paladinBuffPhraseEnabled
        elseif definition.legacy == "DRUID" then
            oldEmote, oldWhisper = DamageLifeDB.druidBuffChatEnabled, DamageLifeDB.druidBuffWhisperEnabled
        elseif definition.legacy == "SHAMAN" then
            oldEmote, oldWhisper = DamageLifeDB.shamanBuffChatEnabled, DamageLifeDB.shamanBuffWhisperEnabled
        end
        if definition.whisperOnly then
            config.emote = false
            if config.whisper == nil then config.whisper = true end
        else
            if config.emote == nil then config.emote = oldEmote ~= false end
            if config.whisper == nil then config.whisper = not definition.groupWide and oldWhisper ~= false or false end
        end
        config.phrases = config.phrases or {}
        config.phraseEnabled = config.phraseEnabled or {}
        -- Версия 0.42 могла создать «Левитацию» из старых общих фраз жреца.
        -- Один раз заменяем их на собственный набор личных сообщений.
        if definition.key == "PRIEST_LEVITATE" and (config.messageDefaultsVersion or 0) < 1 then
            for i = 1, 6 do
                config.phrases[i] = definition.defaults[i]
                if i > 1 then config.phraseEnabled[i] = true end
            end
            config.messageDefaultsVersion = 1
        end
        for i = 1, 6 do
            if config.phrases[i] == nil then config.phrases[i] = oldPhrases and oldPhrases[i] or definition.defaults[i] end
            config.phrases[i] = truncateUtf8Characters(config.phrases[i], 70)
            if i > 1 and config.phraseEnabled[i] == nil then
                if oldPhraseEnabled and oldPhraseEnabled[i] ~= nil then config.phraseEnabled[i] = oldPhraseEnabled[i] and true or false
                else config.phraseEnabled[i] = true end
            end
        end
    end
    DamageLifeDB.totalSaves, DamageLifeDB.bestStreak = s.totalSaves, s.bestStreak
end

local function instanceAllowed()
    -- PLAYER_ENTERING_WORLD keeps this value current. Querying instance data
    -- for every raid member on every health pass caused needless client work.
    if currentInstanceType == "pvp" then return DamageLifeDB.allowBattlegrounds end
    if currentInstanceType == "arena" then return DamageLifeDB.allowArenas end
    if currentInstanceType == "party" then return DamageLifeDB.allowDungeons end
    if currentInstanceType == "raid" then return DamageLifeDB.allowRaids end
    return DamageLifeDB.allowWorld
end

local healingRangeSpells = {
    PRIEST = { 48071, 48070, 2061 },
    PALADIN = { 48782, 48781, 635 },
    DRUID = { 48378, 48377, 5185 },
    SHAMAN = { 49273, 49272, 331 },
}
local function unitInHealingRange(unit)
    if UnitIsUnit(unit, "player") then return true end
    -- Для участников группы UnitInRange является самым надёжным штатным
    -- приближением к лекарскому радиусу на клиентах 3.3.5a.
    if UnitInRange then
        local groupResult = UnitInRange(unit)
        if groupResult then return true end
    end
    local _, classToken = UnitClass("player")
    local spellIds = healingRangeSpells[classToken]
    if spellIds and IsSpellInRange then
        for _, spellId in ipairs(spellIds) do
            local known = not IsSpellKnown or IsSpellKnown(spellId)
            local spellName = known and GetSpellInfo(spellId)
            if spellName then
                local result = IsSpellInRange(spellName, unit)
                if result ~= nil then return result == 1 end
            end
        end
    end
    -- Консервативный запасной вариант (~28 м), если сервер не поддерживает
    -- проверку дальности заклинаний. Он не добавляет далёкие ложные цели.
    if CheckInteractDistance and CheckInteractDistance(unit, 4) then return true end
    return false
end

local function unitAllowed(unit)
    if not instanceAllowed() then return false end
    if not UnitIsFriend("player", unit) or not UnitCanAssist("player", unit) then return false end
    if not unitInHealingRange(unit) then return false end
    if UnitIsUnit(unit, "player") and not DamageLifeDB.includeSelf then return false end
    if string.find(unit, "pet") and not DamageLifeDB.includePets then return false end
    if DamageLifeDB.pvpOnly and currentInstanceType ~= "pvp" and currentInstanceType ~= "arena" and not UnitIsPVP(unit) then return false end
    return true
end

local function rebuildUnitMap()
    wipe(unitsByGUID)
    local function add(unit)
        if UnitExists(unit) and UnitIsFriend("player", unit) and UnitCanAssist("player", unit) then
            local guid = UnitGUID(unit); if guid then unitsByGUID[guid] = unit end
        end
    end
    add("player"); if DamageLifeDB.includePets then add("pet") end
    if GetNumRaidMembers() > 0 then
        for i = 1, GetNumRaidMembers() do add("raid" .. i); if DamageLifeDB.includePets then add("raidpet" .. i) end end
    else
        for i = 1, GetNumPartyMembers() do add("party" .. i); if DamageLifeDB.includePets then add("partypet" .. i) end end
    end
    for guid, state in pairs(tracked) do
        if not unitsByGUID[guid] then state.active, state.pending, state.crisisVisible = false, false, false end
    end
end

local function healthData(unit)
    if not unit or not UnitExists(unit) or UnitIsDeadOrGhost(unit) then return end
    local maximum = UnitHealthMax(unit)
    if not maximum or maximum <= 0 then return end
    local current = UnitHealth(unit)
    return current, maximum, current / maximum
end

local function decayPressure(state, now)
    now = now or GetTime()
    local elapsed = now - (state.lastPressureDecay or now)
    if elapsed > 0 then
        local decay = math.exp(-elapsed / 3)
        state.recentOwnHealing = (state.recentOwnHealing or 0) * decay
        state.recentAbsorb = (state.recentAbsorb or 0) * decay
        state.recentDamage = (state.recentDamage or 0) * decay
        state.lastPressureDecay = now
    end
end

local function statIncrement(bucket, key, amount)
    bucket[key] = (bucket[key] or 0) + (amount or 1)
end

local function refreshStatsUI()
    if DamageLifeSettings_RefreshStats then DamageLifeSettings_RefreshStats() end
end

local function recordAttempt()
    statIncrement(DamageLifeDB.stats, "attempts"); statIncrement(sessionStats, "attempts"); statIncrement(combatStats, "attempts")
    if currentInstanceType == "pvp" or currentInstanceType == "arena" then statIncrement(battlegroundStats, "attempts") end
    if OraculStatisticsEngine then OraculStatisticsEngine:RecordRescueAttempt() end
    refreshStatsUI()
end

local function recordFailure(state)
    statIncrement(DamageLifeDB.stats, "failures"); statIncrement(sessionStats, "failures"); statIncrement(combatStats, "failures")
    if currentInstanceType == "pvp" or currentInstanceType == "arena" then statIncrement(battlegroundStats, "failures") end
    if OraculStatisticsEngine then OraculStatisticsEngine:RecordRescueFailure(state) end
    debugChat("спасти " .. (state.name or UNKNOWN) .. " не удалось")
    refreshStatsUI()
end

local function beginCrisis(guid, unit, current, maximum)
    if not unitAllowed(unit) then return end
    local state = tracked[guid]
    if state and (state.active or not state.armed) then return end
    state = state or {}; tracked[guid] = state
    local className, classToken = UnitClass(unit)
    state.active, state.armed, state.pending, state.crisisVisible, state.crisisResolvedAt = true, false, false, true, nil
    state.startedAt, state.startHealth, state.maxHealth = GetTime(), current, maximum
    state.ownHealing, state.totalHealing, state.prevented, state.lethalPrevented = 0, 0, 0, false
    state.recentOwnHealing, state.recentAbsorb, state.recentDamage, state.lastPressureDecay = 0, 0, 0, GetTime()
    state.name, state.unit, state.guid = UnitName(unit) or UNKNOWN, unit, guid
    state.className, state.classToken = className or UNKNOWN, classToken or "UNKNOWN"
    state.lastOwnSpell, state.lastOwnHealAt, state.lastHealerGUID, state.defensiveSpell = nil, 0, nil, nil
    state.lastOwnContributionAt = 0
    if ownAuras[guid] then
        for spellId, spellName in pairs(ownAuras[guid]) do
            local setting = defensiveSpellSettings[spellId]
            if defensiveSpells[spellId] and (not setting or DamageLifeDB[setting]) then state.defensiveSpell, state.lastOwnSpell = spellName, spellName; break end
        end
    end
    state.reportedReject = false
    recordAttempt()
    debugChat("окно спасения открыто: " .. state.name .. " — " .. math.floor(current / maximum * 100 + 0.5) .. "%")
end

local widget = CreateFrame("Frame", "DamageLifeSaveWidget", UIParent)
widget:SetSize(420, 500); widget:SetFrameStrata("HIGH"); widget:EnableMouse(true); widget:SetMovable(true); widget:SetClampedToScreen(true)
widget:SetBackdrop({
    bgFile = "Interface\\Buttons\\WHITE8X8",
    edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
    tile = true, tileSize = 8, edgeSize = 12,
    insets = { left = 3, right = 3, top = 3, bottom = 3 },
})
widget:SetBackdropColor(0.005, 0.012, 0.022, 0.10); widget:SetBackdropBorderColor(0.85, 0.64, 0.18, 0); widget:Hide()
widget.inner = widget:CreateTexture(nil, "BACKGROUND"); widget.inner:SetTexture("Interface\\Buttons\\WHITE8X8")
widget.inner:SetPoint("TOPLEFT", 6, -6); widget.inner:SetPoint("BOTTOMRIGHT", -6, 6); widget.inner:SetVertexColor(0.015, 0.07, 0.045, 0.42)
widget.topAccent = widget:CreateTexture(nil, "BORDER"); widget.topAccent:SetTexture("Interface\\Buttons\\WHITE8X8")
widget.topAccent:SetPoint("TOPLEFT", 10, -5); widget.topAccent:SetPoint("TOPRIGHT", -10, -5); widget.topAccent:SetHeight(2); widget.topAccent:SetVertexColor(1, 0.78, 0.18, 0.95)
widget.bottomAccent = widget:CreateTexture(nil, "BORDER"); widget.bottomAccent:SetTexture("Interface\\Buttons\\WHITE8X8")
widget.bottomAccent:SetPoint("BOTTOMLEFT", 10, 5); widget.bottomAccent:SetPoint("BOTTOMRIGHT", -10, 5); widget.bottomAccent:SetHeight(2); widget.bottomAccent:SetVertexColor(0.55, 0.38, 0.08, 0.9)

widget.portraitFrame = CreateFrame("Frame", nil, widget); widget.portraitFrame:SetSize(86, 86); widget.portraitFrame:SetPoint("LEFT", 12, 0)
widget.portraitFrame:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", edgeSize = 11, insets = { left = 3, right = 3, top = 3, bottom = 3 } })
widget.portraitFrame:SetBackdropColor(0.01, 0.015, 0.012, 1); widget.portraitFrame:SetBackdropBorderColor(1, 0.75, 0.18, 1)
widget.icon = widget.portraitFrame:CreateTexture(nil, "ARTWORK"); widget.icon:SetPoint("TOPLEFT", 7, -7); widget.icon:SetPoint("BOTTOMRIGHT", -7, 7)
widget.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)

widget.badge = CreateFrame("Frame", nil, widget); widget.badge:SetSize(32, 32); widget.badge:SetPoint("BOTTOMRIGHT", widget.portraitFrame, "BOTTOMRIGHT", 5, -2)
widget.badge:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", edgeSize = 8, insets = { left = 2, right = 2, top = 2, bottom = 2 } })
widget.badge:SetBackdropColor(0.03, 0.08, 0.18, 1); widget.badge:SetBackdropBorderColor(1, 0.75, 0.18, 1)
widget.badgeIcon = widget.badge:CreateTexture(nil, "ARTWORK"); widget.badgeIcon:SetPoint("TOPLEFT", 5, -5); widget.badgeIcon:SetPoint("BOTTOMRIGHT", -5, 5)
widget.badgeIcon:SetTexture("Interface\\Icons\\Spell_Holy_PowerWordShield")

widget.title = widget:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge"); widget.title:SetPoint("TOPLEFT", 115, -17); widget.title:SetWidth(245); widget.title:SetJustifyH("LEFT")
widget.name = widget:CreateFontString(nil, "OVERLAY", "GameFontHighlightLarge"); widget.name:SetPoint("TOPLEFT", 115, -45); widget.name:SetWidth(245); widget.name:SetJustifyH("LEFT")
widget.subtitle = widget:CreateFontString(nil, "OVERLAY", "GameFontHighlight"); widget.subtitle:SetPoint("TOPLEFT", 115, -74); widget.subtitle:SetWidth(245); widget.subtitle:SetJustifyH("LEFT")

widget.pulse = CreateFrame("Frame", nil, widget); widget.pulse:SetSize(112, 30); widget.pulse:SetPoint("RIGHT", -82, 2)
widget.pulseGlow = widget.pulse:CreateTexture(nil, "BORDER"); widget.pulseGlow:SetTexture("Interface\\Buttons\\WHITE8X8"); widget.pulseGlow:SetBlendMode("ADD")
widget.pulseGlow:SetPoint("LEFT", 0, 0); widget.pulseGlow:SetPoint("RIGHT", 0, 0); widget.pulseGlow:SetHeight(8); widget.pulseGlow:SetAlpha(0.14)
widget.pulseCore = widget.pulse:CreateTexture(nil, "ARTWORK"); widget.pulseCore:SetTexture("Interface\\Buttons\\WHITE8X8"); widget.pulseCore:SetBlendMode("ADD")
widget.pulseCore:SetPoint("LEFT", 0, 0); widget.pulseCore:SetPoint("RIGHT", 0, 0); widget.pulseCore:SetHeight(2)
widget.pulseSpark = widget.pulse:CreateTexture(nil, "OVERLAY"); widget.pulseSpark:SetTexture("Interface\\Cooldown\\star4"); widget.pulseSpark:SetBlendMode("ADD")
widget.pulseSpark:SetSize(24, 24); widget.pulseSpark:SetPoint("CENTER", widget.pulse, "LEFT", 22, 0)
widget.pulseDots = {}
for i, point in ipairs({ 18, 48, 82 }) do
    local dot = widget.pulse:CreateTexture(nil, "OVERLAY"); dot:SetTexture("Interface\\Cooldown\\star4"); dot:SetBlendMode("ADD")
    dot:SetSize(i == 2 and 12 or 8, i == 2 and 12 or 8); dot:SetPoint("CENTER", widget.pulse, "LEFT", point, 0); dot:SetAlpha(i == 2 and 0.55 or 0.3)
    widget.pulseDots[i] = dot
end

widget.healGlow = widget:CreateTexture(nil, "ARTWORK"); widget.healGlow:SetTexture("Interface\\Cooldown\\star4"); widget.healGlow:SetBlendMode("ADD")
widget.healGlow:SetSize(82, 82); widget.healGlow:SetPoint("RIGHT", -17, 2); widget.healGlow:SetVertexColor(0.65, 1, 0.05, 0.8)
widget.healFrame = CreateFrame("Frame", nil, widget); widget.healFrame:SetSize(54, 54); widget.healFrame:SetPoint("RIGHT", -31, 2)
widget.healFrame:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", edgeSize = 9, insets = { left = 2, right = 2, top = 2, bottom = 2 } })
widget.healFrame:SetBackdropColor(0.08, 0.20, 0.01, 0.95); widget.healFrame:SetBackdropBorderColor(0.72, 1, 0.08, 1)
widget.healIcon = widget.healFrame:CreateTexture(nil, "ARTWORK"); widget.healIcon:SetPoint("TOPLEFT", 6, -6); widget.healIcon:SetPoint("BOTTOMRIGHT", -6, 6)
widget.healIcon:SetTexture("Interface\\Buttons\\WHITE8X8"); widget.healIcon:SetVertexColor(0.04, 0.10, 0.01, 0.85)
widget.healCrossH = widget.healFrame:CreateTexture(nil, "OVERLAY"); widget.healCrossH:SetTexture("Interface\\Buttons\\WHITE8X8"); widget.healCrossH:SetBlendMode("ADD")
widget.healCrossH:SetSize(32, 11); widget.healCrossH:SetPoint("CENTER")
widget.healCrossV = widget.healFrame:CreateTexture(nil, "OVERLAY"); widget.healCrossV:SetTexture("Interface\\Buttons\\WHITE8X8"); widget.healCrossV:SetBlendMode("ADD")
widget.healCrossV:SetSize(11, 32); widget.healCrossV:SetPoint("CENTER")

widget.close = CreateFrame("Button", nil, widget); widget.close:SetSize(24, 24); widget.close:SetPoint("TOPRIGHT", -5, -5)
widget.close:SetFontString(widget.close:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")); widget.close:GetFontString():SetAllPoints(); widget.close:SetText("X")
widget.close:SetScript("OnClick", function() widget.expires = nil; widget.editMode = false; widget:Hide() end)
widget.close:SetScript("OnEnter", function(self) self:GetFontString():SetTextColor(1, 1, 1) end)
widget.close:SetScript("OnLeave", function(self) self:GetFontString():SetTextColor(1, 0.75, 0.18) end)

widget.bar = CreateFrame("StatusBar", nil, widget); widget.bar:SetPoint("BOTTOMLEFT", 112, 10); widget.bar:SetPoint("BOTTOMRIGHT", -21, 10); widget.bar:SetHeight(4)
widget.bar:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar"); widget.bar:SetStatusBarColor(0.2, 1, 0.45); widget.bar:SetMinMaxValues(0, 1)
widget.barBg = widget.bar:CreateTexture(nil, "BACKGROUND"); widget.barBg:SetTexture("Interface\\Buttons\\WHITE8X8"); widget.barBg:SetAllPoints(); widget.barBg:SetVertexColor(0.08, 0.12, 0.04, 0.9)

-- Вертикальная композиция награды за спасение.
widget.inner:ClearAllPoints(); widget.inner:SetSize(370, 470); widget.inner:SetPoint("CENTER", 0, -2); widget.inner:SetVertexColor(0.005, 0.018, 0.035, 0.06)
widget.topAccent:ClearAllPoints(); widget.topAccent:SetSize(72, 2); widget.topAccent:SetPoint("TOPLEFT", 32, -111)
widget.bottomAccent:ClearAllPoints(); widget.bottomAccent:SetSize(72, 2); widget.bottomAccent:SetPoint("TOPRIGHT", -32, -111)

widget.title:ClearAllPoints(); widget.title:SetPoint("TOP", 0, -35); widget.title:SetWidth(390); widget.title:SetJustifyH("CENTER")
widget.title:SetFont("Interface\\AddOns\\DamageLife\\Fonts\\FritzQuadrataCyri-Regular.ttf", 32, "OUTLINE")
widget.subtitle:ClearAllPoints(); widget.subtitle:SetPoint("TOP", 0, -82); widget.subtitle:SetWidth(250); widget.subtitle:SetJustifyH("CENTER")
widget.subtitle:SetFont("Interface\\AddOns\\DamageLife\\Fonts\\FritzQuadrataCyri-Regular.ttf", 18, "OUTLINE")

widget.portraitFrame:ClearAllPoints(); widget.portraitFrame:SetSize(178, 178); widget.portraitFrame:SetPoint("TOP", 0, -132)
widget.portraitFrame:SetBackdropBorderColor(1, 0.72, 0.12, 1)
widget.badge:Hide(); widget.pulse:Hide()

widget.name:ClearAllPoints(); widget.name:SetPoint("TOP", 0, -350); widget.name:SetWidth(290); widget.name:SetJustifyH("CENTER")
widget.name:SetFont("Interface\\AddOns\\DamageLife\\Fonts\\FritzQuadrataCyri-Regular.ttf", 25, "OUTLINE")
widget.bar:ClearAllPoints(); widget.bar:SetPoint("TOP", 0, -396); widget.bar:SetSize(286, 3)
widget.close:ClearAllPoints(); widget.close:SetPoint("TOPRIGHT", -8, -8)
widget.close:Hide()

widget.healFrame:ClearAllPoints(); widget.healFrame:SetSize(42, 42); widget.healFrame:SetPoint("TOP", 0, -411)
widget.healGlow:ClearAllPoints(); widget.healGlow:SetSize(100, 100); widget.healGlow:SetPoint("CENTER", widget.healFrame, "CENTER", 0, 0)

widget.stageGlow = widget:CreateTexture(nil, "BACKGROUND"); widget.stageGlow:SetTexture("Interface\\Cooldown\\star4"); widget.stageGlow:SetBlendMode("ADD")
widget.stageGlow:SetSize(420, 420); widget.stageGlow:SetPoint("CENTER", widget.portraitFrame, "CENTER", 0, 0); widget.stageGlow:SetVertexColor(0.02, 0.20, 0.55, 0.20)
widget.portraitGlow = widget:CreateTexture(nil, "BORDER"); widget.portraitGlow:SetTexture("Interface\\Cooldown\\star4"); widget.portraitGlow:SetBlendMode("ADD")
widget.portraitGlow:SetSize(260, 260); widget.portraitGlow:SetPoint("CENTER", widget.portraitFrame, "CENTER", 0, 0); widget.portraitGlow:SetVertexColor(1, 0.55, 0.04, 0.68)
widget.portraitHalo = widget:CreateTexture(nil, "OVERLAY"); widget.portraitHalo:SetTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight"); widget.portraitHalo:SetBlendMode("ADD")
widget.portraitHalo:SetSize(210, 210); widget.portraitHalo:SetPoint("CENTER", widget.portraitFrame, "CENTER", 0, 0); widget.portraitHalo:SetVertexColor(1, 0.70, 0.10, 0.95)
widget.portraitRing = widget.portraitFrame:CreateTexture(nil, "OVERLAY"); widget.portraitRing:SetTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight"); widget.portraitRing:SetBlendMode("ADD")
widget.portraitRing:SetSize(202, 202); widget.portraitRing:SetPoint("CENTER", widget.portraitFrame, "CENTER", 0, 0); widget.portraitRing:SetVertexColor(1, 0.74, 0.12, 1)

widget.emblemLeft = widget:CreateTexture(nil, "ARTWORK"); widget.emblemLeft:SetTexture("Interface\\Buttons\\WHITE8X8"); widget.emblemLeft:SetBlendMode("ADD")
widget.emblemLeft:SetSize(72, 2); widget.emblemLeft:SetPoint("RIGHT", widget.subtitle, "LEFT", -10, 0)
widget.emblemRight = widget:CreateTexture(nil, "ARTWORK"); widget.emblemRight:SetTexture("Interface\\Buttons\\WHITE8X8"); widget.emblemRight:SetBlendMode("ADD")
widget.emblemRight:SetSize(72, 2); widget.emblemRight:SetPoint("LEFT", widget.subtitle, "RIGHT", 10, 0)

widget.wingRays = {}
local wingRayLayout = {
    { "LEFT",  -12,  28, 88, 3 }, { "LEFT",  -20,  13, 120, 2 }, { "LEFT",  -18,  -4, 135, 3 },
    { "LEFT",  -12, -22, 105, 2 }, { "LEFT",   -7, -39, 72, 2 },
    { "RIGHT",  12,  28, 88, 3 }, { "RIGHT",  20,  13, 120, 2 }, { "RIGHT",  18,  -4, 135, 3 },
    { "RIGHT",  12, -22, 105, 2 }, { "RIGHT",   7, -39, 72, 2 },
}
for i, ray in ipairs(wingRayLayout) do
    local texture = widget:CreateTexture(nil, "BORDER"); texture:SetTexture("Interface\\Buttons\\WHITE8X8"); texture:SetBlendMode("ADD")
    texture:SetSize(ray[4], ray[5])
    if ray[1] == "LEFT" then
        texture:SetPoint("RIGHT", widget.portraitFrame, "LEFT", ray[2], ray[3])
    else
        texture:SetPoint("LEFT", widget.portraitFrame, "RIGHT", ray[2], ray[3])
    end
    texture:SetVertexColor(1, 0.55, 0.04, 0.42)
    widget.wingRays[i] = texture
end

widget.namePlate = widget:CreateTexture(nil, "BORDER"); widget.namePlate:SetTexture("Interface\\Buttons\\WHITE8X8")
widget.namePlate:SetSize(310, 62); widget.namePlate:SetPoint("CENTER", widget.name, "CENTER", 0, 0); widget.namePlate:SetVertexColor(0.01, 0.04, 0.09, 0.92)
widget.nameTop = widget:CreateTexture(nil, "ARTWORK"); widget.nameTop:SetTexture("Interface\\Buttons\\WHITE8X8"); widget.nameTop:SetSize(300, 2); widget.nameTop:SetPoint("TOP", widget.namePlate, "TOP", 0, 0)
widget.nameBottom = widget:CreateTexture(nil, "ARTWORK"); widget.nameBottom:SetTexture("Interface\\Buttons\\WHITE8X8"); widget.nameBottom:SetSize(300, 2); widget.nameBottom:SetPoint("BOTTOM", widget.namePlate, "BOTTOM", 0, 0)
widget.nameLeft = widget:CreateTexture(nil, "ARTWORK"); widget.nameLeft:SetTexture("Interface\\Buttons\\WHITE8X8"); widget.nameLeft:SetSize(2, 54); widget.nameLeft:SetPoint("LEFT", widget.namePlate, "LEFT", 0, 0)
widget.nameRight = widget:CreateTexture(nil, "ARTWORK"); widget.nameRight:SetTexture("Interface\\Buttons\\WHITE8X8"); widget.nameRight:SetSize(2, 54); widget.nameRight:SetPoint("RIGHT", widget.namePlate, "RIGHT", 0, 0)

widget.particles = {}
local particleLayout = {
    { -165, -165, 10 }, { -145, -215, 7 }, { -158, -275, 12 }, { -115, -315, 8 },
    { 160, -175, 9 }, { 142, -225, 12 }, { 164, -285, 7 }, { 112, -320, 10 },
    { -92, -140, 6 }, { 88, -142, 7 }, { -78, -325, 9 }, { 82, -330, 6 },
}
for i, particle in ipairs(particleLayout) do
    local texture = widget:CreateTexture(nil, "OVERLAY"); texture:SetTexture("Interface\\Cooldown\\star4"); texture:SetBlendMode("ADD")
    texture:SetSize(particle[3], particle[3]); texture:SetPoint("TOP", particle[1], particle[2]); texture:SetVertexColor(1, 0.62, 0.08, 0.8)
    widget.particles[i] = texture
end
widget.bottomFlare = widget:CreateTexture(nil, "OVERLAY"); widget.bottomFlare:SetTexture("Interface\\Cooldown\\star4"); widget.bottomFlare:SetBlendMode("ADD")
widget.bottomFlare:SetSize(88, 88); widget.bottomFlare:SetPoint("CENTER", widget.healFrame, "CENTER", 0, 0); widget.bottomFlare:SetVertexColor(1, 0.55, 0.04, 0.75)

-- Finished reward artwork.  The generated textures share one canvas: glow behind,
-- live character model in the opening, ornamental frame and dynamic text above it.
widget:SetSize(512, 512)
widget:SetBackdropColor(0, 0, 0, 0); widget:SetBackdropBorderColor(0, 0, 0, 0)
widget.inner:Hide(); widget.topAccent:Hide(); widget.bottomAccent:Hide()
widget.badge:Hide(); widget.pulse:Hide(); widget.healFrame:Hide(); widget.healGlow:Hide(); widget.close:Hide(); widget.bar:Hide()
widget.stageGlow:Hide(); widget.portraitGlow:Hide(); widget.portraitHalo:Hide(); widget.portraitRing:Hide(); widget.bottomFlare:Hide()
widget.emblemLeft:Hide(); widget.emblemRight:Hide(); widget.namePlate:Hide(); widget.nameTop:Hide(); widget.nameBottom:Hide(); widget.nameLeft:Hide(); widget.nameRight:Hide()
for _, ray in ipairs(widget.wingRays) do ray:Hide() end
for _, particle in ipairs(widget.particles) do particle:Hide() end

widget.rewardGlow = widget:CreateTexture(nil, "BACKGROUND")
widget.rewardGlow:SetTexture("Interface\\AddOns\\DamageLife\\Textures\\SaveRewardGlow.tga")
widget.rewardGlow:SetBlendMode("ADD"); widget.rewardGlow:SetSize(375, 375); widget.rewardGlow:SetPoint("TOP", 0, -19); widget.rewardGlow:SetAlpha(0.24)

widget.portraitFrame:ClearAllPoints(); widget.portraitFrame:SetSize(130, 130); widget.portraitFrame:SetPoint("TOP", 0, -137)
widget.portraitFrame:SetBackdropColor(0, 0, 0, 0); widget.portraitFrame:SetBackdropBorderColor(0, 0, 0, 0)
widget.icon:ClearAllPoints(); widget.icon:SetPoint("TOPLEFT", 7, -7); widget.icon:SetPoint("BOTTOMRIGHT", -7, 7); widget.icon:Hide()
widget.characterModel = CreateFrame("PlayerModel", nil, widget.portraitFrame)
widget.characterModel:SetPoint("TOPLEFT", 5, -5); widget.characterModel:SetPoint("BOTTOMRIGHT", -5, 5)
widget.characterModel:SetFrameLevel(widget.portraitFrame:GetFrameLevel() + 1); widget.characterModel:Hide()
widget.characterModel:SetScript("OnShow", function(self) if self.SetCamera then self:SetCamera(0) end end)

-- The classic 3D portrait camera is inconsistent for several races on 3.3.5
-- clients.  Build a circular portrait from narrow 2D portrait slices instead.
widget.portraitSlices = {}
do
    local sliceCount, radius = 24, 56
    local sliceHeight = radius * 2 / sliceCount
    for i = 1, sliceCount do
        local yMid = -radius + (i - 0.5) * sliceHeight
        local halfWidth = math.sqrt(math.max(0, radius * radius - yMid * yMid))
        local texture = widget.portraitFrame:CreateTexture(nil, "ARTWORK")
        texture:SetSize(halfWidth * 2 + 1, sliceHeight + 1)
        texture:SetPoint("TOP", widget.portraitFrame, "CENTER", 0, radius - (i - 1) * sliceHeight)
        texture.portraitLeft = 0.5 - (halfWidth / radius) * 0.42
        texture.portraitRight = 0.5 + (halfWidth / radius) * 0.42
        texture.portraitTop = 0.08 + ((i - 1) / sliceCount) * 0.84
        texture.portraitBottom = 0.08 + (i / sliceCount) * 0.84
        texture:Hide()
        widget.portraitSlices[i] = texture
    end
end

widget.portraitDisc = widget.portraitFrame:CreateTexture(nil, "BACKGROUND")
widget.portraitDisc:SetTexture("Interface\\Minimap\\UI-Minimap-Background")
widget.portraitDisc:SetSize(124, 124); widget.portraitDisc:SetPoint("CENTER")
widget.portraitDisc:SetVertexColor(0.01, 0.025, 0.05, 0.96)
widget.faceIconFrame = CreateFrame("Frame", nil, widget.portraitFrame)
widget.faceIconFrame:SetSize(122, 122); widget.faceIconFrame:SetPoint("CENTER")
widget.faceIconFrame:SetFrameLevel(widget.portraitFrame:GetFrameLevel() + 1)
widget.faceIconFrame:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", edgeSize = 9, insets = { left = 3, right = 3, top = 3, bottom = 3 } })
widget.faceIconFrame:SetBackdropColor(0.005, 0.01, 0.02, 1); widget.faceIconFrame:SetBackdropBorderColor(1, 0.67, 0.08, 1)
widget.faceIcon = widget.faceIconFrame:CreateTexture(nil, "ARTWORK")
widget.faceIcon:SetPoint("TOPLEFT", 5, -5); widget.faceIcon:SetPoint("BOTTOMRIGHT", -5, 5)
widget.faceIcon:SetTexCoord(0.08, 0.92, 0.08, 0.92)

widget.artLayer = CreateFrame("Frame", nil, widget); widget.artLayer:SetAllPoints(widget); widget.artLayer:SetFrameLevel(widget.portraitFrame:GetFrameLevel() + 3)
-- Keep the portrait at its readable size and tighten the ornamental artwork
-- around it.  This makes the golden ring cover the unused portrait edges.
widget.rewardFront = widget.artLayer:CreateTexture(nil, "ARTWORK"); widget.rewardFront:SetSize(336, 336); widget.rewardFront:SetPoint("TOP", 0, -66)
widget.rewardFront:SetTexture("Interface\\AddOns\\DamageLife\\Textures\\SaveRewardFront.tga")

widget.title:Hide(); widget.subtitle:Hide(); widget.name:Hide()
widget.textLayer = CreateFrame("Frame", nil, widget); widget.textLayer:SetAllPoints(widget); widget.textLayer:SetFrameLevel(widget.artLayer:GetFrameLevel() + 1)
widget.title = widget.textLayer:CreateFontString(nil, "OVERLAY"); widget.title:SetPoint("TOP", 0, -22); widget.title:SetWidth(470); widget.title:SetJustifyH("CENTER")
widget.title:SetFont("Interface\\AddOns\\DamageLife\\Fonts\\FritzQuadrataCyri-Regular.ttf", 32, "OUTLINE"); widget.title:SetShadowColor(0, 0, 0, 1); widget.title:SetShadowOffset(2, -2)
widget.subtitle = widget.textLayer:CreateFontString(nil, "OVERLAY"); widget.subtitle:SetPoint("TOP", 0, -70); widget.subtitle:SetWidth(390); widget.subtitle:SetJustifyH("CENTER")
widget.subtitle:SetFont("Interface\\AddOns\\DamageLife\\Fonts\\FritzQuadrataCyri-Regular.ttf", 18, "OUTLINE"); widget.subtitle:SetShadowColor(0, 0, 0, 1); widget.subtitle:SetShadowOffset(1, -1)
widget.name = widget.textLayer:CreateFontString(nil, "OVERLAY"); widget.name:SetPoint("TOP", 0, -267); widget.name:SetWidth(215); widget.name:SetJustifyH("CENTER")
widget.categoryIcon = widget.textLayer:CreateTexture(nil, "OVERLAY")
widget.categoryIcon:SetSize(52, 52); widget.categoryIcon:SetPoint("TOP", 0, -82); widget.categoryIcon:Hide()
widget.categoryIcon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
widget.name:SetFont("Interface\\AddOns\\DamageLife\\Fonts\\FritzQuadrataCyri-Regular.ttf", 27, "OUTLINE"); widget.name:SetShadowColor(0, 0, 0, 1); widget.name:SetShadowOffset(2, -2)
widget:RegisterForDrag("LeftButton")
widget:SetScript("OnDragStart", function(self) if not DamageLifeDB.widgetLocked then self:StartMoving() end end)
widget:SetScript("OnDragStop", function(self)
    self:StopMovingOrSizing()
    local point, _, relativePoint, x, y = self:GetPoint()
    DamageLifeDB.widgetPoint, DamageLifeDB.widgetRelativePoint = point or "CENTER", relativePoint or "CENTER"
    DamageLifeDB.widgetX, DamageLifeDB.widgetY = x or 0, y or 0
end)
widget:SetScript("OnUpdate", function(self)
    if not self.expires then return end
    local remaining = self.expires - GetTime()
    self.bar:SetValue(math.max(0, remaining / math.max(1, self.duration or 4)))
    local now = GetTime(); local age = now - (self.animationStart or now)
    local intro = math.min(1, math.max(0, age / 0.35)); local outro = remaining < 0.65 and math.max(0, remaining / 0.65) or 1
    self:SetAlpha(intro * outro)
    self.portraitFrame:SetScale(0.88 + intro * 0.12); self.healFrame:SetScale(0.84 + intro * 0.16)
    local breathe = (math.sin(now * 3.2) + 1) * 0.5
    self.healGlow:SetSize(88 + breathe * 16, 88 + breathe * 16); self.healGlow:SetAlpha(0.55 + breathe * 0.35)
    self.portraitGlow:SetSize(250 + breathe * 20, 250 + breathe * 20); self.portraitGlow:SetAlpha(0.45 + breathe * 0.32)
    self.stageGlow:SetAlpha(0.12 + breathe * 0.08); self.bottomFlare:SetAlpha(0.45 + breathe * 0.38)
    for i, ray in ipairs(self.wingRays) do ray:SetAlpha(0.24 + breathe * 0.22 + (i % 2) * 0.05) end
    for i, particle in ipairs(self.particles) do particle:SetAlpha(0.18 + 0.72 * math.abs(math.sin(now * (1.6 + i * 0.07) + i))) end
    self.rewardGlow:SetAlpha(0.14 + breathe * 0.16)
    self.rewardGlow:SetSize(371 + breathe * 7, 371 + breathe * 7)
    if remaining <= 0 then self.expires = nil; self:Hide() end
end)

local function setWidgetAccent(red, green, blue)
    red, green, blue = red or 0.2, green or 1, blue or 0.45
    widget.bar:SetStatusBarColor(red, green, blue)
    widget.healGlow:SetVertexColor(red, green, blue, 0.8)
    widget.healFrame:SetBackdropBorderColor(red, green, blue, 1)
    widget.healCrossH:SetVertexColor(red, green, blue, 1); widget.healCrossV:SetVertexColor(red, green, blue, 1)
    widget.pulseGlow:SetVertexColor(red, green, blue, 0.5); widget.pulseCore:SetVertexColor(red, green, blue, 0.95); widget.pulseSpark:SetVertexColor(red, green, blue, 1)
    for _, dot in ipairs(widget.pulseDots) do dot:SetVertexColor(red, green, blue, 0.8) end
    widget.emblemLeft:SetVertexColor(red, green, blue, 0.75); widget.emblemRight:SetVertexColor(red, green, blue, 0.75)
    widget.topAccent:SetVertexColor(red, green, blue, 0.85); widget.bottomAccent:SetVertexColor(red, green, blue, 0.85)
    widget.nameTop:SetVertexColor(red, green, blue, 1); widget.nameBottom:SetVertexColor(red, green, blue, 1)
    widget.nameLeft:SetVertexColor(red, green, blue, 0.8); widget.nameRight:SetVertexColor(red, green, blue, 0.8)
    widget.portraitGlow:SetVertexColor(red, green, blue, 0.68); widget.portraitRing:SetVertexColor(red, green, blue, 1)
    widget.bottomFlare:SetVertexColor(red, green, blue, 0.75)
    for _, ray in ipairs(widget.wingRays) do ray:SetVertexColor(red, green, blue, 0.42) end
end

local function setupWidget()
    widget:ClearAllPoints(); widget:SetPoint(DamageLifeDB.widgetPoint or "CENTER", UIParent, DamageLifeDB.widgetRelativePoint or "CENTER", DamageLifeDB.widgetX, DamageLifeDB.widgetY)
    widget:SetScale(DamageLifeDB.widgetScale or 1)
    setWidgetAccent(DamageLifeDB.widgetR or 0.2, DamageLifeDB.widgetG or 1, DamageLifeDB.widgetB or 0.45)
    widget:EnableMouse(not DamageLifeDB.widgetLocked)
end

-- Компактные окна анализа целей.
-- Каждый слот показывает одну вражескую цель. Количество и позиции окон
-- настраиваются глобально через «Общие -> Окна целей».
local TARGET_WINDOW_MAX = 5
local targetWindows = {}
local targetWindowElapsed = 0
local targetWindowPreview = false

local targetSpecData
local targetDefenseHistory = {}
local targetObservedSpells = {}
local targetObservedSpellNames = {}

-- WotLK 3.3.5a не даёт прямого API для спека вражеского игрока.
-- Поэтому сначала пытаемся определить специализацию по Inspect/талантам,
-- а уже затем используем наблюдаемые способности как быстрый fallback.
local targetInspectedSpecs = {}
local targetInspectQueue = {}
local targetInspectQueued = {}
local targetInspectLastRequest = 0
local TARGET_INSPECT_INTERVAL = 1.25
local TARGET_INSPECT_MIN_POINTS = 5

local targetSpecByTalentTab = {
    PRIEST = { [1] = "DISCIPLINE", [2] = "HOLY", [3] = "SHADOW" },
    PALADIN = { [1] = "HOLY", [2] = "PROTECTION", [3] = "RETRIBUTION" },
    DRUID = { [1] = "BALANCE", [2] = "FERAL", [3] = "RESTORATION" },
    SHAMAN = { [1] = "ELEMENTAL", [2] = "ENHANCEMENT", [3] = "RESTORATION" },
    WARRIOR = { [1] = "ARMS", [2] = "FURY", [3] = "PROTECTION" },
    HUNTER = { [1] = "BEAST_MASTERY", [2] = "MARKSMANSHIP", [3] = "SURVIVAL" },
    ROGUE = { [1] = "ASSASSINATION", [2] = "COMBAT", [3] = "SUBTLETY" },
    MAGE = { [1] = "ARCANE", [2] = "FIRE", [3] = "FROST" },
    WARLOCK = { [1] = "AFFLICTION", [2] = "DEMONOLOGY", [3] = "DESTRUCTION" },
    DEATHKNIGHT = { [1] = "BLOOD", [2] = "FROST", [3] = "UNHOLY" },
}

local function targetWindowStoreInspectedSpec(guid, classToken, spec)
    if not guid or not classToken or not spec then return end
    if targetSpecData[classToken] and targetSpecData[classToken][spec] then
        targetInspectedSpecs[guid] = { classToken = classToken, spec = spec, time = GetTime() }
    end
end

local function targetWindowReadInspectSpec(guid, classToken)
    if not guid or not classToken or not GetTalentTabInfo then return nil end
    local tabs = targetSpecByTalentTab[classToken]
    if not tabs then return nil end
    local bestTab, bestPoints = nil, -1
    local group = 1
    if GetActiveTalentGroup then
        local ok, value = pcall(GetActiveTalentGroup, true)
        if ok and tonumber(value) then group = tonumber(value) end
    end
    for tab = 1, 3 do
        local ok, _, _, _, _, points = pcall(GetTalentTabInfo, tab, true, false, group)
        points = ok and tonumber(points) or 0
        if points > bestPoints then
            bestPoints, bestTab = points, tab
        end
    end
    if bestTab and bestPoints >= TARGET_INSPECT_MIN_POINTS then
        local spec = tabs[bestTab]
        targetWindowStoreInspectedSpec(guid, classToken, spec)
        return spec
    end
    return nil
end

local function targetWindowQueueInspect(unit, guid, classToken)
    if not unit or not guid or not classToken or not UnitIsPlayer(unit) then return end
    if not NotifyInspect then return end
    if targetInspectedSpecs[guid] then return end
    if targetInspectQueued[guid] then return end
    targetInspectQueued[guid] = true
    targetInspectQueue[#targetInspectQueue + 1] = { unit = unit, guid = guid, classToken = classToken }
end

local function targetWindowProcessInspectQueue()
    if not NotifyInspect or not UnitIsPlayer then return end
    if GetTime() - targetInspectLastRequest < TARGET_INSPECT_INTERVAL then return end
    local item = table.remove(targetInspectQueue, 1)
    if not item then return end
    targetInspectQueued[item.guid] = nil
    if not UnitExists(item.unit) or UnitGUID(item.unit) ~= item.guid then return end
    if CanInspect and not CanInspect(item.unit) then return end
    if CheckInteractDistance and not CheckInteractDistance(item.unit, 1) then return end
    targetInspectLastRequest = GetTime()
    local ok = pcall(NotifyInspect, item.unit)
    if not ok then
        targetInspectLastRequest = GetTime()
    end
end

local targetDefenseCooldowns = {
    [871] = 300, [12975] = 180, [23920] = 10,
    [498] = 60, [642] = 300, [1022] = 180, [6940] = 120,
    [5277] = 120, [31224] = 90, [1856] = 120,
    [19263] = 90, [45438] = 300, [66] = 180,
    [47585] = 120, [33206] = 180, [47788] = 180,
    [48707] = 60, [47241] = 30, [30823] = 60,
    [22812] = 60, [61336] = 180,
    [48792] = 120, [51052] = 120, [48743] = 120,
}

-- Спек-зависимые защитные способности WotLK 3.3.5a.
-- Если спек ещё не определён, используется только общий классический набор.
targetSpecData = {
    PRIEST = {
        SHADOW = { role = "DAMAGER", label = "SHADOW", defensives = {47585}, burst = {34433} },
        DISCIPLINE = { role = "HEALER", label = "DISCIPLINE", defensives = {33206, 47788}, burst = {33206, 10060} },
        HOLY = { role = "HEALER", label = "HOLY", defensives = {47788}, burst = {20216, 31842} },
    },
    PALADIN = {
        HOLY = { role = "HEALER", label = "HOLY", defensives = {498, 642, 1022, 6940}, burst = {20216, 31842, 31884} },
        RETRIBUTION = { role = "DAMAGER", label = "RETRIBUTION", defensives = {498, 1022, 6940}, burst = {31884} },
        PROTECTION = { role = "DAMAGER", label = "PROTECTION", defensives = {498, 642, 1022}, burst = {31884} },
    },
    DRUID = {
        RESTORATION = { role = "HEALER", label = "RESTORATION", defensives = {22812, 61336}, burst = {17116} },
        BALANCE = { role = "RANGED", label = "BALANCE", defensives = {22812, 61336}, burst = {48505, 33831} },
        FERAL = { role = "DAMAGER", label = "FERAL", defensives = {22812, 61336}, burst = {50334} },
    },
    SHAMAN = {
        RESTORATION = { role = "HEALER", label = "RESTORATION", defensives = {30823}, burst = {2825, 16190} },
        ELEMENTAL = { role = "RANGED", label = "ELEMENTAL", defensives = {30823}, burst = {2825, 16166} },
        ENHANCEMENT = { role = "DAMAGER", label = "ENHANCEMENT", defensives = {30823}, burst = {2825, 51533} },
    },
    WARRIOR = {
        ARMS = { role = "DAMAGER", label = "ARMS", defensives = {871, 23920}, burst = {1719, 46924} },
        FURY = { role = "DAMAGER", label = "FURY", defensives = {871, 23920}, burst = {12292, 1719} },
        PROTECTION = { role = "DAMAGER", label = "PROTECTION", defensives = {871, 12975, 23920}, burst = {1719} },
    },
    HUNTER = {
        MARKSMANSHIP = { role = "RANGED", label = "MARKSMANSHIP", defensives = {19263}, burst = {3045, 23989} },
        SURVIVAL = { role = "RANGED", label = "SURVIVAL", defensives = {19263}, burst = {3045, 23989} },
        BEAST_MASTERY = { role = "RANGED", label = "BEAST MASTERY", defensives = {19263}, burst = {19574, 3045} },
    },
    ROGUE = {
        ASSASSINATION = { role = "DAMAGER", label = "ASSASSINATION", defensives = {5277, 31224, 1856}, burst = {13750, 14177} },
        COMBAT = { role = "DAMAGER", label = "COMBAT", defensives = {5277, 31224, 1856}, burst = {13750, 51690} },
        SUBTLETY = { role = "DAMAGER", label = "SUBTLETY", defensives = {5277, 31224, 1856}, burst = {51713, 14183} },
    },
    MAGE = {
        FROST = { role = "RANGED", label = "FROST", defensives = {45438, 66}, burst = {12472, 12043} },
        FIRE = { role = "RANGED", label = "FIRE", defensives = {45438, 66}, burst = {11129, 30482} },
        ARCANE = { role = "RANGED", label = "ARCANE", defensives = {45438, 66}, burst = {12042, 12472} },
    },
    WARLOCK = {
        AFFLICTION = { role = "RANGED", label = "AFFLICTION", defensives = {48707, 47241}, burst = {17962, 47847} },
        DEMONOLOGY = { role = "RANGED", label = "DEMONOLOGY", defensives = {48707, 47241}, burst = {59672, 47193} },
        DESTRUCTION = { role = "RANGED", label = "DESTRUCTION", defensives = {48707, 47241}, burst = {47847, 47843} },
    },
    DEATHKNIGHT = {
        BLOOD = { role = "DAMAGER", label = "BLOOD", defensives = {48792, 51052, 48743}, burst = {49016, 47568} },
        FROST = { role = "DAMAGER", label = "FROST", defensives = {48792, 51052, 48743}, burst = {49016, 47568} },
        UNHOLY = { role = "DAMAGER", label = "UNHOLY", defensives = {48792, 51052, 48743}, burst = {49016, 47568} },
    },
}

local targetClassDefensives = {
    WARRIOR = {871, 12975, 23920}, PALADIN = {498, 642, 1022, 6940},
    HUNTER = {19263}, ROGUE = {5277, 31224, 1856}, MAGE = {45438, 66},
    PRIEST = {47585, 33206, 47788}, WARLOCK = {48707, 47241}, SHAMAN = {30823},
    DRUID = {22812, 61336}, DEATHKNIGHT = {48792, 51052, 48743},
}

local targetBurstCooldowns = {
    [1719]=180, [46924]=90, [12292]=120, [31884]=180, [19574]=60,
    [3045]=300, [23989]=180, [13750]=180, [51690]=120, [51713]=60,
    [12472]=180, [12042]=120, [11129]=120, [59672]=120, [47193]=120,
    [50334]=180, [48505]=90, [33831]=180, [2825]=300, [51533]=180,
    [16166]=180, [16190]=180, [49016]=180, [47568]=180, [17962]=15,
    [47847]=12, [47843]=10, [20216]=120, [31842]=180, [10060]=120,
}

local targetDefensiveNames, targetDefensiveIcons = {}, {}
local targetBurstNames, targetBurstIcons = {}, {}
local function cacheSpell(spellId, names, icons)
    local name, _, icon = GetSpellInfo(spellId)
    names[spellId] = name or ("Spell " .. spellId)
    icons[spellId] = icon or "Interface\\Icons\\INV_Misc_QuestionMark"
end
for _, ids in pairs(targetClassDefensives) do for _, id in ipairs(ids) do cacheSpell(id, targetDefensiveNames, targetDefensiveIcons) end end
for _, classData in pairs(targetSpecData) do
    for _, specData in pairs(classData) do
        for _, id in ipairs(specData.defensives or {}) do cacheSpell(id, targetDefensiveNames, targetDefensiveIcons) end
        for _, id in ipairs(specData.burst or {}) do cacheSpell(id, targetBurstNames, targetBurstIcons) end
    end
end

local classColors = {
    WARRIOR={0.78,0.61,0.43}, PALADIN={0.96,0.55,0.73}, HUNTER={0.67,0.83,0.45},
    ROGUE={1,0.96,0.41}, PRIEST={1,1,1}, SHAMAN={0.14,0.44,1}, MAGE={0.25,0.78,0.92},
    WARLOCK={0.53,0.53,0.93}, DRUID={1,0.49,0.04}, DEATHKNIGHT={0.77,0.12,0.23}
}

local function targetWindowDefaultPosition(index)
    local positions = {
        { "CENTER", "CENTER", -420, -120 }, { "CENTER", "CENTER", -210, -120 },
        { "CENTER", "CENTER", 0, -120 }, { "CENTER", "CENTER", 210, -120 },
        { "CENTER", "CENTER", 420, -120 },
    }
    local p = positions[index] or positions[1]
    return p[1], p[2], p[3], p[4]
end

local function targetWindowGetPosition(index)
    DamageLifeDB.targetWindowPositions = DamageLifeDB.targetWindowPositions or {}
    local p = DamageLifeDB.targetWindowPositions[index]
    if type(p) ~= "table" then
        local point, relativePoint, x, y = targetWindowDefaultPosition(index)
        p = { point = point, relativePoint = relativePoint, x = x, y = y }
        DamageLifeDB.targetWindowPositions[index] = p
    end
    return p
end

local function targetWindowApplyPosition(frame, index)
    local p = targetWindowGetPosition(index)
    frame:ClearAllPoints()
    frame:SetPoint(p.point or "CENTER", UIParent, p.relativePoint or "CENTER", p.x or 0, p.y or -120)
    frame:SetScale(DamageLifeDB.targetWindowScale or 0.90)
end

local function targetWindowSavePosition(frame, index)
    local point, _, relativePoint, x, y = frame:GetPoint(1)
    DamageLifeDB.targetWindowPositions = DamageLifeDB.targetWindowPositions or {}
    DamageLifeDB.targetWindowPositions[index] = {
        point = point or "CENTER", relativePoint = relativePoint or "CENTER", x = x or 0, y = y or -120
    }
end

local function targetWindowRoleData(classToken, spec)
    local classData = targetSpecData[classToken]
    local data = classData and classData[spec]
    if data then return data end
    if classToken == "PRIEST" or classToken == "PALADIN" or classToken == "DRUID" or classToken == "SHAMAN" then
        return { role = "UNKNOWN", label = spec or "UNKNOWN", defensives = {}, burst = {} }
    end
    return { role = "UNKNOWN", label = spec or "UNKNOWN", defensives = {}, burst = {} }
end

local function targetWindowObserveSpell(guid, spellId, spellName)
    if not guid or not spellId then return end
    targetObservedSpells[guid] = targetObservedSpells[guid] or {}
    targetObservedSpells[guid][spellId] = GetTime()
    targetObservedSpellNames[guid] = targetObservedSpellNames[guid] or {}
    targetObservedSpellNames[guid][spellId] = spellName or GetSpellInfo(spellId) or ("Spell " .. spellId)
end

local function targetWindowHasObserved(guid, ids)
    local observed = targetObservedSpells[guid]
    if not observed then return false end
    for _, id in ipairs(ids or {}) do if observed[id] then return true end end
    return false
end

local function targetWindowDetectSpec(unit, guid, classToken)
    local inspected = targetInspectedSpecs[guid]
    if inspected and inspected.classToken == classToken then
        return inspected.spec
    end
    -- Попытка получить спек из Inspect происходит асинхронно.
    -- Здесь только ставим цель в очередь; результат придёт через INSPECT_READY.
    targetWindowQueueInspect(unit, guid, classToken)
    local observed = targetObservedSpells[guid] or {}
    local auras = {}
    for i = 1, 40 do
        local name, _, _, _, _, _, _, _, _, spellId = UnitAura(unit, i, "HELPFUL")
        if not name then break end
        if spellId then auras[spellId] = true end
    end

    local function has(ids)
        for _, id in ipairs(ids) do if observed[id] or auras[id] then return true end end
        return false
    end

    if classToken == "PRIEST" then
        if has({47585, 48160, 48127, 48156}) then return "SHADOW" end
        if has({33206, 10060}) then return "DISCIPLINE" end
        if has({47788, 64843, 64901}) then return "HOLY" end
    elseif classToken == "PALADIN" then
        if has({31884, 53385, 35395}) then return "RETRIBUTION" end
        if has({498, 47788, 53563}) then return "HOLY" end
        if has({642, 498, 6940}) then return "PROTECTION" end
    elseif classToken == "DRUID" then
        if has({50334, 49800, 48572}) then return "FERAL" end
        if has({48505, 48469, 48465}) then return "BALANCE" end
        if has({17116, 48451, 53201}) then return "RESTORATION" end
    elseif classToken == "SHAMAN" then
        if has({51533, 58804, 17364}) then return "ENHANCEMENT" end
        if has({16166, 60043, 49238}) then return "ELEMENTAL" end
        if has({16190, 2825, 49284}) then return "RESTORATION" end
    elseif classToken == "WARRIOR" then
        if has({47486, 7384, 12294}) then return "ARMS" end
        if has({46924, 23881, 47465}) then return "FURY" end
        if has({871, 12975, 23920}) then return "PROTECTION" end
    elseif classToken == "HUNTER" then
        if has({19574, 49050, 49052}) then return "BEAST_MASTERY" end
        if has({49050, 34490, 3045}) then return "MARKSMANSHIP" end
        if has({60053, 19306, 3045}) then return "SURVIVAL" end
    elseif classToken == "ROGUE" then
        if has({51713, 16511, 48668}) then return "SUBTLETY" end
        if has({51690, 13750, 48638}) then return "COMBAT" end
        if has({48666, 48668, 57992}) then return "ASSASSINATION" end
    elseif classToken == "MAGE" then
        if has({12472, 42914, 44572}) then return "FROST" end
        if has({11129, 42833, 42891}) then return "FIRE" end
        if has({12042, 42897, 44425}) then return "ARCANE" end
    elseif classToken == "WARLOCK" then
        if has({59672, 47193, 47193}) then return "DEMONOLOGY" end
        if has({47847, 47843, 17962}) then return "DESTRUCTION" end
        if has({59164, 47813, 47825}) then return "AFFLICTION" end
    elseif classToken == "DEATHKNIGHT" then
        if has({55268, 51411, 49143}) then return "FROST" end
        if has({55050, 49930, 51460}) then return "UNHOLY" end
        if has({49998, 49028, 48266}) then return "BLOOD" end
    end
    return nil
end

local function targetWindowGetDefensiveState(unit, guid, spellId)
    local now = GetTime()
    local spellName = targetDefensiveNames[spellId]
    local active = false
    if spellName then
        for i = 1, 40 do
            local name, _, _, _, _, _, _, _, _, auraSpellId = UnitAura(unit, i, "HELPFUL")
            if not name then break end
            if auraSpellId == spellId or name == spellName then active = true; break end
        end
    end
    if active then return "АКТИВНО", {1,0.80,0.22}, "ACTIVE" end
    local history = targetDefenseHistory[guid]
    local last = history and history[spellId]
    local cd = targetDefenseCooldowns[spellId] or 60
    if last and now - last < cd then
        return string.format("КД %.0fс", cd - (now - last)), {0.92,0.58,0.30}, "CD"
    end
    return "ГОТОВ", {0.30,0.90,0.35}, "READY"
end

local function targetWindowGetBurstState(unit, guid, spellId)
    local now = GetTime()
    local name = targetBurstNames[spellId] or GetSpellInfo(spellId) or ("Spell " .. spellId)
    local active = false
    for i = 1, 40 do
        local auraName, _, _, _, _, _, _, _, _, auraSpellId = UnitAura(unit, i, "HELPFUL")
        if not auraName then break end
        if auraSpellId == spellId or auraName == name then active = true; break end
    end
    if active then return "АКТИВНО", {1,0.20,0.08}, "ACTIVE" end
    local observed = targetObservedSpells[guid] and targetObservedSpells[guid][spellId]
    local cd = targetBurstCooldowns[spellId] or 60
    if observed and now - observed < cd then
        return string.format("КД %.0fс", cd - (now - observed)), {1,0.58,0.08}, "CD"
    end
    return "ГОТОВ", {0.30,0.90,0.35}, "READY"
end

local showWidget
local targetNotificationState = {}
local targetNotificationLast = {}
local targetNotificationExecute = {}
local targetNotificationPriority = {}

local function targetNotificationPlaySound(kind)
    if not DamageLifeDB.targetNotifications or DamageLifeDB.targetNotifications.sound == false then return end
    if not DamageLifeAbilitySounds or not DamageLifeAbilitySounds.Play then return end
    local key = ({
        VULNERABLE = "CRITICAL",
        LAST_DEFENSE = "EXECUTE",
        DEFENSE_REGAINED = "BURST",
        EXECUTE = "EXECUTE",
        PRIORITY = "BURST",
        LOW_HP = "CRITICAL",
    })[kind]
    if key then DamageLifeAbilitySounds:Play(key, "Combat") end
end

local function targetNotificationShow(kind, name, extra)
    local cfg = DamageLifeDB.targetNotifications or {}
    if cfg.enabled == false then return end
    local enabled = ({
        VULNERABLE = cfg.vulnerable,
        LAST_DEFENSE = cfg.lastDefense,
        DEFENSE_REGAINED = cfg.defenseRegained,
        EXECUTE = cfg.execute,
        PRIORITY = cfg.priority,
        LOW_HP = cfg.lowHP,
    })[kind]
    if enabled == false then return end
    local now = GetTime()
    local key = kind .. ":" .. tostring(name or "")
    if targetNotificationLast[key] and now - targetNotificationLast[key] < (tonumber(cfg.cooldown) or 2) then return end
    targetNotificationLast[key] = now

    local title, color
    if kind == "VULNERABLE" then title, color = "ЦЕЛЬ СТАЛА УЯЗВИМОЙ", {1,0.28,0.08}
    elseif kind == "LAST_DEFENSE" then title, color = "ПОСЛЕДНЯЯ ЗАЩИТА ЗАКОНЧИЛАСЬ", {1,0.72,0.08}
    elseif kind == "DEFENSE_REGAINED" then title, color = "ЦЕЛЬ СНОВА ПОЛУЧИЛА ЗАЩИТУ", {0.30,0.90,0.35}
    elseif kind == "EXECUTE" then title, color = "EXECUTE WINDOW", {1,0.18,0.08}
    elseif kind == "PRIORITY" then title, color = "ПРИОРИТЕТНАЯ ЦЕЛЬ", {1,0.82,0.08}
    else title, color = "НИЗКИЙ HP", {1,0.42,0.08} end

    if DamageLifeDB.screenEnabled then
        local fake = { name = name or "цель", unit = UnitGUID("target") == (extra and extra.guid) and "target" or nil, classToken = extra and extra.classToken }
        showWidget(title, fake)
    end
    targetNotificationPlaySound(kind)
    if cfg.chat then
        local text = title .. " — " .. (name or "цель")
        if extra and extra.reason then text = text .. " • " .. extra.reason end
        chat(text)
    end
end

local function targetNotificationUpdate(guid, name, classToken, ready, active, pct, score, isCurrentTarget)
    if not guid or not isCurrentTarget then return end
    local available = ready + active
    local previous = targetNotificationState[guid]
    if previous then
        if previous.active > 0 and active == 0 then
            targetNotificationShow("VULNERABLE", name, { guid = guid, classToken = classToken })
        end
        if previous.available > 0 and available == 0 then
            targetNotificationShow("LAST_DEFENSE", name, { guid = guid, classToken = classToken })
        elseif previous.available == 0 and available > 0 then
            targetNotificationShow("DEFENSE_REGAINED", name, { guid = guid, classToken = classToken })
        end
    end
    targetNotificationState[guid] = { available = available, active = active, pct = pct, score = score }

    local executePct = tonumber(DamageLifeDB.targetNotifications and DamageLifeDB.targetNotifications.executePercent) or 20
    if pct > 0 and pct <= executePct and not targetNotificationExecute[guid] then
        targetNotificationExecute[guid] = true
        targetNotificationShow("EXECUTE", name, { guid = guid, classToken = classToken, reason = pct .. "% HP" })
    elseif pct > executePct + 3 then
        targetNotificationExecute[guid] = nil
    end

    if score >= 85 and not targetNotificationPriority[guid] then
        targetNotificationPriority[guid] = true
        targetNotificationShow("PRIORITY", name, { guid = guid, classToken = classToken, reason = "Priority " .. score })
    elseif score < 75 then
        targetNotificationPriority[guid] = nil
    end

    if (DamageLifeDB.targetNotifications and DamageLifeDB.targetNotifications.lowHP) and pct > 0 and pct <= 35 and not targetNotificationState[guid].lowHPNotified then
        targetNotificationState[guid].lowHPNotified = true
        targetNotificationShow("LOW_HP", name, { guid = guid, classToken = classToken, reason = pct .. "% HP" })
    elseif pct > 40 then
        targetNotificationState[guid].lowHPNotified = nil
    end
end

local function targetWindowBuildCard(index)
    local frame = CreateFrame("Frame", "DamageLifeTargetWindow" .. index, UIParent)
    frame:SetSize(380, 270)
    frame:SetFrameStrata("HIGH")
    frame:SetClampedToScreen(true)
    frame:SetMovable(true)
    frame:EnableMouse(true)

    local bg = frame:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints(frame); bg:SetTexture("Interface\\Buttons\\WHITE8X8")
    bg:SetVertexColor(0.012, 0.010, 0.014, 0.96)
    frame.background = bg

    local header = frame:CreateTexture(nil, "BACKGROUND")
    header:SetPoint("TOPLEFT", 7, -7); header:SetPoint("TOPRIGHT", -7, -39); header:SetTexture("Interface\\Buttons\\WHITE8X8")
    header:SetVertexColor(0.025, 0.020, 0.026, 0.98)

    local top = frame:CreateTexture(nil, "BORDER"); top:SetPoint("TOPLEFT", 5, -5); top:SetPoint("TOPRIGHT", -5, -5); top:SetHeight(2); top:SetTexture("Interface\\Buttons\\WHITE8X8"); top:SetVertexColor(0.60,0.38,0.12,1)
    local bottom = frame:CreateTexture(nil, "BORDER"); bottom:SetPoint("BOTTOMLEFT", 5, 5); bottom:SetPoint("BOTTOMRIGHT", -5, 5); bottom:SetHeight(2); bottom:SetTexture("Interface\\Buttons\\WHITE8X8"); bottom:SetVertexColor(0.34,0.12,0.08,0.95)

    frame.classIcon = frame:CreateTexture(nil, "ARTWORK"); frame.classIcon:SetSize(30,30); frame.classIcon:SetPoint("TOPLEFT",12,-10)
    frame.roleIcon = frame:CreateTexture(nil, "ARTWORK"); frame.roleIcon:SetSize(18,18); frame.roleIcon:SetPoint("TOPLEFT",47,-10)
    frame.role = frame:CreateFontString(nil,"OVERLAY","GameFontNormalSmall"); frame.role:SetPoint("TOPLEFT",68,-11); frame.role:SetWidth(150); frame.role:SetJustifyH("LEFT")
    frame.name = frame:CreateFontString(nil,"OVERLAY","GameFontNormal"); frame.name:SetPoint("TOPLEFT",46,-27); frame.name:SetWidth(210); frame.name:SetWordWrap(false)
    frame.hp = frame:CreateFontString(nil,"OVERLAY","GameFontNormal"); frame.hp:SetPoint("TOPRIGHT",-12,-15); frame.hp:SetWidth(70); frame.hp:SetJustifyH("RIGHT")
    frame.spec = frame:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall"); frame.spec:SetPoint("TOPLEFT",46,-47); frame.spec:SetWidth(260); frame.spec:SetWordWrap(false)

    frame.bar = CreateFrame("StatusBar",nil,frame); frame.bar:SetSize(356,8); frame.bar:SetPoint("TOPLEFT",12,-67); frame.bar:SetStatusBarTexture("Interface\\Buttons\\WHITE8X8"); frame.bar:SetMinMaxValues(0,100)

    frame.defTitle = frame:CreateFontString(nil,"OVERLAY","GameFontNormalSmall"); frame.defTitle:SetPoint("TOPLEFT",12,-82); frame.defTitle:SetText("ЗАЩИТЫ")
    frame.burstTitle = frame:CreateFontString(nil,"OVERLAY","GameFontNormalSmall"); frame.burstTitle:SetPoint("TOPLEFT",202,-82); frame.burstTitle:SetText("BURST")

    frame.defRows, frame.burstRows = {}, {}
    for i = 1, 3 do
        local row = CreateFrame("Frame",nil,frame); row:SetSize(178,25); row:SetPoint("TOPLEFT",10,-97-(i-1)*28)
        row.icon = row:CreateTexture(nil,"ARTWORK"); row.icon:SetSize(22,22); row.icon:SetPoint("LEFT",0,0)
        row.name = row:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall"); row.name:SetPoint("LEFT",row.icon,"RIGHT",5,0); row.name:SetWidth(112); row.name:SetWordWrap(false); row.name:SetJustifyH("LEFT")
        row.state = row:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall"); row.state:SetPoint("RIGHT",0,0); row.state:SetWidth(58); row.state:SetJustifyH("RIGHT")
        frame.defRows[i]=row
        local brow = CreateFrame("Frame",nil,frame); brow:SetSize(168,25); brow:SetPoint("TOPLEFT",202,-97-(i-1)*28)
        brow.icon = brow:CreateTexture(nil,"ARTWORK"); brow.icon:SetSize(22,22); brow.icon:SetPoint("LEFT",0,0)
        brow.name = brow:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall"); brow.name:SetPoint("LEFT",brow.icon,"RIGHT",5,0); brow.name:SetWidth(105); brow.name:SetWordWrap(false)
        brow.state = brow:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall"); brow.state:SetPoint("RIGHT",0,0); brow.state:SetWidth(50); brow.state:SetJustifyH("RIGHT")
        frame.burstRows[i]=brow
    end

    frame.summary = frame:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall"); frame.summary:SetPoint("TOPLEFT",12,-187); frame.summary:SetWidth(356); frame.summary:SetJustifyH("LEFT")
    frame.status = frame:CreateFontString(nil,"OVERLAY","GameFontNormal"); frame.status:SetPoint("TOPLEFT",12,-204); frame.status:SetWidth(356); frame.status:SetWordWrap(false)
    frame.priority = frame:CreateFontString(nil,"OVERLAY","GameFontNormal"); frame.priority:SetPoint("TOPLEFT",12,-225); frame.priority:SetWidth(160)
    frame.switchText = frame:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall"); frame.switchText:SetPoint("TOPRIGHT",-12,-225); frame.switchText:SetWidth(200); frame.switchText:SetJustifyH("RIGHT"); frame.switchText:SetWordWrap(false)

    frame:SetScript("OnMouseDown",function(self,button)
        if button=="LeftButton" and (targetWindowPreview or not DamageLifeDB.targetWindowLocked) then self:StartMoving() end
    end)
    frame:SetScript("OnMouseUp",function(self,button)
        if button=="LeftButton" then self:StopMovingOrSizing(); targetWindowSavePosition(self,index) end
    end)
    frame:SetScript("OnEnter",function(self)
        if targetWindowPreview then
            GameTooltip:SetOwner(self,"ANCHOR_TOP"); GameTooltip:AddLine("DamageLife — Окно цели #"..index,1,0.82,0.25)
            GameTooltip:AddLine("ЛКМ — перемещение",0.82,0.82,0.82); GameTooltip:Show()
        end
    end)
    frame:SetScript("OnLeave",function() GameTooltip:Hide() end)
    targetWindowApplyPosition(frame,index)
    return frame
end

for i = 1, TARGET_WINDOW_MAX do targetWindows[i] = targetWindowBuildCard(i); targetWindows[i]:Hide() end
local targetWindow = targetWindows[1]
_G.DamageLifeTargetWindow = targetWindow

local function targetWindowClearCard(frame)
    for _, rows in ipairs({frame.defRows, frame.burstRows}) do
        for _, row in ipairs(rows) do row.icon:SetTexture("Interface\\Icons\\INV_Misc_QuestionMark"); row.name:SetText(""); row.state:SetText(""); row:Hide() end
    end
end

local function targetWindowSetRow(row, spellId, nameTable, iconTable, stateText, color)
    row.icon:SetTexture(iconTable[spellId] or "Interface\\Icons\\INV_Misc_QuestionMark")
    row.name:SetText(nameTable[spellId] or GetSpellInfo(spellId) or ("Spell "..spellId))
    row.state:SetText(stateText or "")
    row.state:SetTextColor(color[1],color[2],color[3],1)
    row:Show()
end

local function targetWindowUnitCandidates()
    local candidates = {}
    local seen = {}
    local tokens = {"target","focus","mouseover"}
    for i=1,5 do tokens[#tokens+1]="arena"..i end
    for i=1,40 do tokens[#tokens+1]="nameplate"..i end
    for _, unit in ipairs(tokens) do
        if UnitExists(unit) and UnitCanAttack("player",unit) and not UnitIsDeadOrGhost(unit) then
            local guid = UnitGUID(unit)
            if guid and not seen[guid] then
                seen[guid]=true; candidates[#candidates+1]=unit
            end
        end
    end
    return candidates
end

local function targetWindowScore(unit, guid, roleData, hpPercent, defReady, defActive, burstReady, burstActive)
    local score = 35
    score = score + math.max(0, 35 - hpPercent) * 0.9
    if roleData.role == "HEALER" then score = score + 22 elseif roleData.role == "RANGED" then score = score + 4 end
    if defReady == 0 and defActive == 0 then score = score + 18 elseif defReady <= 1 then score = score + 8 end
    if burstActive then score = score - 8 elseif burstReady == 0 and #roleData.burst > 0 then score = score + 6 end
    if hpPercent <= 20 then score = score + 12 end
    if score > 100 then score=100 end
    if score < 0 then score=0 end
    return math.floor(score+0.5)
end

local function targetWindowUpdateCard(frame, index, unit, preview)
    targetWindowClearCard(frame)
    frame:Show()
    if preview then
        frame.roleIcon:SetTexture("Interface\\Icons\\Spell_Holy_HolyProtection")
        frame.role:SetText("HEALER"); frame.role:SetTextColor(1,0.20,0.20,1)
        frame.name:SetText("Pandora"); frame.name:SetTextColor(1,0.82,0.25,1)
        frame.spec:SetText("Holy Priest • PREVIEW"); frame.hp:SetText("42%")
        frame.bar:SetValue(42); frame.bar:SetStatusBarColor(1,0.48,0.08,0.95)
        targetWindowSetRow(frame.defRows[1],47788,targetDefensiveNames,targetDefensiveIcons,"ГОТОВ",{0.30,0.90,0.35})
        targetWindowSetRow(frame.defRows[2],642,targetDefensiveNames,targetDefensiveIcons,"КД 24с",{0.92,0.58,0.30})
        targetWindowSetRow(frame.burstRows[1],31842,targetBurstNames,targetBurstIcons,"ГОТОВ",{0.30,0.90,0.35})
        frame.summary:SetText("2 защиты • 1 Burst • PREVIEW")
        frame.status:SetText("ПРИОРИТЕТНАЯ ЦЕЛЬ"); frame.status:SetTextColor(1,0.22,0.08,1)
        frame.priority:SetText("★ PRIORITY: 96"); frame.priority:SetTextColor(1,0.82,0.10,1)
        frame.switchText:SetText("SWITCH → HEALER"); frame.switchText:SetTextColor(1,0.35,0.25,1)
        frame.classIcon:SetTexture("Interface\\Icons\\Spell_Holy_HolyProtection"); frame.classIcon:SetTexCoord(0.08,0.92,0.08,0.92)
        return
    end

    local name = UnitName(unit) or "Цель"
    local className, classToken = UnitClass(unit)
    local guid = UnitGUID(unit)
    local hp,maxHp = UnitHealth(unit) or 0, UnitHealthMax(unit) or 0
    local pct = maxHp > 0 and math.floor(hp/maxHp*100+0.5) or 0
    local spec = targetWindowDetectSpec(unit,guid,classToken)
    local roleData = targetWindowRoleData(classToken,spec)
    local roleLabel, roleIconPath, roleColor
    if roleData.role == "HEALER" then
        roleLabel, roleIconPath, roleColor = "HEALER", "Interface\\Icons\\Spell_Holy_HolyProtection", {1,0.20,0.20}
    elseif roleData.role == "RANGED" then
        roleLabel, roleIconPath, roleColor = "RANGE DAMAGER", "Interface\\Icons\\Ability_Hunter_AimedShot", {0.90,0.90,0.90}
    else
        roleLabel, roleIconPath, roleColor = "DAMAGER", "Interface\\Icons\\Ability_Warrior_BattleShout", {0.90,0.90,0.90}
    end
    frame.roleIcon:SetTexture(roleIconPath)
    frame.role:SetText(roleLabel); frame.role:SetTextColor(roleColor[1],roleColor[2],roleColor[3],1)
    frame.name:SetText(name); local cc=classColors[classToken]; if cc then frame.name:SetTextColor(cc[1],cc[2],cc[3],1) else frame.name:SetTextColor(1,0.82,0.25,1) end
    frame.spec:SetText((spec and roleData.label or "SPEC UNKNOWN") .. " • " .. (className or "NPC"))
    frame.hp:SetText(string.format("%d%%",pct))
    frame.bar:SetValue(pct)
    local barColor = pct <= 20 and {0.85,0.12,0.08} or pct <= 40 and {1,0.48,0.08} or {0.18,0.72,0.24}
    frame.bar:SetStatusBarColor(barColor[1],barColor[2],barColor[3],0.95)
    if classToken and CLASS_ICON_TCOORDS and CLASS_ICON_TCOORDS[classToken] then
        local c=CLASS_ICON_TCOORDS[classToken]; frame.classIcon:SetTexture("Interface\\GLUES\\CHARACTERCREATE\\UI-CharacterCreate-Classes"); frame.classIcon:SetTexCoord(c[1],c[2],c[3],c[4])
    else frame.classIcon:SetTexture("Interface\\Icons\\INV_Misc_QuestionMark"); frame.classIcon:SetTexCoord(0.08,0.92,0.08,0.92) end

    local defs = roleData.defensives or targetClassDefensives[classToken] or {}
    local bursts = roleData.burst or {}
    local specKnown = spec ~= nil
    local ready,active,cds = 0,0,0
    for i,spellId in ipairs(defs) do
        if i > 3 then break end
        local stateText,color = targetWindowGetDefensiveState(unit,guid,spellId)
        local _,_,stateCode = targetWindowGetDefensiveState(unit,guid,spellId)
        if stateCode=="READY" then ready=ready+1 elseif stateCode=="ACTIVE" then active=active+1 else cds=cds+1 end
        targetWindowSetRow(frame.defRows[i],spellId,targetDefensiveNames,targetDefensiveIcons,stateText,color)
    end
    local burstReady,burstActive = 0,0
    for i,spellId in ipairs(bursts) do
        if i > 3 then break end
        local stateText,color,stateCode = targetWindowGetBurstState(unit,guid,spellId)
        if stateCode=="READY" then burstReady=burstReady+1 elseif stateCode=="ACTIVE" then burstActive=burstActive+1 end
        targetWindowSetRow(frame.burstRows[i],spellId,targetBurstNames,targetBurstIcons,stateText,color)
    end

    local score = targetWindowScore(unit,guid,roleData,pct,ready,active,burstReady,burstActive)
    targetNotificationUpdate(guid, name, classToken, ready, active, pct, score, UnitGUID("target") == guid)
    if specKnown then
        frame.summary:SetText(string.format("Защит: %d готово • %d КД • %d активно",ready,cds,active))
    else
        frame.summary:SetText("Защиты: ожидание определения спека • BURST: ожидание")
    end
    if pct <= 20 and ready == 0 and active == 0 then
        frame.status:SetText("EXECUTE WINDOW • УЯЗВИМ"); frame.status:SetTextColor(1,0.22,0.08,1)
    elseif ready == 0 and active == 0 then
        frame.status:SetText("УЯЗВИМ • ЗАЩИТ НЕ ОСТАЛОСЬ"); frame.status:SetTextColor(1,0.22,0.08,1)
    elseif burstActive > 0 then
        frame.status:SetText("ENEMY BURST ACTIVE"); frame.status:SetTextColor(1,0.20,0.08,1)
    elseif roleData.role == "HEALER" then
        frame.status:SetText("HEALER • ПРИОРИТЕТ"); frame.status:SetTextColor(1,0.35,0.25,1)
    elseif roleData.role == "UNKNOWN" then
        frame.status:SetText("ОПРЕДЕЛЯЕМ СПЕК"); frame.status:SetTextColor(0.82,0.82,0.82,1)
    else
        frame.status:SetText("ЦЕЛЬ ПОД НАБЛЮДЕНИЕМ"); frame.status:SetTextColor(0.82,0.82,0.82,1)
    end
    frame.priority:SetText("★ PRIORITY: "..score); frame.priority:SetTextColor(1,0.82,0.10,1)
    frame.switchText:SetText(score >= 85 and "SWITCH → РЕКОМЕНДОВАНО" or "")
    frame.switchText:SetTextColor(1,0.35,0.25,1)
end

local function targetWindowSetCount(count)
    count = math.max(1, math.min(TARGET_WINDOW_MAX, math.floor(tonumber(count) or 1)))
    DamageLifeDB.targetWindowCount = count
    for i=1,TARGET_WINDOW_MAX do
        if i <= count then
            targetWindowApplyPosition(targetWindows[i],i)
            if targetWindowPreview then targetWindowUpdateCard(targetWindows[i],i,nil,true) end
        else
            targetWindows[i]:Hide()
        end
    end
end

local function targetWindowShowPreview()
    targetWindowPreview = true
    targetWindowSetCount(DamageLifeDB.targetWindowCount or 1)
    for i=1,(DamageLifeDB.targetWindowCount or 1) do targetWindowUpdateCard(targetWindows[i],i,nil,true) end
end

local function targetWindowHidePreview()
    targetWindowPreview = false
    for i=1,TARGET_WINDOW_MAX do targetWindows[i]:Hide() end
end

local function targetWindowResetPositions()
    DamageLifeDB.targetWindowPositions = {}
    for i=1,TARGET_WINDOW_MAX do targetWindowApplyPosition(targetWindows[i],i) end
end

local function targetWindowUpdate()
    if targetWindowPreview then
        for i=1,(DamageLifeDB.targetWindowCount or 1) do targetWindowUpdateCard(targetWindows[i],i,nil,true) end
        return
    end
    if not DamageLifeDB or not DamageLifeDB.enabled or DamageLifeDB.targetAnalysisEnabled == false then
        for i=1,TARGET_WINDOW_MAX do targetWindows[i]:Hide() end
        return
    end
    local units = targetWindowUnitCandidates()
    local scored = {}
    for _,unit in ipairs(units) do
        local guid=UnitGUID(unit); local _,classToken=UnitClass(unit)
        if guid and classToken and UnitIsPlayer(unit) then
            targetWindowQueueInspect(unit, guid, classToken)
        end
        local hp,maxHp=UnitHealth(unit) or 0,UnitHealthMax(unit) or 0
        local pct=maxHp>0 and math.floor(hp/maxHp*100+0.5) or 0
        local spec=targetWindowDetectSpec(unit,guid,classToken); local roleData=targetWindowRoleData(classToken,spec)
        local defs=roleData.defensives or targetClassDefensives[classToken] or {}
        local ready,active=0,0
        for _,id in ipairs(defs) do local _,_,code=targetWindowGetDefensiveState(unit,guid,id); if code=="READY" then ready=ready+1 elseif code=="ACTIVE" then active=active+1 end end
        local bursts=roleData.burst or {}; local burstReady,burstActive=0,0
        for _,id in ipairs(bursts) do local _,_,code=targetWindowGetBurstState(unit,guid,id); if code=="READY" then burstReady=burstReady+1 elseif code=="ACTIVE" then burstActive=burstActive+1 end end
        local score=targetWindowScore(unit,guid,roleData,pct,ready,active,burstReady,burstActive)
        scored[#scored+1]={unit=unit,score=score}
    end
    table.sort(scored,function(a,b) return a.score>b.score end)
    local count=DamageLifeDB.targetWindowCount or 1
    for i=1,TARGET_WINDOW_MAX do
        if i<=count and scored[i] then targetWindowUpdateCard(targetWindows[i],i,scored[i].unit,false)
        else targetWindows[i]:Hide() end
    end
end

DamageLifeTargetWindowManager = DamageLifeTargetWindowManager or {}
function DamageLifeTargetWindowManager:SetCount(count) targetWindowSetCount(count); targetWindowUpdate() end
function DamageLifeTargetWindowManager:ShowPreview() targetWindowShowPreview() end
function DamageLifeTargetWindowManager:HidePreview() targetWindowHidePreview() end
function DamageLifeTargetWindowManager:ResetPositions() targetWindowResetPositions() end
function DamageLifeTargetWindowManager:Refresh() targetWindowUpdate() end
function DamageLifeTargetWindowManager:IsPreview() return targetWindowPreview end

local function targetWindowTick(elapsed)
    targetWindowElapsed = targetWindowElapsed + (elapsed or 0)
    if targetWindowElapsed < 0.20 then return end
    targetWindowElapsed = 0
    targetWindowUpdate()
end

targetWindowSetCount(DamageLifeDB.targetWindowCount or 1)


local function setRewardPortrait(unit)
    widget.characterModel:Hide(); widget.icon:Hide()
    widget.faceIconFrame:Hide()
    local hasUnit = unit and UnitExists(unit)
    for _, texture in ipairs(widget.portraitSlices) do
        if hasUnit then
            SetPortraitTexture(texture, unit)
        else
            texture:SetTexture("Interface\\Icons\\Spell_Holy_GuardianSpirit")
        end
        texture:SetTexCoord(texture.portraitLeft, texture.portraitRight, texture.portraitTop, texture.portraitBottom)
        texture:Show()
    end
end

showWidget = function(text, state)
    if not DamageLifeDB.screenEnabled then return end
    setupWidget(); widget.editMode = false; widget.mode = "save"
    local classToken = state.classToken
    if state.unit and UnitExists(state.unit) then local _, unitClassToken = UnitClass(state.unit); classToken = unitClassToken or classToken end
    widget.title:SetText("|cffffd34e" .. text .. "|r")
    widget.name:SetText("|cffffd67a" .. (state.name or UNKNOWN) .. "|r")
    widget.subtitle:SetText("|cffd8d2c4Боевой успех DamageLife|r")
    setRewardPortrait(state.unit)
    widget.duration = 4; widget.animationStart = GetTime(); widget.expires = GetTime() + widget.duration; widget.bar:SetValue(1); widget:SetAlpha(0); widget:Show()
end

local function randomEmote(targetName)
    local choices = {}
    for i, phrase in ipairs(DamageLifeDB.phrases) do if DamageLifeDB.phraseEnabled[i] and phrase ~= "" then choices[#choices + 1] = i end end
    if #choices == 0 then return nil end
    local pick = choices[math.random(#choices)]
    if #choices > 1 and pick == lastPhraseIndex then for _, i in ipairs(choices) do if i ~= lastPhraseIndex then pick = i; break end end end
    lastPhraseIndex = pick
    return string.gsub(DamageLifeDB.phrases[pick], "{target}", targetName)
end

local function canPublicEmote()
    if not instanceAllowed() then return false end
    if currentInstanceType == "none" then return DamageLifeDB.allowWorld ~= false end
    if not DamageLifeDB.groupEmotesOnly then return true end
    return GetNumRaidMembers() > 0 or GetNumPartyMembers() > 0 or currentInstanceType == "pvp" or currentInstanceType == "arena"
end

local function canPublicAnnouncement(channel)
    if not instanceAllowed() then return false end
    if channel == "YELL" then return true end
    return canPublicEmote()
end

local combatVoiceSounds = {
    CRITICAL = "Interface\\AddOns\\DamageLife\\Sounds\\Voice\\CRITICAL.mp3",
    BURST = "Interface\\AddOns\\DamageLife\\Sounds\\Voice\\BURST.mp3",
    EXECUTE = "Interface\\AddOns\\DamageLife\\Sounds\\Voice\\EXECUTE.mp3",
    CONTROL = "Interface\\AddOns\\DamageLife\\Sounds\\Voice\\CONTROL.mp3",
}
local function playVoice(key)
    local path = combatVoiceSounds[key]
    if path then return PlaySoundFile(path, "Master") end
    return false
end

local function recordSave(state)
    local s = DamageLifeDB.stats
    statIncrement(s, "totalSaves"); statIncrement(sessionStats, "saves"); statIncrement(combatStats, "saves")
    if currentInstanceType == "pvp" or currentInstanceType == "arena" then statIncrement(battlegroundStats, "saves") end
    statIncrement(s.byTarget, state.name); statIncrement(s.byClass, state.className)
    if state.lastOwnSpell then statIncrement(s.bySpell, state.lastOwnSpell) end
    statIncrement(s, "effectiveHealing", state.ownHealing); statIncrement(s, "prevented", state.prevented)
    if state.lethalPrevented then statIncrement(s, "lethalPreventions") end
    statIncrement(sessionStats, "healing", state.ownHealing); statIncrement(sessionStats, "prevented", state.prevented)
    DamageLifeDB.totalSaves = s.totalSaves
    if OraculStatisticsEngine then OraculStatisticsEngine:RecordRescue(state) end
end

local function announceSave(state, isTest)
    local now = GetTime()
    local previousTargetAnnouncement = lastTargetAnnouncement[state.guid]
    local suppressed = not isTest and previousTargetAnnouncement and now - previousTargetAnnouncement < DamageLifeDB.targetCooldown
    if now - lastSaveAt > DamageLifeDB.streakWindow then streak = 0 end
    streak, lastSaveAt = streak + 1, now
    if not isTest then
        recordSave(state)
        if currentInstanceType == "pvp" or currentInstanceType == "arena" then
            refreshBattlegroundCounter()
            DamageLifeDB.bgSaveCount = (tonumber(DamageLifeDB.bgSaveCount) or 0) + 1
        end
        if streak > DamageLifeDB.stats.bestStreak then DamageLifeDB.stats.bestStreak = streak end
        DamageLifeDB.bestStreak = DamageLifeDB.stats.bestStreak
        refreshStatsUI()
    end
    local tier = math.min(streak, #DamageLifeDB.streakNames)
    local text = DamageLifeDB.streakNames[tier] or ("DAMAGE x" .. streak .. "!")
    if streak > #DamageLifeDB.streakNames then text = "DAMAGE x" .. streak .. "!" end
    if not suppressed then showWidget(text, state) end
    if not suppressed and DamageLifeDB.localChatEnabled then chat(text .. " |cffffffff" .. state.name .. "|r" .. (isTest and " |cffaaaaaa(тест)|r" or " (всего: " .. DamageLifeDB.stats.totalSaves .. ")")) end
    if not suppressed and not isTest and DamageLifeDB.emoteEnabled and now - lastEmoteAt >= DamageLifeDB.emoteCooldown and canPublicEmote() then
        local phrase = randomEmote(state.name)
        if phrase then
            local count = tonumber(DamageLifeDB.bgSaveCount) or 0
            SendChatMessage(phrase .. (count > 0 and (" #" .. count) or ""), "EMOTE")
            lastEmoteAt = now
        end
    end
    if not suppressed then
        if DamageLifeDB.voiceRescueEnabled ~= false then playVoice("RESCUE") end
    end
    if not isTest and not suppressed then lastTargetAnnouncement[state.guid] = now end
    state.active, state.pending, state.crisisVisible, state.crisisResolvedAt = false, false, false, now
end

local function qualifies(state, percent)
    local required = math.max(0, state.maxHealth * DamageLifeDB.safePercent / 100 - state.startHealth)
    if percent < DamageLifeDB.safePercent / 100 then return false end
    -- Спасение засчитывается только когда личное эффективное лечение и
    -- поглощение полностью покрыли путь от начального HP до безопасного порога.
    return state.ownHealing + state.prevented >= required
end

local function updateUnit(unit)
    local guid = UnitGUID(unit); if not guid then return end
    local groupUnit = unitsByGUID[guid]
    local state = tracked[guid]
    if not groupUnit then
        if state then state.active, state.pending, state.crisisVisible = false, false, false end
        return
    end
    unit = groupUnit
    if not unitAllowed(unit) then
        if state then
            state.active, state.pending, state.crisisVisible = false, false, false
            -- При возвращении союзника в радиус уже низкое здоровье должно
            -- открыть новое честное окно спасения.
            state.armed = true
        end
        return
    end
    local current, maximum, percent = healthData(unit)
    if not current then return end
    -- Ровно безопасный порог (например, 50%) тоже должен заново вооружать
    -- цель для следующего независимого спасения.
    if state and not state.armed and not state.active and percent >= DamageLifeDB.safePercent / 100 then state.armed = true end
    if state and state.crisisVisible and not state.active and percent >= DamageLifeDB.safePercent / 100 then state.crisisVisible = false end
    if percent <= DamageLifeDB.lowPercent / 100 then
        if not state then tracked[guid] = { armed = true }; state = tracked[guid] end
        beginCrisis(guid, unit, current, maximum); state = tracked[guid]
    end
    if state and state.active then
        local now = GetTime()
        decayPressure(state, now)
        local activelyRescuing = (state.lastOwnContributionAt or 0) > 0 and now - state.lastOwnContributionAt <= 2
        if now - state.startedAt > DamageLifeDB.rescueWindow and not activelyRescuing then
            state.active, state.pending, state.crisisVisible = false, false, false
            state.lastOwnContributionAt = 0
        elseif qualifies(state, percent) then
            announceSave(state)
        elseif percent >= DamageLifeDB.safePercent / 100 and not state.reportedReject then
            state.reportedReject = true
            local required = math.max(0, state.maxHealth * DamageLifeDB.safePercent / 100 - state.startHealth)
            debugChat(state.name .. ": цель достигла порога, но ваш вклад " .. math.floor(state.ownHealing + state.prevented) .. " из необходимых " .. math.floor(required))
        end
    end
end

local function scanGroup()
    -- The roster map is rebuilt by roster/world events. Rebuilding it on every
    -- health scan multiplied GUID, class and range calls by the raid size.
    for _, unit in pairs(unitsByGUID) do updateUnit(unit) end
end

local function healEvent(sourceGUID, sourceFlags, destGUID, spellName, amount, overhealing)
    local state = tracked[destGUID]; if not state or (not state.active and not state.crisisVisible) then return end
    local effective = math.max(0, (amount or 0) - (overhealing or 0))
    if effective > 0 then state.lastHealerGUID = sourceGUID end
    local mine = sourceGUID == playerGUID
    if not mine and sourceFlags and COMBATLOG_OBJECT_AFFILIATION_MINE then
        mine = bit.band(sourceFlags, COMBATLOG_OBJECT_AFFILIATION_MINE) == COMBATLOG_OBJECT_AFFILIATION_MINE
    end
    if mine then
        local now = GetTime(); decayPressure(state, now)
        state.recentOwnHealing = (state.recentOwnHealing or 0) + effective
        if not state.active then return end
        state.ownHealing = state.ownHealing + effective; state.lastOwnSpell = spellName or UNKNOWN; state.lastOwnHealAt = GetTime()
        state.lastOwnContributionAt = now
        state.lastHealerGUID = playerGUID
        debugChat(state.name .. ": ваш эффективный хил " .. math.floor(state.ownHealing) .. ", общий хил " .. math.floor(state.totalHealing))
    elseif not state.active then return end
    state.totalHealing = state.totalHealing + effective
end

local function damageAmount(eventType, ...)
    local amount
    if eventType == "SWING_DAMAGE" then amount = select(9, ...)
    elseif eventType == "SPELL_DAMAGE" or eventType == "SPELL_PERIODIC_DAMAGE" or eventType == "RANGE_DAMAGE" then amount = select(12, ...) end
    if amount ~= nil then return tonumber(amount) or 0 end
    return 0
end

local function damageAbsorbed(eventType, ...)
    local absorbed
    if eventType == "SWING_DAMAGE" then absorbed = select(14, ...)
    elseif eventType == "SPELL_DAMAGE" or eventType == "SPELL_PERIODIC_DAMAGE" or eventType == "RANGE_DAMAGE" then absorbed = select(17, ...) end
    if absorbed ~= nil then return tonumber(absorbed) or 0 end
    return 0
end

local function missedAbsorb(eventType, ...)
    local missType, amount
    if eventType == "SWING_MISSED" then
        missType, amount = select(9, ...), select(10, ...)
    elseif eventType == "SPELL_MISSED" or eventType == "SPELL_PERIODIC_MISSED" or eventType == "RANGE_MISSED" then
        missType, amount = select(12, ...), select(13, ...)
    end
    if missType == "ABSORB" then return tonumber(amount) or 0 end
    return 0
end

local function recordOwnAbsorb(state, destGUID, amount)
    if amount <= 0 then return end
    local auras = ownAuras[destGUID]
    if not auras then return end
    local absorbName, absorbSpellId
    for spellId, spellName in pairs(auras) do
        if absorbSpells[spellId] then absorbName, absorbSpellId = spellName or UNKNOWN, spellId; break end
    end
    if not absorbName then return end
    local unit = unitsByGUID[destGUID]
    local targetName = (state and state.name) or (unit and UnitExists(unit) and UnitName(unit)) or UNKNOWN
    if OraculStatisticsEngine then OraculStatisticsEngine:RecordAbsorb(amount, targetName, absorbSpellId, absorbName) end
    if not state then return end
    local now = GetTime(); decayPressure(state, now)
    state.recentAbsorb = (state.recentAbsorb or 0) + amount
    if state.active then
        state.prevented = (state.prevented or 0) + amount
        state.lastOwnSpell = absorbName
        state.lastOwnContributionAt = now
        if unit and UnitExists(unit) and amount >= UnitHealth(unit) then state.lethalPrevented = true end
        debugChat(state.name .. ": ваш щит поглотил " .. math.floor(amount) .. ", общий вклад " .. math.floor((state.ownHealing or 0) + state.prevented))
    end
end

local function classBuffAllowed(classToken)
    local key = classSetting[classToken]; return key and DamageLifeDB[key]
end

local function defensiveSpellAllowed(spellId, classToken)
    if not classBuffAllowed(classToken) then return false end
    local setting = defensiveSpellSettings[spellId]
    return not setting or DamageLifeDB[setting]
end

local function chooseAbilityPhrase(definition, config)
    local choices = { 1 }
    for i = 2, 6 do
        if config.phraseEnabled[i] and config.phrases[i] and config.phrases[i] ~= "" then choices[#choices + 1] = i end
    end
    local selected = choices[math.random(#choices)]
    local previous = lastAbilityPhraseIndex[definition.key]
    if #choices > 1 and selected == previous then
        for _, index in ipairs(choices) do if index ~= previous then selected = index; break end end
    end
    lastAbilityPhraseIndex[definition.key] = selected
    local phrase = config.phrases[selected] or definition.defaults[1]
    if phrase == "" then phrase = definition.defaults[1] end
    return phrase
end

local function canWhisperTarget(destName, destGUID, destFlags)
    if not destName or destName == "" then return false end
    if destGUID == playerGUID then return false end
    -- In battlegrounds/arenas a combat-log player may be targetable but still
    -- be unavailable for direct whisper (especially opponents and players
    -- outside our party/raid). Only allow a whisper when the target is a
    -- member of our current party/raid.
    if currentInstanceType == "pvp" or currentInstanceType == "arena" then
        local inParty = UnitInParty and UnitInParty(destName)
        local inRaid = UnitInRaid and UnitInRaid(destName)
        return inParty or inRaid or false
    end
    -- In the open world, hostile/faction-opposed players cannot be whispered
    -- reliably. Friendly players remain eligible.
    if destFlags and COMBATLOG_OBJECT_REACTION_FRIENDLY then
        return bit.band(destFlags, COMBATLOG_OBJECT_REACTION_FRIENDLY) == COMBATLOG_OBJECT_REACTION_FRIENDLY
    end
    return false
end

local function announceAbility(definition, spellId, spellName, destGUID, destName, destFlags)
    if not definition then return end
    if not definition.groupWide and (not destGUID or destGUID == playerGUID) then return end
    local targetKey = definition.groupWide and "GROUP" or destGUID
    local announcementKey = definition.key .. ":" .. tostring(targetKey)
    if recentAbilityAnnouncements[announcementKey] and GetTime() - recentAbilityAnnouncements[announcementKey] < 2 then return end
    recentAbilityAnnouncements[announcementKey] = GetTime()

    if DamageLifeAbilitySounds then DamageLifeAbilitySounds:Play(definition.key, "Class") end

    local config = DamageLifeDB.abilitySettings and DamageLifeDB.abilitySettings[definition.key]
    if not config then return end
    local spellLink = GetSpellLink(spellId) or spellName or UNKNOWN
    local targetName = definition.groupWide and "группа" or (destName or UNKNOWN)
    local stats = DamageLifeDB.stats
    statIncrement(stats, "buffCasts")
    statIncrement(stats.buffBySpell, spellName or UNKNOWN)
    statIncrement(stats.buffByTarget, targetName)
    if OraculStatisticsEngine then OraculStatisticsEngine:RecordAbility(definition, spellId, spellName, targetName) end
    if DamageLifeDB.localChatEnabled and not definition.whisperOnly then chat(spellLink .. " → |cffffffff" .. targetName .. "|r") end

    if not definition.groupWide and config.whisper and destName and destFlags and bit.band(destFlags, COMBATLOG_OBJECT_TYPE_PLAYER) == COMBATLOG_OBJECT_TYPE_PLAYER and canWhisperTarget(destName, destGUID, destFlags) then
        local whisperText
        if definition.whisperOnly then
            whisperText = chooseAbilityPhrase(definition, config)
            whisperText = string.gsub(whisperText, "{target}", targetName)
            whisperText = string.gsub(whisperText, "{spell}", spellLink)
        else
            whisperText = "На вас наложено: " .. spellLink .. "."
        end
        SendChatMessage(whisperText, "WHISPER", nil, destName)
    end
    local announcementChannel = definition.announcementChannel or "EMOTE"
    if not definition.whisperOnly and config.emote and canPublicAnnouncement(announcementChannel) then
        local phrase = chooseAbilityPhrase(definition, config)
        phrase = string.gsub(phrase, "{target}", targetName)
        phrase = string.gsub(phrase, "{spell}", spellLink)
        SendChatMessage(phrase, announcementChannel)
    end
end

local recentAllyDeaths = {}
local function announceNearbyAllyDeath(destGUID, destFlags)
    if DamageLifeDB.voiceAllyDeathEnabled == false or not destGUID or destGUID == playerGUID then return end
    if bit.band(destFlags or 0, COMBATLOG_OBJECT_TYPE_PLAYER) ~= COMBATLOG_OBJECT_TYPE_PLAYER then return end
    if bit.band(destFlags or 0, COMBATLOG_OBJECT_REACTION_FRIENDLY) ~= COMBATLOG_OBJECT_REACTION_FRIENDLY then return end
    local unit = unitsByGUID[destGUID]
    -- The 3.3.5 client has no exact 100-metre range API. UnitIsVisible is the
    -- closest stable client-side check and excludes remote raid deaths.
    if not unit or not UnitExists(unit) or (UnitIsVisible and not UnitIsVisible(unit)) then return end
    local now = GetTime()
    if recentAllyDeaths[destGUID] and now - recentAllyDeaths[destGUID] < 5 then return end
    recentAllyDeaths[destGUID] = now
    playVoice("ALLY_DIED")
end

local function combatLogEvent(...)
    local eventType, sourceGUID, sourceFlags, destGUID = select(2, ...), select(3, ...), select(5, ...), select(6, ...)
    if eventType == "UNIT_DIED" or eventType == "UNIT_DESTROYED" then
        announceNearbyAllyDeath(destGUID, select(8, ...))
        local state = tracked[destGUID]
        if state and state.active then recordFailure(state) end
        if state then state.active, state.pending, state.crisisVisible = false, false, false end
        return
    end
    if eventType == "SPELL_HEAL" or eventType == "SPELL_PERIODIC_HEAL" then
        healEvent(sourceGUID, sourceFlags, destGUID, select(10, ...), select(12, ...), select(13, ...)); return
    end
    if (eventType == "SPELL_CAST_SUCCESS" or eventType == "SPELL_RESURRECT") and sourceGUID == playerGUID then
        local spellId, spellName, destName, destFlags = select(9, ...), select(10, ...), select(7, ...), select(8, ...)
        local definition = abilityBySpellId[spellId]
        if definition and (definition.class == "PALADIN" or definition.groupWide or definition.announceOnCast) and classBuffAllowed(definition.class) and DamageLifeDB[definition.setting] then
            announceAbility(definition, spellId, spellName, destGUID, destName, destFlags)
        end
        return
    end
    if eventType == "SPELL_AURA_APPLIED" or eventType == "SPELL_AURA_REFRESH" then
        if sourceGUID == playerGUID then
            local spellId, spellName, destName, destFlags = select(9, ...), select(10, ...), select(7, ...), select(8, ...)
            local classToken = defensiveSpells[spellId]
            local definition = abilityBySpellId[spellId]
            local abilityAllowed = definition and classBuffAllowed(definition.class) and DamageLifeDB[definition.setting]
            if definition and not definition.groupWide and destGUID == playerGUID then return end
            if classToken and defensiveSpellAllowed(spellId, classToken) then
                ownAuras[destGUID] = ownAuras[destGUID] or {}; ownAuras[destGUID][spellId] = spellName
                local state = tracked[destGUID]; if state and state.active then state.defensiveSpell, state.lastOwnSpell = spellName, spellName end
            end
            if absorbSpells[spellId] then
                ownAuras[destGUID] = ownAuras[destGUID] or {}; ownAuras[destGUID][spellId] = spellName
            end
            if eventType == "SPELL_AURA_APPLIED" and abilityAllowed and not definition.groupWide then
                announceAbility(definition, spellId, spellName, destGUID, destName, destFlags)
            end
        end
        return
    end
    if eventType == "SPELL_AURA_REMOVED" then
        local spellId = select(9, ...)
        if ownAuras[destGUID] and (sourceGUID == playerGUID or absorbSpells[spellId]) then ownAuras[destGUID][spellId] = nil end
        return
    end
    if eventType == "SWING_MISSED" or eventType == "SPELL_MISSED" or eventType == "SPELL_PERIODIC_MISSED" or eventType == "RANGE_MISSED" then
        local absorbed = missedAbsorb(eventType, ...)
        if absorbed > 0 then recordOwnAbsorb(tracked[destGUID], destGUID, absorbed) end
        return
    end
    if string.find(eventType or "", "_DAMAGE$") then
        local state = tracked[destGUID]
        if state and state.crisisVisible then
            decayPressure(state, GetTime())
            state.recentDamage = (state.recentDamage or 0) + damageAmount(eventType, ...)
        end
        local absorbed = damageAbsorbed(eventType, ...)
        if absorbed > 0 then recordOwnAbsorb(state, destGUID, absorbed) end
    end
end

function LS:GetRuntimeStats() return sessionStats, combatStats, battlegroundStats, streak end
function LS:PreviewVoice(key)
    local aliases = {
        CRITICAL = "CRITICAL", BURST = "BURST", EXECUTE = "EXECUTE", CONTROL = "CONTROL",
    }
    return playVoice(aliases[key] or key)
end
function LS:GetTracked() return tracked end
function LS:RefreshWidget() setupWidget() end
function LS:SetWidgetLocked(locked)
    DamageLifeDB.widgetLocked = locked and true or false
    widget:EnableMouse(not DamageLifeDB.widgetLocked)
    if not DamageLifeDB.widgetLocked then
        setupWidget()
        widget.editMode = true
        widget.expires = nil
        setRewardPortrait("player")
        widget.title:SetText("|cffffd34eРЕЖИМ ПЕРЕМЕЩЕНИЯ|r")
        widget.name:SetText("|cffffffffПеретащите плашку мышью|r")
        widget.subtitle:SetText("|cffd8d2c4Затем закрепите её в новом месте.|r")
        widget.bar:SetValue(1)
        widget:SetAlpha(1); widget.portraitFrame:SetScale(1); widget.healFrame:SetScale(1)
        widget:Show()
    elseif widget.editMode then
        widget.editMode = false
        widget:Hide()
    end
end
function LS:ResetWidgetPosition()
    DamageLifeDB.widgetPoint, DamageLifeDB.widgetRelativePoint = "TOP", "TOP"
    DamageLifeDB.widgetX, DamageLifeDB.widgetY, DamageLifeDB.widgetScale = 0, -276, 0.6
    setupWidget()
end
function LS:PreviewPhrase(index)
    local phrase = DamageLifeDB.phrases[index] or defaultPhrases[1]
    chat(string.gsub(phrase, "{target}", UnitName("player") or "Игрок"))
end
function LS:ResetStats()
    DamageLifeDB.stats = { totalDamageEvents = 0, abilityCasts = 0, criticalHits = 0, categoryEvents = { CRITICAL = 0, BURST = 0, EXECUTE = 0, CONTROL = 0 }, categoryBySpell = {}, categoryByTarget = {}, totalSaves = 0, bestStreak = 0, attempts = 0, failures = 0, lethalPreventions = 0, effectiveHealing = 0, prevented = 0, buffCasts = 0, buffBySpell = {}, buffByTarget = {}, byTarget = {}, bySpell = {}, byClass = {} }
    DamageLifeDB.totalSaves, DamageLifeDB.bestStreak = 0, 0
    sessionStats = { saves = 0, attempts = 0, failures = 0, healing = 0, prevented = 0 }
    combatStats = { saves = 0, attempts = 0, failures = 0 }; battlegroundStats = { saves = 0, attempts = 0, failures = 0 }
    streak, lastSaveAt = 0, 0
    wipe(tracked); wipe(ownAuras); wipe(lastTargetAnnouncement); wipe(targetNotificationState); wipe(targetNotificationExecute); wipe(targetNotificationPriority); wipe(targetNotificationLast)
    if DamageLifeStatisticsEngine then DamageLifeStatisticsEngine:ResetAll() end
    refreshStatsUI()
end
function LS:SetEnabled(enabled)
    DamageLifeDB.enabled = enabled and true or false
    if DamageLifeDB.enabled then
        playerGUID = UnitGUID("player")
    else
        if DamageLifeStatisticsEngine and DamageLifeStatisticsEngine.DiscardActiveMatch then DamageLifeStatisticsEngine:DiscardActiveMatch() end
        wipe(tracked); wipe(ownAuras); wipe(unitsByGUID)
        streak, lastSaveAt = 0, 0
        widget.expires, widget.editMode = nil, false
        widget:Hide()
    end
end

frame:SetScript("OnEvent", function(self, event, ...)
    if event == "ADDON_LOADED" then
        if (...) ~= ADDON then return end
        deepDefaults()
        if DamageLifeTheme and DamageLifeTheme.SetFont then DamageLifeTheme:SetFont(DamageLifeDB.fontKey or "FRITZ") end
        setupWidget(); chat("загружен. /ls — настройки")
    elseif event == "PLAYER_ENTERING_WORLD" then
        local previousInstanceType = lastEnteredInstanceType
        playerGUID = UnitGUID("player")
        local _, kind = GetInstanceInfo(); currentInstanceType = kind or "none"
        if (previousInstanceType == "pvp" or previousInstanceType == "arena") and currentInstanceType ~= "pvp" and currentInstanceType ~= "arena" then streak, lastSaveAt = 0, 0 end
        lastEnteredInstanceType = currentInstanceType
        wipe(targetInspectQueue); wipe(targetInspectQueued); wipe(targetInspectedSpecs)
        refreshBattlegroundCounter()
        for i=1,TARGET_WINDOW_MAX do targetWindowApplyPosition(targetWindows[i], i) end; targetWindowUpdate()
    elseif event == "INSPECT_READY" then
        local guid = (...)
        if guid then
            local unit = nil
            if UnitGUID("target") == guid then unit = "target" end
            if not unit then
                for i = 1, 5 do
                    local candidate = "nameplate" .. i
                    if UnitExists(candidate) and UnitGUID(candidate) == guid then unit = candidate; break end
                end
            end
            if unit then
                local _, classToken = UnitClass(unit)
                local spec = targetWindowReadInspectSpec(guid, classToken)
                if spec then targetWindowUpdate() end
            elseif UnitGUID("target") == guid then
                local _, classToken = UnitClass("target")
                local spec = targetWindowReadInspectSpec(guid, classToken)
                if spec then targetWindowUpdate() end
            end
        end
    elseif event == "PLAYER_TARGET_CHANGED" then
        local guid = UnitGUID("target")
        if guid then
            local _, classToken = UnitClass("target")
            if classToken and UnitIsPlayer("target") then
                targetWindowQueueInspect("target", guid, classToken)
            end
        end
        targetWindowUpdate()
    elseif event == "PLAYER_DEAD" then
        streak, lastSaveAt = 0, 0
        for i=1,TARGET_WINDOW_MAX do targetWindows[i]:Hide() end
        wipe(tracked); wipe(ownAuras)
        wipe(targetInspectQueue); wipe(targetInspectQueued); wipe(targetInspectedSpecs)
        refreshStatsUI()
    elseif event == "PLAYER_REGEN_DISABLED" then inCombat = true; combatStats = { saves = 0, attempts = 0, failures = 0 }
    elseif event == "PLAYER_REGEN_ENABLED" then inCombat = false
    end
end)


-- DPS CombatEngine: после успешного UI-теста боевые события переводятся
-- из старой логики «спасений» в единый обработчик атакующих способностей.
local dpsDefinitionBySpellId = {}
local dpsDefinitionReady = false
local recentDpsAnnouncements = {}
local recentDpsCategoryAnnouncements = {}
local recentDpsCategorySounds = {}
local recentDpsDamage = {}

local dpsCategoryByKey = {
    WARRIOR_MORTAL_STRIKE = "CRITICAL", WARRIOR_BLADESTORM = "BURST", WARRIOR_EXECUTE = "EXECUTE", WARRIOR_RECKLESSNESS = "BURST",
    WARRIOR_OVERPOWER = "CRITICAL", WARRIOR_HEROIC_STRIKE = "CRITICAL", WARRIOR_WHIRLWIND = "CRITICAL", WARRIOR_HAMSTRING = "CONTROL",
    WARRIOR_CHARGE = "CONTROL", WARRIOR_INTERCEPT = "CONTROL", WARRIOR_PUMMEL = "CONTROL", WARRIOR_SHOCKWAVE = "CONTROL",
    WARRIOR_CONCUSSION_BLOW = "CONTROL", WARRIOR_SPELL_REFLECTION = "CONTROL",
    PALADIN_DIVINE_STORM = "CRITICAL", PALADIN_CRUSADER_STRIKE = "CRITICAL", PALADIN_HAMMER_WRATH = "EXECUTE", PALADIN_AVENGING_WRATH = "BURST",
    PALADIN_JUDGEMENT = "CRITICAL", PALADIN_CONSECRATION = "CRITICAL", PALADIN_EXORCISM = "CRITICAL", PALADIN_HAMMER_JUSTICE = "CONTROL",
    PALADIN_REPENTANCE = "CONTROL", PALADIN_DIVINE_SACRIFICE = "BURST", PALADIN_HAND_FREEDOM = "CONTROL", PALADIN_SEAL_COMMAND = "CRITICAL",
    HUNTER_CHIMERA_SHOT = "CRITICAL", HUNTER_AIMED_SHOT = "CRITICAL", HUNTER_KILL_SHOT = "EXECUTE", HUNTER_RAPID_FIRE = "BURST",
    HUNTER_STEADY_SHOT = "CRITICAL", HUNTER_ARCANE_SHOT = "CRITICAL", HUNTER_SERPENT_STING = "CRITICAL", HUNTER_EXPLOSIVE_SHOT = "CRITICAL",
    HUNTER_SILENCING_SHOT = "CONTROL", HUNTER_WING_CLIP = "CONTROL", HUNTER_FREEZING_TRAP = "CONTROL", HUNTER_BESTIAL_WRATH = "BURST", HUNTER_DISENGAGE = "CONTROL",
    ROGUE_EVISCERATE = "EXECUTE", ROGUE_KILLING_SPREE = "BURST", ROGUE_SHADOW_DANCE = "BURST", ROGUE_ADRENALINE_RUSH = "BURST",
    ROGUE_MUTILATE = "CRITICAL", ROGUE_SINISTER_STRIKE = "CRITICAL", ROGUE_HAMMER_SHIV = "CONTROL", ROGUE_KICK = "CONTROL",
    ROGUE_KIDNEY_SHOT = "CONTROL", ROGUE_GOUGE = "CONTROL", ROGUE_CHEAP_SHOT = "CONTROL", ROGUE_BLIND = "CONTROL", ROGUE_VANISH = "BURST",
    PRIEST_MIND_BLAST = "CRITICAL", PRIEST_SHADOW_WORD_DEATH = "EXECUTE", PRIEST_VAMPIRIC_TOUCH = "CRITICAL", PRIEST_MIND_FLAY = "CRITICAL",
    PRIEST_DEVOURING_PLAGUE = "CRITICAL", PRIEST_SW_PAIN = "CRITICAL", PRIEST_HOLY_FIRE = "CRITICAL", PRIEST_SILENCE = "CONTROL",
    PRIEST_PSYCHIC_SCREAM = "CONTROL", PRIEST_DISPERSION = "BURST",
    SHAMAN_LAVA_BURST = "CRITICAL", SHAMAN_STORMSTRIKE = "CRITICAL", SHAMAN_EARTH_SHOCK = "CONTROL", SHAMAN_BLOODLUST = "BURST",
    SHAMAN_FLAME_SHOCK = "CRITICAL", SHAMAN_FROST_SHOCK = "CONTROL", SHAMAN_CHAIN_LIGHTNING = "CRITICAL", SHAMAN_LIGHTNING_BOLT = "CRITICAL",
    SHAMAN_WINDFURY = "CRITICAL", SHAMAN_WIND_SHEAR = "CONTROL", SHAMAN_HEX = "CONTROL", SHAMAN_EARTHBIND = "CONTROL", SHAMAN_PURGE = "CONTROL",
    MAGE_FROSTBOLT = "CRITICAL", MAGE_ARCANE_BLAST = "CRITICAL", MAGE_DEEP_FREEZE = "CONTROL", MAGE_ICY_VEINS = "BURST",
    MAGE_FIREBALL = "CRITICAL", MAGE_FROSTFIRE_BOLT = "CRITICAL", MAGE_ICE_LANCE = "CRITICAL", MAGE_FIRE_BLAST = "CRITICAL",
    MAGE_PYROBLAST = "BURST", MAGE_LIVING_BOMB = "CRITICAL", MAGE_COUNTERSPELL = "CONTROL", MAGE_FROST_NOVA = "CONTROL",
    MAGE_POLYMORPH = "CONTROL", MAGE_BLINK = "BURST",
    WARLOCK_CHAOS_BOLT = "CRITICAL", WARLOCK_CONFLAGRATE = "CRITICAL", WARLOCK_SHADOW_BOLT = "CRITICAL", WARLOCK_DEATH_COIL = "CONTROL",
    WARLOCK_UNSTABLE_AFFLICTION = "CRITICAL", WARLOCK_CORRUPTION = "CRITICAL", WARLOCK_IMMOLATE = "CRITICAL", WARLOCK_INCINERATE = "CRITICAL",
    WARLOCK_HAUNT = "BURST", WARLOCK_FEAR = "CONTROL", WARLOCK_SHADOWFURY = "CONTROL", WARLOCK_SHADOWFLAME = "CRITICAL", WARLOCK_SOUL_FIRE = "EXECUTE",
    DRUID_STARFALL = "BURST", DRUID_WRATH = "CRITICAL", DRUID_FERAL_CHARGE = "CONTROL", DRUID_BERSERK = "BURST",
    DRUID_MOONFIRE = "CRITICAL", DRUID_STARFIRE = "CRITICAL", DRUID_INSECT_SWARM = "CRITICAL", DRUID_FERAL_RIP = "EXECUTE",
    DRUID_MAIM = "CONTROL", DRUID_SHRED = "CRITICAL", DRUID_FERAL_CHARGE_CAT = "CONTROL", DRUID_CYCLONE = "CONTROL", DRUID_BASH = "CONTROL",
    DEATHKNIGHT_FROST_STRIKE = "CRITICAL", DEATHKNIGHT_HOWLING_BLAST = "CRITICAL", DEATHKNIGHT_DEATH_STRIKE = "CRITICAL", DEATHKNIGHT_DANCING_RUNE_WEAPON = "BURST",
    DEATHKNIGHT_OBLITERATE = "CRITICAL", DEATHKNIGHT_DEATH_COIL = "CRITICAL", DEATHKNIGHT_ICY_TOUCH = "CRITICAL", DEATHKNIGHT_PLAGUE_STRIKE = "CRITICAL",
    DEATHKNIGHT_DEATH_AND_DECAY = "BURST", DEATHKNIGHT_STRANGULATE = "CONTROL", DEATHKNIGHT_MIND_FREEZE = "CONTROL", DEATHKNIGHT_DEATH_GRIP = "CONTROL",
    DEATHKNIGHT_CHAINS_ICE = "CONTROL", DEATHKNIGHT_ARMY_DEAD = "BURST",
}

local dpsCategoryInfo = {
    CRITICAL = { label = "Критический удар", texture = "Interface\\AddOns\\DamageLife\\Textures\\CombatCritical.tga", color = {1, 0.12, 0.08}, sound = "CRITICAL" },
    BURST = { label = "Бурст", texture = "Interface\\AddOns\\DamageLife\\Textures\\CombatBurst.tga", color = {1, 0.48, 0.08}, sound = "BURST" },
    EXECUTE = { label = "Добивание", texture = "Interface\\AddOns\\DamageLife\\Textures\\CombatExecute.tga", color = {1, 0.78, 0.08}, sound = "EXECUTE" },
    CONTROL = { label = "Контроль", texture = "Interface\\AddOns\\DamageLife\\Textures\\CombatControl.tga", color = {0.35, 0.65, 1}, sound = "CONTROL" },
}
for _, definition in ipairs(DamageLifeClassAbilityDefinitions or {}) do definition.category = dpsCategoryByKey[definition.key] or "CRITICAL" end
local function rebuildDpsDefinitions()
    if dpsDefinitionReady then return end
    wipe(dpsDefinitionBySpellId)
    -- Settings.lua loads after DamageLife.lua, so category assignment must happen here.
    for _, definition in ipairs(DamageLifeClassAbilityDefinitions or {}) do
        definition.category = dpsCategoryByKey[definition.key] or definition.category or "CRITICAL"
    end
    for _, definition in ipairs(DamageLifeClassAbilityDefinitions or {}) do
        for _, spellId in ipairs(definition.spellIds or {}) do
            dpsDefinitionBySpellId[spellId] = definition
        end
        if definition.spellId then dpsDefinitionBySpellId[definition.spellId] = definition end
    end
    dpsDefinitionReady = true
end

local function ensureDpsRuntimeConfig(definition)
    DamageLifeDB.abilitySettings = DamageLifeDB.abilitySettings or {}
    local config = DamageLifeDB.abilitySettings[definition.key]
    if type(config) ~= "table" then config = {}; DamageLifeDB.abilitySettings[definition.key] = config end
    config.phrases = type(config.phrases) == "table" and config.phrases or {}
    config.phraseEnabled = type(config.phraseEnabled) == "table" and config.phraseEnabled or {}
    if config.emote == nil then config.emote = DamageLifeDB.emoteEnabled ~= false end
    if config.whisper == nil then config.whisper = false end
    local defaults = definition.defaults or defaultPhrases
    for i, phrase in ipairs(defaults) do
        if config.phrases[i] == nil or config.phrases[i] == "" then config.phrases[i] = phrase end
        if i > 1 and config.phraseEnabled[i] == nil then config.phraseEnabled[i] = true end
    end
    return config
end

local function chooseDpsPhrase(definition, config)
    local choices = {}
    for i, phrase in ipairs(config.phrases or {}) do
        if phrase ~= "" and (config.phraseEnabled[i] ~= false) then choices[#choices + 1] = i end
    end
    if #choices == 0 then return (definition.defaults or defaultPhrases)[1] end
    local previous = config.lastPhraseIndex
    local pick = choices[math.random(#choices)]
    if #choices > 1 and pick == previous then
        for _, index in ipairs(choices) do if index ~= previous then pick = index; break end end
    end
    config.lastPhraseIndex = pick
    return config.phrases[pick]
end

local function dpsTargetAllowed(destGUID, destFlags)
    -- DPS combat events must also work against training dummies and hostile NPCs.
    -- The previous UI-era filter rejected every non-player destination unless
    -- includePets was enabled, so SPELL_DAMAGE from a mannequin never reached
    -- the category runtime.
    if not destGUID or destGUID == playerGUID then return false end
    if bit and bit.band and destFlags then
        if bit.band(destFlags, COMBATLOG_OBJECT_TYPE_PLAYER) ~= 0 then return true end
        if COMBATLOG_OBJECT_TYPE_NPC and bit.band(destFlags, COMBATLOG_OBJECT_TYPE_NPC) ~= 0 then return true end
        if DamageLifeDB.includePets then return true end
        return false
    end
    return true
end

local function dpsCastTargetAllowed(definition, event)
    -- Self-buffs and untargeted burst cooldowns have no enemy destination.
    -- They are still valid BURST category events.
    if definition and definition.category == "BURST" and event and event.type == "SPELL_CAST_SUCCESS" then
        return true
    end
    return dpsTargetAllowed(event and event.destGUID, event and event.destFlags)
end

local function categoryEnabled(category)
    local settings = DamageLifeDB.combatCategories or {}
    local key = type(category) == "string" and string.lower(category) or ""
    return settings[key] ~= false
end

local function targetHealthPercent(destGUID)
    if not destGUID then return nil end
    local targetUnit = UnitGUID and UnitGUID("target") == destGUID and "target" or nil
    if not targetUnit or not UnitExists(targetUnit) or UnitIsDeadOrGhost(targetUnit) then return nil end
    local maximum = UnitHealthMax(targetUnit)
    if not maximum or maximum <= 0 then return nil end
    return (UnitHealth(targetUnit) or 0) / maximum * 100
end

local function categoryTrigger(definition, event)
    if not definition or not event then return nil end
    local category = definition.category or "CRITICAL"
    if category == "CRITICAL" then
        return (event.type == "SPELL_DAMAGE" or event.type == "SPELL_PERIODIC_DAMAGE" or event.type == "RANGE_DAMAGE") and event.critical and true or false
    elseif category == "BURST" then
        return event.type == "SPELL_CAST_SUCCESS"
    elseif category == "EXECUTE" then
        if event.type ~= "SPELL_DAMAGE" and event.type ~= "SPELL_PERIODIC_DAMAGE" and event.type ~= "RANGE_DAMAGE" then return false end
        if (tonumber(event.overkill) or 0) > 0 then return true end
        local hp = targetHealthPercent(event.destGUID)
        return hp ~= nil and hp <= 20
    elseif category == "CONTROL" then
        return event.type == "SPELL_CAST_SUCCESS" or event.type == "SPELL_AURA_APPLIED" or event.type == "SPELL_AURA_APPLIED_DOSE"
    end
    return false
end

local function playCombatCategorySound(category, isTest)
    if not categoryEnabled(category) then return false end
    if not DamageLifeAbilitySounds or not DamageLifeAbilitySounds.Play then return false end
    local now = GetTime()
    local cooldown = isTest and 0 or 0.35
    if not isTest and recentDpsCategorySounds[category] and now - recentDpsCategorySounds[category] < cooldown then return false end
    recentDpsCategorySounds[category] = now
    return DamageLifeAbilitySounds:Play(category, "Combat", isTest) and true or false
end

local function announceDpsCategory(definition, event, category, isTest)
    if not categoryEnabled(category) then return false end
    local info = dpsCategoryInfo[category]
    if not info then return false end
    local now = GetTime()
    -- Sound is intentionally independent from the 1.5s visual/chat notification throttle.
    -- This lets real criticals/execute/control events on NPCs and players produce audio
    -- without flooding the screen or chat.
    playCombatCategorySound(category, isTest)
    local targetKey = event.destGUID or event.destName or "UNKNOWN"
    local key = category .. ":" .. tostring(targetKey)
    if not isTest and recentDpsCategoryAnnouncements[key] and now - recentDpsCategoryAnnouncements[key] < 1.5 then return false end
    recentDpsCategoryAnnouncements[key] = now
    local config = ensureDpsRuntimeConfig(definition)
    local targetName = event.destName or (event.destGUID == playerGUID and UnitName("player")) or UnitName("target") or "цель"
    local spellName = GetSpellLink(event.spellId) or event.spellName or definition.label or UNKNOWN
    local phrase = chooseDpsPhrase(definition, config)
    phrase = string.gsub(phrase, "{target}", targetName)
    phrase = string.gsub(phrase, "{spell}", spellName)
    local stats = DamageLifeDB.stats
    stats.categoryEvents = stats.categoryEvents or { CRITICAL = 0, BURST = 0, EXECUTE = 0, CONTROL = 0 }
    stats.categoryEvents[category] = (tonumber(stats.categoryEvents[category]) or 0) + 1
    stats.categoryBySpell = stats.categoryBySpell or {}
    stats.categoryByTarget = stats.categoryByTarget or {}
    local spellKey = definition.label or event.spellName or tostring(event.spellId)
    stats.categoryBySpell[category] = stats.categoryBySpell[category] or {}
    stats.categoryBySpell[category][spellKey] = (stats.categoryBySpell[category][spellKey] or 0) + 1
    stats.categoryByTarget[category] = stats.categoryByTarget[category] or {}
    stats.categoryByTarget[category][targetName] = (stats.categoryByTarget[category][targetName] or 0) + 1
    if DamageLifeDB.localChatEnabled then chat("|cff" .. (category == "CONTROL" and "66aaff" or category == "EXECUTE" and "ffcc33" or category == "BURST" and "ff7a22" or "ff3322") .. info.label .. ":|r " .. phrase) end
    if DamageLifeDB.screenEnabled then
        setupWidget(); widget.editMode = false; widget.mode = "dps"
        widget.title:SetText("|cff" .. (category == "CONTROL" and "66aaff" or category == "EXECUTE" and "ffcc33" or category == "BURST" and "ff7a22" or "ff3322") .. info.label .. "|r")
        widget.name:SetText("|cffffd67a" .. targetName .. "|r")
        widget.subtitle:SetText("|cffd8d2c4" .. (definition.label or spellName) .. "|r")
        widget.categoryIcon:SetTexture(info.texture); widget.categoryIcon:Show()
        widget.categoryIcon:SetVertexColor(1, 1, 1, 1)
        setRewardPortrait(event.destGUID and unitsByGUID[event.destGUID] or "target")
        widget.duration = 2.5; widget.animationStart = now; widget.expires = now + widget.duration; widget.bar:SetValue(1); widget:SetAlpha(1); widget:Show()
    end
    if not isTest and config.emote and DamageLifeDB.emoteEnabled ~= false and canPublicEmote() and now - lastEmoteAt >= (DamageLifeDB.emoteCooldown or 3) then
        SendChatMessage(phrase, "EMOTE"); lastEmoteAt = now
    end
    if not isTest and config.whisper and event.destName and canWhisperTarget(event.destName, event.destGUID, event.destFlags) then
        SendChatMessage(phrase, "WHISPER", nil, event.destName)
    end
    return true
end

local function announceDpsAbility(definition, event, isTest)
    if not definition or not DamageLifeDB.enabled then return end
    local config = ensureDpsRuntimeConfig(definition)
    if DamageLifeDB[definition.setting] == false then return end
    local now = GetTime()
    local targetKey = event.destGUID or "UNKNOWN"
    local recentKey = definition.key .. ":" .. targetKey
    if not isTest and recentDpsAnnouncements[recentKey] and now - recentDpsAnnouncements[recentKey] < 1.5 then return end
    recentDpsAnnouncements[recentKey] = now

    local spellLink = GetSpellLink(event.spellId) or event.spellName or definition.label or UNKNOWN
    local targetName = event.destName or UnitName("target") or "цель"
    local phrase = chooseDpsPhrase(definition, config)
    phrase = string.gsub(phrase, "{target}", targetName)
    phrase = string.gsub(phrase, "{spell}", spellLink)

    local stats = DamageLifeDB.stats
    stats.abilityCasts = (tonumber(stats.abilityCasts) or 0) + 1
    stats.bySpell = stats.bySpell or {}; stats.byTarget = stats.byTarget or {}
    stats.bySpell[definition.label or event.spellName or tostring(event.spellId)] = (stats.bySpell[definition.label or event.spellName or tostring(event.spellId)] or 0) + 1
    stats.byTarget[targetName] = (stats.byTarget[targetName] or 0) + 1

    if DamageLifeDB.localChatEnabled then
        chat(phrase .. (isTest and " |cffaaaaaa(тест)|r" or ""))
    end
    if DamageLifeDB.screenEnabled then
        setupWidget(); widget.editMode = false; widget.mode = "dps"
        local category = definition.category or "CRITICAL"
        local info = dpsCategoryInfo[category]
        local hex = category == "CONTROL" and "66aaff" or category == "EXECUTE" and "ffcc33" or category == "BURST" and "ff7a22" or "ff3322"
        widget.title:SetText("|cff" .. hex .. (info and info.label or (isTest and "DAMAGE TEST" or "DAMAGE EVENT")) .. "|r")
        widget.name:SetText("|cffff4d3d" .. targetName .. "|r")
        widget.subtitle:SetText("|cffd8d2c4" .. (definition.label or event.spellName or "Способность") .. "|r")
        local category = definition.category or "CRITICAL"
        local info = dpsCategoryInfo[category]
        if info then widget.categoryIcon:SetTexture(info.texture); widget.categoryIcon:Show() else widget.categoryIcon:Hide() end
        setRewardPortrait(event.destGUID and unitsByGUID[event.destGUID] or "target")
        widget.duration = 2.5; widget.animationStart = now; widget.expires = now + widget.duration; widget.bar:SetValue(1); widget:SetAlpha(1); widget:Show()
    end
    if DamageLifeAbilitySounds then DamageLifeAbilitySounds:Play(definition.key, "Class") end

    if not isTest and config.emote and DamageLifeDB.emoteEnabled ~= false and canPublicEmote() and now - lastEmoteAt >= (DamageLifeDB.emoteCooldown or 3) then
        SendChatMessage(phrase, "EMOTE")
        lastEmoteAt = now
    end
    if not isTest and config.whisper and event.destName and dpsTargetAllowed(event.destGUID, event.destFlags) then
        SendChatMessage(phrase, "WHISPER", nil, event.destName)
    end
end

local function recordDpsDamage(definition, event)
    if not definition or not DamageLifeDB.enabled then return end
    local stats = DamageLifeDB.stats
    stats.totalDamageEvents = (tonumber(stats.totalDamageEvents) or 0) + 1
    stats.bySpell = stats.bySpell or {}; stats.byTarget = stats.byTarget or {}
    local spellLabel = definition.label or event.spellName or tostring(event.spellId)
    local targetName = event.destName or "цель"
    stats.bySpell[spellLabel] = (stats.bySpell[spellLabel] or 0) + 1
    stats.byTarget[targetName] = (stats.byTarget[targetName] or 0) + 1
    if event.critical then stats.criticalHits = (tonumber(stats.criticalHits) or 0) + 1 end
    local now = GetTime()
    local key = definition.key .. ":" .. tostring(event.destGUID or targetName)
    if recentDpsDamage[key] and now - recentDpsDamage[key] < 1 then return end
    recentDpsDamage[key] = now
    if now - lastSaveAt > (DamageLifeDB.streakWindow or 20) then streak = 0 end
    streak, lastSaveAt = streak + 1, now
    if streak > (tonumber(stats.bestStreak) or 0) then stats.bestStreak = streak; DamageLifeDB.bestStreak = streak end
end

local function onDpsCombatEvent(event, ...)
    if not event or not DamageLifeDB or not DamageLifeDB.enabled then return end
    if not playerGUID then playerGUID = UnitGUID("player") end
    rebuildDpsDefinitions()
    if event.sourceGUID ~= playerGUID then return end
    local definition = event.spellId and dpsDefinitionBySpellId[event.spellId]
    if not definition then return end
    if event.type == "SPELL_CAST_SUCCESS" then
        if dpsCastTargetAllowed(definition, event) then
            announceDpsAbility(definition, event, false)
            local category = definition.category or "CRITICAL"
            if categoryTrigger(definition, event) and category ~= "CRITICAL" then
                announceDpsCategory(definition, event, category, false)
            end
        end
    elseif event.type == "SPELL_DAMAGE" or event.type == "SPELL_PERIODIC_DAMAGE" or event.type == "RANGE_DAMAGE" then
        if dpsTargetAllowed(event.destGUID, event.destFlags) then
            recordDpsDamage(definition, event)
            if categoryTrigger(definition, event) then
                announceDpsCategory(definition, event, definition.category or "CRITICAL", false)
            end
        end
    elseif event.type == "SPELL_AURA_APPLIED" or event.type == "SPELL_AURA_APPLIED_DOSE" then
        if dpsTargetAllowed(event.destGUID, event.destFlags) and categoryTrigger(definition, event) and (definition.category or "CRITICAL") == "CONTROL" then
            announceDpsCategory(definition, event, "CONTROL", false)
        end
    end
end

if DamageLifeCombatEngine then
    DamageLifeCombatEngine:RegisterSubscriber("TargetProfileTracker", function(event)
        if not event or not event.spellId or not event.sourceGUID then return end
        if event.type == "SPELL_CAST_SUCCESS" or event.type == "SPELL_AURA_APPLIED" then
            local playerFlags = event.sourceFlags or 0
            if bit and bit.band and COMBATLOG_OBJECT_REACTION_HOSTILE then
                if bit.band(playerFlags, COMBATLOG_OBJECT_REACTION_HOSTILE) ~= 0 then
                    targetWindowObserveSpell(event.sourceGUID, event.spellId, event.spellName)
                end
            else
                targetWindowObserveSpell(event.sourceGUID, event.spellId, event.spellName)
            end
        end
    end, 14)

    DamageLifeCombatEngine:RegisterSubscriber("TargetDefenseTracker", function(event)
        if not event or not event.spellId then return end
        local guid = UnitGUID("target")
        if not guid then return end
        local trackedIds = targetDefensiveNames[event.spellId]
        if not trackedIds then return end
        if event.type == "SPELL_CAST_SUCCESS" and event.sourceGUID == guid then
            targetDefenseHistory[guid] = targetDefenseHistory[guid] or {}; targetDefenseHistory[guid][event.spellId] = GetTime()
        elseif (event.type == "SPELL_AURA_APPLIED" or event.type == "SPELL_AURA_APPLIED_DOSE") and event.destGUID == guid then
            targetDefenseHistory[guid] = targetDefenseHistory[guid] or {}; targetDefenseHistory[guid][event.spellId] = GetTime()
        end
    end, 15)
end

-- CombatEngine: единый DPS-поток. Старый RescueEngine здесь больше не регистрируется,
-- поэтому интерфейс DamageLife не генерирует healer-спасения после перехода на DPS-логику.
if DamageLifeCombatEngine then
    DamageLifeCombatEngine:RegisterSubscriber("DPSCombatEngine", onDpsCombatEvent, 20)
end

frame:SetScript("OnUpdate", function(self, elapsed)
    if not DamageLifeDB or not DamageLifeDB.enabled then return end
    targetWindowTick(elapsed)
    targetWindowProcessInspectQueue()
    elapsedSinceScan = elapsedSinceScan + elapsed
    if elapsedSinceScan >= 0.50 then
        elapsedSinceScan = 0
        if streak > 0 and GetTime() - lastSaveAt > DamageLifeDB.streakWindow then streak = 0 end
    end
end)

for _, event in ipairs({ "ADDON_LOADED", "PLAYER_ENTERING_WORLD", "PLAYER_TARGET_CHANGED", "INSPECT_READY", "PLAYER_DEAD", "PLAYER_REGEN_DISABLED", "PLAYER_REGEN_ENABLED" }) do frame:RegisterEvent(event) end

SLASH_DAMAGELIFE1, SLASH_DAMAGELIFE2 = "/damagelife", "/dl"
SlashCmdList["DAMAGELIFE"] = function(message)
    local command, value = string.match(string.lower(message or ""), "^(%S*)%s*(.-)$")
    if command == "" or command == "config" or command == "options" then if DamageLife_OpenConfig then DamageLife_OpenConfig() end
    elseif command == "on" or command == "off" then LS:SetEnabled(command == "on"); chat(DamageLifeDB.enabled and "включён" or "выключен")
    elseif command == "debug" then DamageLifeDB.debug = value == "on"; chat("режим проверки " .. (DamageLifeDB.debug and "включён" or "выключен"))
    elseif command == "test" then
        if not DamageLifeDB.enabled then chat("выключен — сначала включите DamageLife")
        else rebuildDpsDefinitions(); local definition = (DamageLifeClassAbilityDefinitions or {})[1]; if definition then announceDpsAbility(definition, { spellId = definition.spellId, spellName = definition.label, destGUID = UnitGUID("target"), destName = UnitName("target") or "цель", destFlags = 0 }, true) end end
    elseif command == "testcategory" then
        rebuildDpsDefinitions()
        local input = type(value) == "string" and string.lower(value) or ""
        local aliases = { critical = "CRITICAL", crit = "CRITICAL", burst = "BURST", execute = "EXECUTE", control = "CONTROL" }
        local wanted = aliases[input]
        if not wanted then chat("категория не найдена: critical, burst, execute, control") return end
        local definition
        for _, candidate in ipairs(DamageLifeClassAbilityDefinitions or {}) do
            if (candidate.category or "CRITICAL") == wanted then definition = candidate break end
        end
        if definition then
            announceDpsCategory(definition, { spellId = definition.spellId, spellName = definition.label, destGUID = UnitGUID("target"), destName = UnitName("target") or "цель", destFlags = 0, type = wanted == "CRITICAL" and "SPELL_DAMAGE" or wanted == "BURST" and "SPELL_CAST_SUCCESS" or wanted == "EXECUTE" and "SPELL_DAMAGE" or "SPELL_AURA_APPLIED", critical = wanted == "CRITICAL", overkill = wanted == "EXECUTE" and 1 or 0 }, wanted, true)
            if DamageLifeAbilitySounds and DamageLifeAbilitySounds.Play then
                local soundOK = playCombatCategorySound(wanted, true)
                chat("тест категории: " .. wanted .. (soundOK and " — звук OK" or " — звук НЕ НАЙДЕН"))
            else
                chat("тест категории: " .. wanted .. " — звуковой модуль недоступен")
            end
        else
            chat("категория не найдена: " .. wanted)
        end
    elseif command == "reset" then LS:ResetStats(); chat("статистика сброшена")
    elseif command == "status" then chat("урона: " .. (DamageLifeDB.stats.totalDamageEvents or 0) .. ", применений: " .. (DamageLifeDB.stats.abilityCasts or 0) .. ", критов: " .. (DamageLifeDB.stats.criticalHits or 0) .. ", рекорд серии: " .. (DamageLifeDB.stats.bestStreak or 0))
    else chat("/dl, /dl test, /dl testcategory critical|burst|execute|control, /dl status, /dl debug on|off, /dl reset") end
end
