DamageLifeAbilitySounds = DamageLifeAbilitySounds or {}
local Sounds = DamageLifeAbilitySounds

local ROOT = "Interface\\AddOns\\DamageLife\\Sounds\\Custom\\"
local CATEGORY_ROOT = "Interface\\AddOns\\DamageLife\\Sounds\\Voice\\"
local discoveredDefaults = {
    Class = {},
    Control = {},
    Combat = { CRITICAL = "CRITICAL.mp3", BURST = "BURST.mp3", EXECUTE = "EXECUTE.mp3", CONTROL = "CONTROL.mp3" },
}

local function settings()
    DamageLifeDB.abilitySounds = DamageLifeDB.abilitySounds or { enabled = {}, files = {} }
    DamageLifeDB.abilitySounds.enabled = DamageLifeDB.abilitySounds.enabled or {}
    DamageLifeDB.abilitySounds.files = DamageLifeDB.abilitySounds.files or {}
    return DamageLifeDB.abilitySounds
end

local function fileKey(key, category)
    return tostring(category or "Class") .. ":" .. tostring(key)
end

local function cleanFileName(fileName)
    fileName = tostring(fileName or "")
    fileName = string.match(fileName, "([^\\/]+)$") or ""
    local extension = string.match(string.lower(fileName), "%.([%w]+)$")
    if extension ~= "ogg" and extension ~= "mp3" and extension ~= "wav" then return "" end
    return fileName
end

function Sounds:GetFileName(key, category)
    category = category or "Class"
    local saved = cleanFileName(settings().files[fileKey(key, category)])
    local detected = discoveredDefaults[category] and discoveredDefaults[category][key]
    -- Старые версии записывали sound.ogg в SavedVariables даже тогда, когда
    -- пользователь положил в папку файл с другим именем. Для известных файлов
    -- сборки один раз заменяем это устаревшее значение автоматически.
    if detected and (saved == "" or string.lower(saved) == "sound.ogg") then
        detected = cleanFileName(detected)
        settings().files[fileKey(key, category)] = detected
        return detected
    end
    if saved ~= "" then return saved end
    return cleanFileName(detected) ~= "" and detected or "sound.ogg"
end

function Sounds:SetFileName(key, category, fileName)
    local cleaned = cleanFileName(fileName)
    if cleaned == "" then return false end
    settings().files[fileKey(key, category)] = cleaned
    return true
end

function Sounds:GetPath(key, category)
    category = category or "Class"
    if category == "Combat" then
        return CATEGORY_ROOT .. self:GetFileName(key, category)
    end
    return ROOT .. category .. "\\" .. tostring(key) .. "\\" .. self:GetFileName(key, category)
end

function Sounds:IsEnabled(key)
    return settings().enabled[key] == true
end

function Sounds:SetEnabled(key, enabled)
    settings().enabled[key] = enabled and true or false
end

function Sounds:Play(key, category, force)
    category = category or "Class"
    local enabled
    if category == "Combat" then
        local combat = DamageLifeDB and DamageLifeDB.combatSoundEnabled
        enabled = combat and combat[key] ~= false
    else
        enabled = self:IsEnabled(key)
    end
    if not force and not enabled then return false end
    local path = self:GetPath(key, category)
    local ok = PlaySoundFile(path, "Master")
    if force and DEFAULT_CHAT_FRAME then
        if ok then
            DEFAULT_CHAT_FRAME:AddMessage("|cff7CFC00DamageLife:|r звук воспроизведения: " .. path)
        else
            DEFAULT_CHAT_FRAME:AddMessage("|cffff3333DamageLife:|r звук не найден/не загружен: " .. path)
        end
    end
    return ok and true or false
end

function Sounds:GetFolderHint(key, category)
    category = category or "Class"
    return "Sounds\\Custom\\" .. category .. "\\" .. tostring(key) .. "\\" .. self:GetFileName(key, category)
end
