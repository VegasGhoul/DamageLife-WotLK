local ADDON = ...

DamageLifeCombatEngine = DamageLifeCombatEngine or {}
local Engine = DamageLifeCombatEngine

local subscribers = Engine.subscribers or {}
Engine.subscribers = subscribers
Engine.event = Engine.event or {}

local function sortSubscribers()
    table.sort(subscribers, function(left, right)
        if left.priority == right.priority then return left.id < right.id end
        return left.priority < right.priority
    end)
end

function Engine:RegisterSubscriber(id, callback, priority)
    if type(id) ~= "string" or type(callback) ~= "function" then return false end
    for _, subscriber in ipairs(subscribers) do
        if subscriber.id == id then
            subscriber.callback = callback
            subscriber.priority = priority or subscriber.priority or 100
            sortSubscribers()
            return true
        end
    end
    subscribers[#subscribers + 1] = { id = id, callback = callback, priority = priority or 100 }
    sortSubscribers()
    return true
end

function Engine:UnregisterSubscriber(id)
    for index = #subscribers, 1, -1 do
        if subscribers[index].id == id then table.remove(subscribers, index) end
    end
end

local function clearPayload(event)
    event.spellId, event.spellName, event.spellSchool = nil, nil, nil
    event.extraSpellId, event.extraSpellName, event.extraSpellSchool = nil, nil, nil
    event.amount, event.overhealing, event.overkill = 0, 0, 0
    event.absorbed, event.resisted, event.blocked = 0, 0, 0
    event.critical, event.missType, event.auraType = false, nil, nil
    event.environmentalType = nil
end

-- select() can return several values; passing it directly to tonumber lets
-- Lua interpret the next combat-log field as tonumber's numeric base.
local function numberAt(index, ...)
    local value = select(index, ...)
    return tonumber(value) or 0
end

local function normalize(...)
    local event = Engine.event
    clearPayload(event)

    event.timestamp = select(1, ...)
    event.type = select(2, ...)
    event.sourceGUID = select(3, ...)
    event.sourceName = select(4, ...)
    event.sourceFlags = select(5, ...)
    event.destGUID = select(6, ...)
    event.destName = select(7, ...)
    event.destFlags = select(8, ...)

    local eventType = event.type or ""
    local payload = 9
    if string.sub(eventType, 1, 6) == "SWING_" then
        if eventType == "SWING_DAMAGE" then
            event.amount = numberAt(9, ...)
            event.overkill = numberAt(10, ...)
            event.spellSchool = select(11, ...)
            event.resisted = numberAt(12, ...)
            event.blocked = numberAt(13, ...)
            event.absorbed = numberAt(14, ...)
            event.critical = select(15, ...) and true or false
        elseif eventType == "SWING_MISSED" then
            event.missType = select(9, ...)
            event.absorbed = numberAt(10, ...)
        end
        return event
    elseif string.sub(eventType, 1, 14) == "ENVIRONMENTAL_" then
        event.environmentalType = select(9, ...)
        payload = 10
    else
        event.spellId = select(9, ...)
        event.spellName = select(10, ...)
        event.spellSchool = select(11, ...)
        payload = 12
    end

    if string.find(eventType, "_HEAL$") then
        event.amount = numberAt(payload, ...)
        event.overhealing = numberAt(payload + 1, ...)
        event.critical = select(payload + 2, ...) and true or false
    elseif string.find(eventType, "_DAMAGE$") then
        event.amount = numberAt(payload, ...)
        event.overkill = numberAt(payload + 1, ...)
        if eventType ~= "ENVIRONMENTAL_DAMAGE" then event.spellSchool = select(payload + 2, ...) end
        event.resisted = numberAt(payload + 3, ...)
        event.blocked = numberAt(payload + 4, ...)
        event.absorbed = numberAt(payload + 5, ...)
        event.critical = select(payload + 6, ...) and true or false
    elseif string.find(eventType, "_MISSED$") then
        event.missType = select(payload, ...)
        event.absorbed = numberAt(payload + 1, ...)
    elseif eventType == "SPELL_DISPEL" or eventType == "SPELL_STOLEN" or eventType == "SPELL_INTERRUPT" then
        event.extraSpellId = select(12, ...)
        event.extraSpellName = select(13, ...)
        event.extraSpellSchool = select(14, ...)
        event.auraType = select(15, ...)
    elseif string.find(eventType, "^SPELL_AURA_") then
        event.auraType = select(12, ...)
    end
    return event
end

local frame = CreateFrame("Frame")
frame:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED")
frame:SetScript("OnEvent", function(self, wowEvent, ...)
    if DamageLifeDB and DamageLifeDB.enabled == false then return end
    local event = normalize(...)
    for _, subscriber in ipairs(subscribers) do
        if DamageLifeDB and DamageLifeDB.debug then
            local ok, errorMessage = pcall(subscriber.callback, event, ...)
            if not ok and DEFAULT_CHAT_FRAME then
                DEFAULT_CHAT_FRAME:AddMessage("|cffff5555DamageLife CombatEngine [" .. subscriber.id .. "]:|r " .. tostring(errorMessage))
            end
        else
            subscriber.callback(event, ...)
        end
    end
end)

function Engine:GetSubscriberCount() return #subscribers end
