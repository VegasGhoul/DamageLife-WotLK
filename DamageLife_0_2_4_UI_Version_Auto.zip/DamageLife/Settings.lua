local function DamageLife_GetCurrentVersion()
    local version = GetAddOnMetadata and GetAddOnMetadata("DamageLife", "Version")
    if version and version ~= "" then
        return version
    end
    return "UNKNOWN"
end

local function T(key, fallback) return DamageLifeLocale and DamageLifeLocale:Get(key, fallback) or fallback end
local applyLanguage
local layoutToggle, syncLayoutToggle

local window = CreateFrame("Frame", "DamageLifeConfigFrame", UIParent)
window:SetSize(760, 680); window:SetPoint("CENTER", UIParent, "CENTER", 66, 0); window:SetFrameStrata("DIALOG")
window:SetClampedToScreen(true); window:SetMovable(true); window:EnableMouse(true); window:RegisterForDrag("LeftButton")
window:SetScript("OnDragStart", function(self) self:StartMoving() end)
window:SetScript("OnDragStop", function(self) self:StopMovingOrSizing() end)
DamageLifeTheme:StyleWindow(window)
window:Hide()

local titleFrame = CreateFrame("Frame", nil, window)
titleFrame:SetSize(560, 34); titleFrame:SetPoint("BOTTOM", window, "TOP", 0, 2)
titleFrame:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8" }); titleFrame:SetBackdropColor(0.008, 0.010, 0.014, 0.97)
titleFrame:SetMovable(true); titleFrame:SetClampedToScreen(true)
titleFrame:EnableMouse(true); titleFrame:RegisterForDrag("LeftButton")
DamageLifeTheme:CreateGradientLine(titleFrame, "BOTTOM", 0, 560, 2)
local title = titleFrame:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge"); title:SetPoint("CENTER", -18, 0)
title:SetText("|cffffd100DamageLife|r")

local close = CreateFrame("Button", nil, titleFrame); close:SetSize(42, 26); close:SetPoint("RIGHT", -8, 0)
close:SetFontString(close:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")); close:GetFontString():SetAllPoints(); close:SetText("X")
close:SetScript("OnClick", function() window:Hide() end)
close:SetScript("OnEnter", function(self) self:GetFontString():SetTextColor(1, 1, 1) end)
close:SetScript("OnLeave", function(self) self:GetFontString():SetTextColor(1, 0.82, 0) end)

local sidebar = CreateFrame("Frame", nil, window); sidebar:SetSize(150, 650); sidebar:SetPoint("RIGHT", window, "LEFT", -2, 0)
sidebar:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", edgeSize = 8, insets = { left = 2, right = 2, top = 2, bottom = 2 } }); sidebar:SetBackdropColor(0.008, 0.010, 0.014, 0.96); sidebar:SetBackdropBorderColor(0.22, 0.25, 0.29, 0.90)
local content = CreateFrame("Frame", nil, window); content:SetAllPoints(window)

local statusFrame = CreateFrame("Frame", nil, window); statusFrame:SetSize(220, 30); statusFrame:SetPoint("TOPRIGHT", window, "BOTTOMRIGHT", -18, -2)
statusFrame:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8" }); statusFrame:SetBackdropColor(0.008, 0.010, 0.014, 0.97)
DamageLifeTheme:CreateGradientLine(statusFrame, "TOP", 0, 220, 2)

local languageDefs = {
    { key = "ruRU", label = "Русский", colors = {{1,1,1}, {0.05,0.25,0.75}, {0.75,0.05,0.08}} },
    { key = "enUS", label = "English", usa = true },
    { key = "deDE", label = "Deutsch", colors = {{0.03,0.03,0.03}, {0.75,0.02,0.03}, {1,0.75,0.05}} },
    { key = "frFR", label = "Français", vertical = true, colors = {{0.03,0.2,0.65}, {1,1,1}, {0.8,0.04,0.08}} },
    { key = "esES", label = "Español", colors = {{0.75,0.02,0.04}, {1,0.78,0.08}, {0.75,0.02,0.04}} },
}
local languageNormalFont = _G.DamageLifeLanguageNormal or CreateFont("DamageLifeLanguageNormal")
languageNormalFont:SetFont("Fonts\\FRIZQT__.TTF", 14, ""); languageNormalFont:SetTextColor(0.94, 0.94, 0.94, 1)
local languageHighlightFont = _G.DamageLifeLanguageHighlight or CreateFont("DamageLifeLanguageHighlight")
languageHighlightFont:SetFont("Fonts\\FRIZQT__.TTF", 14, ""); languageHighlightFont:SetTextColor(1, 0.82, 0, 1)
local function updateFlag(flag, definition)
    for _, texture in ipairs(flag.usaLayers or {}) do texture:Hide() end
    for i, stripe in ipairs(flag.stripes or {}) do
        stripe:Hide()
        local color = definition.colors and definition.colors[i]
        if color then stripe:SetVertexColor(color[1], color[2], color[3], 1); stripe:ClearAllPoints()
        if definition.vertical then
            stripe:SetPoint("TOPLEFT", 2 + (i - 1) * ((flag.flagWidth - 4) / 3), -2); stripe:SetSize((flag.flagWidth - 4) / 3, flag.flagHeight - 4)
        else
            stripe:SetPoint("TOPLEFT", 2, -2 - (i - 1) * ((flag.flagHeight - 4) / 3)); stripe:SetSize(flag.flagWidth - 4, (flag.flagHeight - 4) / 3)
        end
        stripe:Show()
        end
    end
    if definition.usa then for _, texture in ipairs(flag.usaLayers or {}) do texture:Show() end end
end
local function addFlag(parent, width, height, definition)
    local flag = CreateFrame("Frame", nil, parent); flag:SetSize(width, height)
    flag:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", edgeSize = 5, insets = { left = 1, right = 1, top = 1, bottom = 1 } })
    flag:SetBackdropColor(0, 0, 0, 1); flag:SetBackdropBorderColor(0.65, 0.52, 0.18, 1)
    flag.flagWidth, flag.flagHeight, flag.stripes, flag.usaLayers = width, height, {}, {}
    for i = 1, 3 do
        local stripe = flag:CreateTexture(nil, "ARTWORK"); stripe:SetTexture("Interface\\Buttons\\WHITE8X8")
        flag.stripes[i] = stripe
    end
    local innerWidth, innerHeight = width - 4, height - 4
    for i = 1, 7 do
        local stripe = flag:CreateTexture(nil, "ARTWORK"); stripe:SetTexture("Interface\\Buttons\\WHITE8X8")
        stripe:SetVertexColor(i % 2 == 1 and 0.72 or 1, i % 2 == 1 and 0.03 or 1, i % 2 == 1 and 0.06 or 1, 1)
        stripe:SetPoint("TOPLEFT", 2, -2 - (i - 1) * (innerHeight / 7)); stripe:SetSize(innerWidth, innerHeight / 7 + 0.2)
        flag.usaLayers[#flag.usaLayers + 1] = stripe
    end
    local canton = flag:CreateTexture(nil, "OVERLAY"); canton:SetTexture("Interface\\Buttons\\WHITE8X8"); canton:SetVertexColor(0.03, 0.16, 0.43, 1)
    canton:SetPoint("TOPLEFT", 2, -2); canton:SetSize(innerWidth * 0.46, innerHeight * 0.57); flag.usaLayers[#flag.usaLayers + 1] = canton
    for row = 1, 2 do for column = 1, 3 do
        local star = flag:CreateTexture(nil, "OVERLAY"); star:SetTexture("Interface\\Buttons\\WHITE8X8"); star:SetVertexColor(1, 1, 1, 0.95)
        star:SetSize(1.2, 1.2); star:SetPoint("TOPLEFT", 3 + column * 2.3, -2.3 - row * 2.1); flag.usaLayers[#flag.usaLayers + 1] = star
    end end
    updateFlag(flag, definition)
    return flag
end
local languageButton = CreateFrame("Button", nil, statusFrame)
languageButton:SetSize(206, 26); languageButton:SetPoint("CENTER", 0, -1)
languageButton:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8" }); languageButton:SetBackdropColor(0.02, 0.015, 0.01, 0.55)
local languageButtonFlag = addFlag(languageButton, 25, 17, languageDefs[1]); languageButtonFlag:SetPoint("LEFT", 10, 0)
local languageButtonText = languageButton:CreateFontString(nil, "OVERLAY", "GameFontHighlight"); languageButtonText:SetPoint("LEFT", 44, 0); languageButtonText:SetText("Русский")
languageButtonText:SetFont("Fonts\\FRIZQT__.TTF", 14, ""); languageButtonText.lsKeepFont = true

local languagePopup = CreateFrame("Frame", nil, statusFrame)
languagePopup:SetSize(206, 146); languagePopup:SetPoint("BOTTOMRIGHT", statusFrame, "TOPRIGHT", -7, 4); languagePopup:SetFrameStrata("TOOLTIP")
languagePopup:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", edgeSize = 9, insets = { left = 3, right = 3, top = 3, bottom = 3 } })
languagePopup:SetBackdropColor(0.018, 0.012, 0.008, 0.97); languagePopup:SetBackdropBorderColor(0.7, 0.5, 0.08, 1); languagePopup:Hide()
local languageButtons = {}
local function selectLanguage(definition)
    DamageLifeDB.language = definition.key
    languageButtonText:SetText(definition.label)
    updateFlag(languageButtonFlag, definition)
    for key, button in pairs(languageButtons) do DamageLifeTheme:SetNavSelected(button, key == definition.key) end
    languagePopup:Hide()
    if DamageLifeTheme and DamageLifeTheme.SetFont then DamageLifeTheme:SetFont(DamageLifeDB.fontKey or "FRITZ") end
    if applyLanguage then applyLanguage() end
end
for i, definition in ipairs(languageDefs) do
    local languageDefinition = definition
    local row = CreateFrame("Button", nil, languagePopup); row:SetSize(196, 27); row:SetPoint("TOPLEFT", 5, -5 - (i - 1) * 27); row:SetText(languageDefinition.label)
    DamageLifeTheme:StyleNavButton(row)
    row:SetNormalFontObject(languageNormalFont); row:SetHighlightFontObject(languageHighlightFont)
    local rowText = row:GetFontString(); rowText:ClearAllPoints(); rowText:SetPoint("LEFT", 43, 0); rowText:SetJustifyH("LEFT"); rowText.lsKeepFont = true
    local flag = addFlag(row, 25, 17, languageDefinition); flag:SetPoint("LEFT", 9, 0)
    row:SetScript("OnClick", function() selectLanguage(languageDefinition) end); languageButtons[languageDefinition.key] = row
end
languageButton:SetScript("OnClick", function()
    if languagePopup:IsShown() then languagePopup:Hide() else languagePopup:Show() end
end)

local minimized = false
titleFrame:SetScript("OnDragStart", function(self)
    if minimized then self:StartMoving() else window:StartMoving() end
end)
titleFrame:SetScript("OnDragStop", function(self)
    if minimized then self:StopMovingOrSizing() else window:StopMovingOrSizing() end
end)
local minimize = CreateFrame("Button", nil, titleFrame); minimize:SetSize(34, 26); minimize:SetPoint("RIGHT", close, "LEFT", -2, 0)
minimize.lsThemeStyled = true
minimize:SetFontString(minimize:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")); minimize:GetFontString():SetAllPoints(); minimize:SetText("—")
minimize:SetScript("OnClick", function(self)
    minimized = not minimized
    if minimized then
        local x, y = titleFrame:GetCenter()
        titleFrame:ClearAllPoints(); titleFrame:SetPoint("CENTER", UIParent, "BOTTOMLEFT", x or UIParent:GetWidth() / 2, y or UIParent:GetHeight() / 2)
        sidebar:Hide(); content:Hide(); statusFrame:Hide(); window:EnableMouse(false)
    else
        local x = ((titleFrame:GetLeft() or 0) + (titleFrame:GetRight() or 0)) / 2
        local top = (titleFrame:GetBottom() or UIParent:GetHeight() / 2) - 2
        window:ClearAllPoints(); window:SetPoint("TOP", UIParent, "BOTTOMLEFT", x, top)
        titleFrame:ClearAllPoints(); titleFrame:SetPoint("BOTTOM", window, "TOP", 0, 2)
        sidebar:Show(); content:Show(); statusFrame:Show(); window:EnableMouse(true)
    end
    for _, texture in ipairs(window.lsWindowTextures or {}) do if minimized then texture:Hide() else texture:Show() end end
end)
minimize:SetScript("OnEnter", function(self) self:GetFontString():SetTextColor(1, 1, 1) end)
minimize:SetScript("OnLeave", function(self) self:GetFontString():SetTextColor(1, 0.82, 0) end)
layoutToggle = CreateFrame("CheckButton", "LSGlobalPanelLayoutToggle", titleFrame, "InterfaceOptionsCheckButtonTemplate")
layoutToggle:SetSize(25, 25); layoutToggle:SetPoint("RIGHT", minimize, "LEFT", -5, 0)
layoutToggle:SetScript("OnEnter", function(self)
    GameTooltip:SetOwner(self, "ANCHOR_BOTTOM")
    GameTooltip:SetText(T("LAYOUT_MODE", "Расстановка плашки"), 1, 0.82, 0)
    GameTooltip:AddLine(T("LAYOUT_MODE_HINT", "Показывает и открепляет плашку боевого события."), 1, 1, 1, true)
    GameTooltip:Show()
end)
layoutToggle:SetScript("OnLeave", function() GameTooltip:Hide() end)

local pages, menuButtons, refreshers = {}, {}, {}
local selectedPage = "OVERVIEW"
local function makePage(key)
    local p = CreateFrame("Frame", nil, content); p:SetPoint("TOPLEFT", 28, -12); p:SetPoint("BOTTOMRIGHT", -28, 12); p:Hide(); pages[key] = p; return p
end

-- UIPanelScrollFrameTemplate in the 3.3.5a client assumes that every
-- ScrollFrame using it has a global name.  A few client builds still invoke
-- ScrollFrame_OnScrollRangeChanged with an unnamed temporary frame, which
-- produces "attempt to concatenate a nil value".  DamageLife uses a small
-- named wrapper instead: it keeps the Blizzard scrollbar art, but owns the
-- range/value synchronisation and never calls the fragile global handler.
local function createSafeScrollFrame(name, parent)
    local scroll = CreateFrame("ScrollFrame", name, parent)
    scroll:EnableMouseWheel(true)
    -- Do not inherit UIPanelScrollBarTemplate either: some 3.3.5a builds
    -- attach the fragile ScrollFrame_OnLoad handler to that template.
    local bar = CreateFrame("Slider", name .. "ScrollBar", scroll)
    bar:SetOrientation("VERTICAL")
    local thumb = bar:CreateTexture(nil, "ARTWORK")
    thumb:SetTexture("Interface\\Buttons\\WHITE8X8")
    thumb:SetVertexColor(1, 0.82, 0.05, 0.95)
    thumb:SetSize(10, 28)
    bar:SetThumbTexture(thumb)
    bar:SetWidth(16)
    bar:ClearAllPoints(); bar:SetPoint("TOPRIGHT", parent, "TOPRIGHT", -2, -2); bar:SetPoint("BOTTOMRIGHT", parent, "BOTTOMRIGHT", -2, 2)
    bar:SetMinMaxValues(0, 0); bar:SetValue(0)
    scroll.lsScrollBar = bar
    scroll.lsRebind = function(self)
        self:SetScript("OnScrollRangeChanged", function(frame, _, verticalRange)
            local range = math.max(0, tonumber(verticalRange) or frame:GetVerticalScrollRange() or 0)
            local value = math.min(range, tonumber(frame:GetVerticalScroll()) or 0)
            bar:SetMinMaxValues(0, range); bar:SetValue(value)
            if range > 0 then bar:Show() else bar:Hide(); frame:SetVerticalScroll(0) end
        end)
        self:SetScript("OnVerticalScroll", function(frame, offset) bar:SetValue(offset or 0) end)
        bar:SetScript("OnValueChanged", function(_, value)
            local current = self:GetVerticalScroll() or 0
            if math.abs(current - (value or 0)) > 0.01 then self:SetVerticalScroll(value or 0) end
        end)
    end
    scroll:lsRebind()
    return scroll
end
local function parseTitleColor(color)
    if type(color) == "table" then return color[1] or 1, color[2] or 0.82, color[3] or 0, color[4] or 1 end
    local hex = type(color) == "string" and color:match("^|cff([%x][%x][%x][%x][%x][%x])")
    if not hex then return 1, 0.82, 0, 1 end
    return tonumber(hex:sub(1,2), 16) / 255, tonumber(hex:sub(3,4), 16) / 255, tonumber(hex:sub(5,6), 16) / 255, 1
end
local function pageTitle(page, text, note, color)
    local titleColor = color or "|cffffd100"
    local h = page:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge"); h:SetPoint("TOP", 0, -10); h:SetText(text or "")
    h:SetTextColor(parseTitleColor(titleColor))
    local n = page:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall"); n:SetPoint("TOPLEFT", 0, -47); n:SetWidth(690); n:SetJustifyH("LEFT"); n:SetTextColor(0.88, 0.88, 0.88); n:SetText(note or "")
    page.lsTitle, page.lsNote, page.lsTitleColor = h, n, titleColor
end
local function check(parent, name, text, x, y, key, callback)
    local c = CreateFrame("CheckButton", name, parent, "InterfaceOptionsCheckButtonTemplate"); c:SetPoint("TOPLEFT", x, y); _G[name .. "Text"]:SetText(text); c.settingKey = key
    c:SetScript("OnClick", function(self) DamageLifeDB[key] = self:GetChecked() and true or false; if callback then callback(self:GetChecked()) end end); return c
end
local function slider(parent, name, label, x, y, width, low, high, step, key, divisor, callback)
    local s = CreateFrame("Slider", name, parent, "OptionsSliderTemplate"); s:SetPoint("TOPLEFT", x, y); s:SetWidth(width); s:SetMinMaxValues(low, high); s:SetValueStep(step or 1)
    _G[name .. "Low"]:SetText(low); _G[name .. "High"]:SetText(high); divisor = divisor or 1; s.lsLabel, s.lsDivisor = label, divisor
    s:SetScript("OnValueChanged", function(self, value)
        value = math.floor(value / (step or 1) + 0.5) * (step or 1); DamageLifeDB[key] = value / divisor
        _G[name .. "Text"]:SetText(self.lsLabel .. ": " .. (value / divisor)); if callback then callback(value / divisor) end
    end); return s
end
local function utf8Length(text)
    local _, count = string.gsub(text or "", "[^\128-\193]", "")
    return count
end

local function utf8Truncate(text, maximum)
    text = text or ""
    local position, count, bytes = 1, 0, #text
    while position <= bytes and count < maximum do
        local first = string.byte(text, position)
        local length = first < 128 and 1 or (first < 224 and 2 or (first < 240 and 3 or 4))
        if position + length - 1 > bytes then break end
        position, count = position + length, count + 1
    end
    return string.sub(text, 1, position - 1)
end

-- One watcher for the currently focused editor. Previously every edit box had
-- its own per-frame script, so the combined General page ran dozens of empty
-- OnUpdate callbacks while the settings window was open.
local focusedEditor
local editorFocusWatcher = CreateFrame("Frame")
local function watchFocusedEditor(self)
    if not focusedEditor or not focusedEditor:HasFocus() or not IsMouseButtonDown then self:SetScript("OnUpdate", nil); return end
    local leftDown, rightDown = IsMouseButtonDown("LeftButton"), IsMouseButtonDown("RightButton")
    local outside = (leftDown and not focusedEditor.lsLeftMouseDown) or (rightDown and not focusedEditor.lsRightMouseDown)
    focusedEditor.lsLeftMouseDown, focusedEditor.lsRightMouseDown = leftDown, rightDown
    if outside and (not MouseIsOver or not MouseIsOver(focusedEditor)) then focusedEditor:ClearFocus() end
end

local function edit(parent, x, y, width, text, onSave, options)
    options = options or {}
    local e = CreateFrame("EditBox", nil, parent); e:SetPoint("TOPLEFT", x, y); e:SetSize(width, 26); e:SetAutoFocus(false); e:SetText(text or "")
    e:SetFontObject(ChatFontNormal); e:SetTextInsets(8, 8, 0, 0)
    e:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", tile = true, tileSize = 8, edgeSize = 8, insets = { left = 2, right = 2, top = 2, bottom = 2 } })
    e:SetBackdropColor(0.015, 0.02, 0.025, 0.92); e:SetBackdropBorderColor(0.35, 0.4, 0.42, 1)
    e:SetScript("OnEditFocusGained", function(self)
        focusedEditor = self; editorFocusWatcher:SetScript("OnUpdate", watchFocusedEditor)
        self:SetBackdropBorderColor(0.2, 0.9, 0.55, 1)
        self.lsLeftMouseDown = IsMouseButtonDown and IsMouseButtonDown("LeftButton") or false
        self.lsRightMouseDown = IsMouseButtonDown and IsMouseButtonDown("RightButton") or false
    end)
    if options.maxLetters then
        local maximum = options.maxLetters
        -- SetMaxLetters alone counts bytes differently on some 3.3.5 clients,
        -- therefore the visible-symbol limit is enforced below as UTF-8 too.
        e:SetMaxLetters(maximum * 4)
        local badge = CreateFrame("Frame", nil, e)
        badge:SetHeight(17); badge:SetPoint("BOTTOMRIGHT", e, "TOPRIGHT", 0, 1)
        badge:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", tile = true, tileSize = 8, edgeSize = 7, insets = { left = 2, right = 2, top = 2, bottom = 2 } })
        badge:SetBackdropColor(0.02, 0.02, 0.02, 0.94); badge:SetBackdropBorderColor(0.6, 0.48, 0.08, 1)
        badge:SetFrameLevel(e:GetFrameLevel() + 5)
        local badgeText = badge:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        badgeText:SetPoint("CENTER", 0, 0)
        local updating = false
        local function updateLimit(self)
            if updating then return end
            local value = self:GetText() or ""
            local length = utf8Length(value)
            if length > maximum then
                updating = true
                self:SetText(utf8Truncate(value, maximum))
                self:SetCursorPosition(#self:GetText())
                updating = false
                length = maximum
                onSave(self:GetText())
            end
            local label = length >= maximum and ("ЛИМИТ: " .. maximum .. "/" .. maximum) or (length .. "/" .. maximum)
            badgeText:SetText(label)
            badge:SetWidth(math.max(48, badgeText:GetStringWidth() + 14))
            if length >= maximum then
                badgeText:SetTextColor(1, 0.25, 0.18); badge:SetBackdropBorderColor(1, 0.2, 0.12, 1); badge:Show()
            elseif self:HasFocus() then
                badgeText:SetTextColor(1, 0.82, 0.1); badge:SetBackdropBorderColor(0.6, 0.48, 0.08, 1); badge:Show()
            else badge:Hide() end
        end
        e:SetScript("OnTextChanged", updateLimit)
        e:HookScript("OnEditFocusGained", updateLimit)
        e.limitBadge, e.UpdateLimitBadge = badge, updateLimit
        updateLimit(e)
    end
    local function save(self) onSave(self:GetText()); self:ClearFocus() end
    e:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
    e:SetScript("OnEnterPressed", save); e:SetScript("OnEditFocusLost", function(self)
        if focusedEditor == self then focusedEditor = nil; editorFocusWatcher:SetScript("OnUpdate", nil) end
        self:SetBackdropBorderColor(0.35, 0.4, 0.42, 1); onSave(self:GetText())
        if self.UpdateLimitBadge then self:UpdateLimitBadge() end
    end); return e
end

-- Общие
local general = makePage("GENERAL"); pageTitle(general, "Основные параметры", "Главные параметры DamageLife, места подсчёта и быстрые действия.")
local generalEnabled = check(general, "LSGeneralEnabled", "Включить DamageLife", 6, -75, "enabled", function(enabled)
    if DamageLife.SetEnabled then DamageLife:SetEnabled(enabled) end
    if general.SetDetailsExpanded then general:SetDetailsExpanded(enabled) end
end)
local generalPreservedChildren, generalPreservedRegions = {}, {}
for _, child in ipairs({ general:GetChildren() }) do generalPreservedChildren[child] = true end
for _, region in ipairs({ general:GetRegions() }) do generalPreservedRegions[region] = true end
local generalFilterTitle = general:CreateFontString(nil, "ARTWORK", "GameFontNormal")
generalFilterTitle:SetPoint("TOPLEFT", 390, -78); generalFilterTitle:SetText("Где считать боевые события")
local generalFilterDefs = {
    { "allowWorld", "Открытый мир" },
    { "allowBattlegrounds", "Поля боя" },
    { "allowArenas", "Арены" },
    { "allowDungeons", "Подземелья" },
    { "allowRaids", "Рейды" },
}
local generalFilterChecks = {}
for i, definition in ipairs(generalFilterDefs) do
    generalFilterChecks[definition[1]] = check(general, "LSGeneralFilter" .. i, definition[2], 380, -105 - (i - 1) * 34, definition[1])
end
local low = slider(general, "LSLowHealth", "Порог начала боевого события", 20, -175, 330, 1, 30, 1, "lowPercent")
local safe = slider(general, "LSSafeHealth", "Безопасный порог", 20, -245, 330, 31, 100, 1, "safePercent")
local windowTime = slider(general, "LSRescueWindow", "Окно события, сек.", 20, -315, 330, 3, 30, 1, "rescueWindow")
local generalStats = general:CreateFontString(nil, "ARTWORK", "GameFontHighlight"); generalStats:SetPoint("TOPLEFT", 6, -365)
local test = CreateFrame("Button", nil, general, "UIPanelButtonTemplate"); test:SetSize(165, 26); test:SetPoint("TOPLEFT", 6, -405); test:SetText("Проверить анонс"); test:SetScript("OnClick", function() SlashCmdList.DAMAGELIFE("test") end)
local reset = CreateFrame("Button", nil, general, "UIPanelButtonTemplate"); reset:SetSize(175, 26); reset:SetPoint("LEFT", test, "RIGHT", 10, 0); reset:SetText("Сбросить статистику"); reset:SetScript("OnClick", function() DamageLife:ResetStats() end)
general.detailObjects = {}
for _, child in ipairs({ general:GetChildren() }) do if not generalPreservedChildren[child] then table.insert(general.detailObjects, child) end end
for _, region in ipairs({ general:GetRegions() }) do if not generalPreservedRegions[region] then table.insert(general.detailObjects, region) end end
function general:SetDetailsExpanded(expanded)
    for _, object in ipairs(self.detailObjects) do if expanded then object:Show() else object:Hide() end end
end
refreshers.GENERAL = function()
    generalEnabled:SetChecked(DamageLifeDB.enabled); low:SetValue(DamageLifeDB.lowPercent); safe:SetValue(DamageLifeDB.safePercent); windowTime:SetValue(DamageLifeDB.rescueWindow)
    for key, filterCheck in pairs(generalFilterChecks) do filterCheck:SetChecked(DamageLifeDB[key]) end
    generalStats:SetText("Всего боевых событий: " .. (DamageLifeDB.stats.totalDamageEvents or 0) .. "    Применений способностей: " .. (DamageLifeDB.stats.abilityCasts or 0) .. "    Рекорд серии: " .. (DamageLifeDB.stats.bestStreak or 0))
    general:SetDetailsExpanded(DamageLifeDB.enabled)
end

-- Единая настройка нескольких Target Window.
-- Кнопка находится внутри «Общие», а не на страницах отдельных классов.
local targetWindowsPage = makePage("TARGET_WINDOWS")
pageTitle(targetWindowsPage, "Окна целей", "Настройка количества, расположения и режима предпросмотра окон анализа целей.")
local targetWindowsEnabled = check(targetWindowsPage, "DamageLifeTargetWindowsEnabled", "Показывать окна целей", 8, -78, "targetAnalysisEnabled", function(enabled)
    if DamageLifeTargetWindowManager then
        if enabled then DamageLifeTargetWindowManager:Refresh()
        else DamageLifeTargetWindowManager:HidePreview(); DamageLifeTargetWindowManager:Refresh() end
    end
end)
local targetWindowsCount = slider(targetWindowsPage, "LSTargetWindowCount", "Количество окон целей", 20, -145, 330, 1, 5, 1, "targetWindowCount", 1, function(value)
    value = math.max(1, math.min(5, math.floor(value + 0.5)))
    DamageLifeDB.targetWindowCount = value
    if DamageLifeTargetWindowManager then DamageLifeTargetWindowManager:SetCount(value) end
end)
local targetWindowsShow = CreateFrame("Button", nil, targetWindowsPage, "UIPanelButtonTemplate")
targetWindowsShow:SetSize(155, 28); targetWindowsShow:SetPoint("TOPLEFT", 20, -215); targetWindowsShow:SetText("Показать")
targetWindowsShow:SetScript("OnClick", function(self)
    if not DamageLifeTargetWindowManager then return end
    if DamageLifeTargetWindowManager:IsPreview() then
        DamageLifeTargetWindowManager:HidePreview()
        self:SetText(T("SHOW_SHORT", "Показать"))
    else
        DamageLifeTargetWindowManager:ShowPreview()
        self:SetText(T("TARGET_WINDOWS_HIDE", "Скрыть"))
    end
end)
local targetWindowsReset = CreateFrame("Button", nil, targetWindowsPage, "UIPanelButtonTemplate")
targetWindowsReset:SetSize(190, 28); targetWindowsReset:SetPoint("LEFT", targetWindowsShow, "RIGHT", 12, 0); targetWindowsReset:SetText("Сбросить положения")
targetWindowsReset:SetScript("OnClick", function()
    if DamageLifeTargetWindowManager then DamageLifeTargetWindowManager:ResetPositions(); DamageLifeTargetWindowManager:Refresh() end
end)
local targetNotifTitle = targetWindowsPage:CreateFontString(nil, "ARTWORK", "GameFontNormal")
targetNotifTitle:SetPoint("TOPLEFT", 20, -285); targetNotifTitle:SetText("Уведомления целей")
local targetNotifChecks = {}
local targetNotifDefs = {
    { key="enabled", label="Включить уведомления" },
    { key="vulnerable", label="Цель стала уязвимой" },
    { key="lastDefense", label="Последняя защита закончилась" },
    { key="defenseRegained", label="Цель снова получила защиту" },
    { key="execute", label="EXECUTE WINDOW" },
    { key="priority", label="Цель стала приоритетной / SWITCH" },
    { key="lowHP", label="Низкий HP" },
    { key="chat", label="Дублировать уведомления в чат" },
}
for i, def in ipairs(targetNotifDefs) do
    local col = (i-1) % 2; local row = math.floor((i-1)/2)
    local cb = check(targetWindowsPage, "LSTargetNotif"..i, def.label, 20 + col*285, -315 - row*32, "targetNotifications."..def.key)
    cb:SetScript("OnClick", function(self)
        DamageLifeDB.targetNotifications = DamageLifeDB.targetNotifications or {}
        DamageLifeDB.targetNotifications[def.key] = self:GetChecked() and true or false
    end)
    targetNotifChecks[def.key] = cb
end
local targetNotifExecute = slider(targetWindowsPage, "LSTargetExecutePct", "Порог EXECUTE, % HP", 20, -410, 250, 5, 50, 5, "targetExecutePercent", 1, function(value)
    DamageLifeDB.targetNotifications = DamageLifeDB.targetNotifications or {}
    DamageLifeDB.targetNotifications.executePercent = value
end)
local targetWindowsHint = targetWindowsPage:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
targetWindowsHint:SetPoint("TOPLEFT", 20, -475); targetWindowsHint:SetWidth(620); targetWindowsHint:SetJustifyH("LEFT")
targetWindowsHint:SetText("Нажмите «Показать», чтобы открыть режим размещения. Окна можно перемещать мышью. Изменение количества 1–5 во время предпросмотра сразу добавляет или убирает окна.")
refreshers.TARGET_WINDOWS = function()
    targetWindowsEnabled:SetChecked(DamageLifeDB.targetAnalysisEnabled ~= false)
    targetWindowsCount:SetValue(DamageLifeDB.targetWindowCount or 1)
    targetWindowsShow:SetText(DamageLifeTargetWindowManager and DamageLifeTargetWindowManager:IsPreview() and "Скрыть" or T("SHOW_SHORT", "Показать"))
end

-- Боевые категории
local eventsPage = makePage("EVENTS"); pageTitle(eventsPage, "Боевые события", "Четыре типа ключевых DPS-событий используют единый шаблон уведомлений и отдельное визуальное оформление.")
local eventsHint = eventsPage:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
eventsHint:SetPoint("TOPLEFT", 8, -78); eventsHint:SetWidth(660); eventsHint:SetJustifyH("LEFT")
eventsHint:SetText("Отключённая категория не создаёт собственных уведомлений, но обычный учёт урона и статистика продолжают работать.")
local eventCategoryDefs = {
    { key = "critical", label = "Критический удар", color = {1, 0.12, 0.08}, note = "Критические попадания и критический DPS-событийный акцент." },
    { key = "burst", label = "Бурст", color = {1, 0.48, 0.08}, note = "Мощные усиления и способности для резкого давления." },
    { key = "execute", label = "Добивание", color = {1, 0.78, 0.08}, note = "Способности и события, предназначенные для завершения цели." },
    { key = "control", label = "Контроль", color = {0.35, 0.65, 1}, note = "Контролирующие способности, которые создают окно для давления." },
}
local eventCategoryChecks, eventCategoryNotes = {}, {}
for index, definition in ipairs(eventCategoryDefs) do
    local y = -122 - (index - 1) * 78
    eventCategoryChecks[definition.key] = check(eventsPage, "LSEventCategory" .. index, definition.label, 20, y, "combatCategories." .. definition.key)
    -- The generic check helper writes flat keys, so replace its click handler with nested SavedVariables.
    eventCategoryChecks[definition.key]:SetScript("OnClick", function(self)
        DamageLifeDB.combatCategories = DamageLifeDB.combatCategories or {}
        DamageLifeDB.combatCategories[definition.key] = self:GetChecked() and true or false
    end)
    local text = _G[eventCategoryChecks[definition.key]:GetName() .. "Text"]
    if text then text:SetTextColor(definition.color[1], definition.color[2], definition.color[3]) end
    eventCategoryNotes[definition.key] = eventsPage:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
    eventCategoryNotes[definition.key]:SetPoint("TOPLEFT", 48, y - 30); eventCategoryNotes[definition.key]:SetWidth(600); eventCategoryNotes[definition.key]:SetText(definition.note)
end
local eventsStats = eventsPage:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
eventsStats:SetPoint("TOPLEFT", 20, -450); eventsStats:SetWidth(620); eventsStats:SetJustifyH("LEFT")
local eventsReset = CreateFrame("Button", nil, eventsPage, "UIPanelButtonTemplate")
eventsReset:SetSize(190, 27); eventsReset:SetPoint("TOPLEFT", 20, -525); eventsReset:SetText("Сбросить статистику")
eventsReset:SetScript("OnClick", function() if DamageLife and DamageLife.ResetStats then DamageLife:ResetStats() end end)
refreshers.EVENTS = function()
    DamageLifeDB.combatCategories = DamageLifeDB.combatCategories or { critical = true, burst = true, execute = true, control = true }
    for key, control in pairs(eventCategoryChecks) do control:SetChecked(DamageLifeDB.combatCategories[key] ~= false) end
    local c = DamageLifeDB.stats and DamageLifeDB.stats.categoryEvents or {}
    eventsStats:SetText("Критические: " .. (c.CRITICAL or 0) .. "    Бурст: " .. (c.BURST or 0) .. "\nДобивания: " .. (c.EXECUTE or 0) .. "    Контроль: " .. (c.CONTROL or 0))
end

-- Серии
local series = makePage("SERIES"); pageTitle(series, "Серии", "Время серии и названия пятнадцати ступеней.")
local streakWindow = slider(series, "LSStreakWindow", "Время серии, сек.", 20, -90, 280, 5, 60, 1, "streakWindow")
local streakResetInfo = series:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
streakResetInfo:SetPoint("TOPLEFT", 335, -76); streakResetInfo:SetWidth(300); streakResetInfo:SetJustifyH("LEFT")
streakResetInfo:SetText("Серия автоматически сбрасывается после смерти и выхода из боя или поля боя.")
local streakEdits = {}
for i = 1, 15 do
    local col, row = (i - 1) % 2, math.floor((i - 1) / 2)
    local label = series:CreateFontString(nil, "ARTWORK", "GameFontNormalSmall"); label:SetPoint("TOPLEFT", 8 + col * 295, -155 - row * 43); label:SetText(i .. ".")
    local index = i; streakEdits[i] = edit(series, 32 + col * 295, -145 - row * 43, 245, "", function(value) DamageLifeDB.streakNames[index] = value end)
end
refreshers.SERIES = function() streakWindow:SetValue(DamageLifeDB.streakWindow); for i, e in ipairs(streakEdits) do if not e:HasFocus() then e:SetText(DamageLifeDB.streakNames[i] or "") end end end

-- Анонсы и редактор эмоций
local announce = makePage("ANNOUNCE"); pageTitle(announce, "Анонсы и эмоции", "Используйте {target} как имя цели. Галочка слева включает фразу, кнопка справа показывает пример.")
local emoteOn = check(announce, "LSEmoteOn", "Отправлять эмоции", 6, -72, "emoteEnabled")
local groupOnly = check(announce, "LSGroupOnly", "Эмоции только в группе, рейде, БГ или арене", 230, -72, "groupEmotesOnly")
local emoteCd = slider(announce, "LSEmoteCD", "Задержка эмоций", 20, -135, 250, 0, 30, 1, "emoteCooldown")
local targetCd = slider(announce, "LSTargetCD", "Повтор одной цели", 330, -135, 250, 0, 60, 1, "targetCooldown")
local phraseChecks, phraseEdits, phrasePreviews = {}, {}, {}
for i = 1, 8 do
    local index = i; phraseChecks[i] = check(announce, "LSPhraseCheck" .. i, "", 6, -190 - (i - 1) * 39, "phraseEnabled")
    phraseChecks[i]:SetScript("OnClick", function(self) DamageLifeDB.phraseEnabled[index] = self:GetChecked() and true or false end)
    phraseEdits[i] = edit(announce, 40, -181 - (i - 1) * 39, 470, "", function(value) DamageLifeDB.phrases[index] = value end, { maxLetters = 100 })
    local preview = CreateFrame("Button", nil, announce, "UIPanelButtonTemplate"); preview:SetSize(72, 22); preview:SetPoint("TOPLEFT", 520, -181 - (i - 1) * 39); preview:SetText("Пример"); preview:SetScript("OnClick", function() DamageLife:PreviewPhrase(index) end)
    phrasePreviews[i] = preview
end
refreshers.ANNOUNCE = function()
    emoteOn:SetChecked(DamageLifeDB.emoteEnabled); groupOnly:SetChecked(DamageLifeDB.groupEmotesOnly); emoteCd:SetValue(DamageLifeDB.emoteCooldown); targetCd:SetValue(DamageLifeDB.targetCooldown)
    for i = 1, 8 do phraseChecks[i]:SetChecked(DamageLifeDB.phraseEnabled[i]); if not phraseEdits[i]:HasFocus() then phraseEdits[i]:SetText(DamageLifeDB.phrases[i] or "") end end
end

-- Экран
local display = makePage("DISPLAY"); pageTitle(display, "Боевые события", "Плашку боевого события можно показывать, перемещать и масштабировать.")
local screenOn = check(display, "LSScreenOn", "Экранное уведомление", 6, -75, "screenEnabled")
local localChat = check(display, "LSLocalChat", "Локальная запись в чат", 6, -108, "localChatEnabled")
local widgetLock = CreateFrame("Button", nil, display, "UIPanelButtonTemplate")
widgetLock:SetSize(135, 27); widgetLock:SetPoint("TOPLEFT", 445, -75)
widgetLock:SetScript("OnClick", function(self)
    DamageLife:SetWidgetLocked(not DamageLifeDB.widgetLocked)
    self:SetText(DamageLifeDB.widgetLocked and T("UNLOCK_SHORT", "Открепить") or T("LOCK_SHORT", "Закрепить"))
    if syncLayoutToggle then syncLayoutToggle() end
end)
local scale
local resetPosition = CreateFrame("Button", nil, display, "UIPanelButtonTemplate")
resetPosition:SetSize(280, 27); resetPosition:SetPoint("TOPLEFT", 300, -110); resetPosition:SetText("Сбросить положение")
resetPosition:SetScript("OnClick", function()
    DamageLife:ResetWidgetPosition()
    if scale then scale:SetValue(60) end
end)
local moveHint = display:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
moveHint:SetPoint("TOPLEFT", 300, -145); moveHint:SetWidth(280); moveHint:SetJustifyH("LEFT")
moveHint:SetText("Открепите плашку, перетащите её мышью и закрепите в новом месте.")
scale = slider(display, "LSWidgetScale", "Масштаб", 20, -240, 280, 50, 150, 5, "widgetScale", 100, function() DamageLife:RefreshWidget() end)
local previewWidget = CreateFrame("Button", nil, display, "UIPanelButtonTemplate"); previewWidget:SetSize(135, 27); previewWidget:SetPoint("TOPLEFT", 300, -75); previewWidget:SetText("Показать"); previewWidget:SetScript("OnClick", function() SlashCmdList.DAMAGELIFE("test") end)

refreshers.DISPLAY = function()
    screenOn:SetChecked(DamageLifeDB.screenEnabled); localChat:SetChecked(DamageLifeDB.localChatEnabled)
    widgetLock:SetText(DamageLifeDB.widgetLocked and T("UNLOCK_SHORT", "Открепить") or T("LOCK_SHORT", "Закрепить"))
    scale:SetValue(DamageLifeDB.widgetScale * 100)
end

-- Озвучка важных способностей и боевых событий.
local voicePage = makePage("VOICE")
pageTitle(voicePage, "Озвучка способностей", "Отдельные голосовые уведомления для боевых событий и важных боевых действий.")
local voiceRows = {
    { key = "voiceRescueEnabled", name = "LSVoiceRescue", label = "Критический удар", sound = "RESCUE", note = "Проигрывается как голосовое уведомление боевого события." },
    { key = "voiceHymnOfHopeEnabled", name = "LSVoiceHymnOfHope", label = "Бурст", sound = "PRIEST_HOPE", note = "Голосовое уведомление для мощного боевого события." },
    { key = "voiceDivineHymnEnabled", name = "LSVoiceDivineHymn", label = "Добивание", sound = "PRIEST_DIVINE", note = "Голосовое уведомление для завершающего удара." },
    { key = "voiceAllyDeathEnabled", name = "LSVoiceAllyDeath", label = "Контроль", sound = "ALLY_DIED", note = "Голосовое уведомление для контрольного эффекта." },
}
for index, row in ipairs(voiceRows) do
    local y = -92 - (index - 1) * 92
    row.check = check(voicePage, row.name, row.label, 20, y, row.key)
    row.noteText = voicePage:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
    row.noteText:SetPoint("TOPLEFT", 48, y - 30); row.noteText:SetWidth(440); row.noteText:SetJustifyH("LEFT"); row.noteText:SetText(row.note)
    row.preview = CreateFrame("Button", nil, voicePage, "UIPanelButtonTemplate")
    row.preview:SetSize(120, 26); row.preview:SetPoint("TOPRIGHT", -40, y + 5); row.preview:SetText("Прослушать")
    local soundKey = row.sound
    row.preview:SetScript("OnClick", function() if DamageLife and DamageLife.PreviewVoice then DamageLife:PreviewVoice(soundKey) end end)
end
refreshers.VOICE = function()
    for _, row in ipairs(voiceRows) do row.check:SetChecked(DamageLifeDB[row.key] ~= false) end
end

syncLayoutToggle = function()
    layoutToggle:SetChecked(not DamageLifeDB.widgetLocked)
end
layoutToggle:SetScript("OnClick", function(self)
    local unlocked = self:GetChecked() and true or false
    DamageLife:SetWidgetLocked(not unlocked)
    refreshers.DISPLAY()
    syncLayoutToggle()
end)

function DamageLifeSettings_RefreshStats()
    if not DamageLifeDB or not DamageLifeDB.stats then return end
    generalStats:SetText("Всего боевых событий: " .. (DamageLifeDB.stats.totalDamageEvents or 0) .. "    Применений способностей: " .. (DamageLifeDB.stats.abilityCasts or 0) .. "    Рекорд серии: " .. (DamageLifeDB.stats.bestStreak or 0))
end

-- О проекте
local about = makePage("ABOUT"); pageTitle(about, "О проекте", "Информация о DamageLife, его идее и разработке.")
local aboutText = about:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
aboutText:SetPoint("TOPLEFT", 8, -78); aboutText:SetWidth(570); aboutText:SetJustifyH("LEFT"); aboutText:SetJustifyV("TOP")
aboutText:SetText("")
refreshers.ABOUT = function()
    local version = DamageLife_GetCurrentVersion()
    local aboutFallback = "|cfffff2b2DamageLife|r — аддон для дамагеров, который анализирует боевые ситуации, помогает оценивать личный вклад в урон, добивание, бурст и контроль и превращает ключевые боевые моменты в понятные анонсы.\n\n" ..
        "|cffffcc00Автор идеи и разработка|r\nVegasy\n\n" ..
        "|cffffcc00Тестировщики Аддона|r\n|cffffffffPandora|r\n\n" ..
        "|cffffcc00Дата начала разработки|r\n5 августа 2026 года\n\n" ..
        "|cffffcc00Текущая версия|r\n" .. version .. "\n\n" ..
        "Проект развивается через реальные боевые проверки. Главная цель — честно определять ключевые боевые моменты: бурст, добивание, контроль и давление на цель.\n\n" ..
        "|cffaaaaaaКоманда /dl открывает настройки аддона.|r"
    aboutText:SetText(string.format(T("ABOUT_BODY", aboutFallback), version))
end

-- Классовые страницы
-- Заголовки классов используют SetTextColor, а не цветовые escape-коды в тексте.
-- Это предотвращает отображение |cff... как обычного текста на старых клиентах 3.3.5a.
local compactClassInfo = {
    WARRIOR = { "Воин", {0.78, 0.61, 0.43}, "warriorDpsEnabled" },
    PALADIN = { "Паладин", {0.96, 0.55, 0.73}, "paladinDpsEnabled" },
    HUNTER = { "Охотник", {0.67, 0.83, 0.45}, "hunterDpsEnabled" },
    ROGUE = { "Разбойник", {1.00, 0.96, 0.41}, "rogueDpsEnabled" },
    PRIEST = { "Жрец", {1.00, 1.00, 1.00}, "priestDpsEnabled" },
    SHAMAN = { "Шаман", {0.00, 0.44, 0.87}, "shamanDpsEnabled" },
    MAGE = { "Маг", {0.41, 0.80, 0.94}, "mageDpsEnabled" },
    WARLOCK = { "Чернокнижник", {0.58, 0.51, 0.79}, "warlockDpsEnabled" },
    DRUID = { "Друид", {1.00, 0.49, 0.06}, "druidDpsEnabled" },
    DEATHKNIGHT = { "Рыцарь смерти", {0.77, 0.12, 0.23}, "deathKnightDpsEnabled" },
}
local compactMasterLabels = {
    WARRIOR = "Включить отслеживание способностей воина",
    PALADIN = "Включить отслеживание способностей паладина",
    HUNTER = "Включить отслеживание способностей охотника",
    ROGUE = "Включить отслеживание способностей разбойника",
    PRIEST = "Включить отслеживание способностей жреца",
    SHAMAN = "Включить отслеживание способностей шамана",
    MAGE = "Включить отслеживание способностей мага",
    WARLOCK = "Включить отслеживание способностей чернокнижника",
    DRUID = "Включить отслеживание способностей друида",
    DEATHKNIGHT = "Включить отслеживание способностей рыцаря смерти",
}
local compactAbilityLabels = {}

-- На интерфейсном этапе CombatEngine не меняется. Этот отдельный реестр
-- даёт странице «Классы» полноценное DPS-содержимое, сохраняя архитектуру
-- исходной страницы Lifesaver (сохраняем архитектуру, но не семантику). Боевые обработчики подключим только после
-- успешного теста интерфейса.
local dpsPhrases = {
    "Атакую {target} с помощью {spell}!",
    "Начинаю бурст по {target}: {spell}!",
    "Использую {spell} против {target}!",
    "Усиливаю давление на {target}: {spell}!",
    "Давлю на {target}: {spell}!",
    "Добиваю {target} с помощью {spell}!",
}
local function dpsAbility(key, class, label, spellId, icon, spellIds)
    return {
        key = key, class = class, label = label,
        setting = "dps_" .. string.lower(key) .. "_enabled",
        spellId = spellId, spellIds = spellIds or { spellId }, icon = icon,
        defaults = dpsPhrases, groupWide = false,
    }
end

-- Полный PvP/DPS-реестр WotLK 3.3.5: основные удары, DoT/AoE, burst,
-- interrupts, контроль и важные offensive cooldowns. Ранги одной способности
-- объединяются через spellIds и не создают дубликаты в интерфейсе.
DamageLifeClassAbilityDefinitions = {
    -- WARRIOR
    dpsAbility("WARRIOR_MORTAL_STRIKE", "WARRIOR", "Смертельный удар", 47486, "Interface\\Icons\\Ability_Warrior_MortalStrike"),
    dpsAbility("WARRIOR_BLADESTORM", "WARRIOR", "Вихрь клинков", 46924, "Interface\\Icons\\Ability_Warrior_Bladestorm"),
    dpsAbility("WARRIOR_EXECUTE", "WARRIOR", "Казнь", 47471, "Interface\\Icons\\INV_Sword_48"),
    dpsAbility("WARRIOR_RECKLESSNESS", "WARRIOR", "Безрассудство", 1719, "Interface\\Icons\\Spell_Shadow_UnholyFrenzy"),
    dpsAbility("WARRIOR_OVERPOWER", "WARRIOR", "Сокрушительный удар", 7384, "Interface\\Icons\\Ability_Melee_PunishingBlow"),
    dpsAbility("WARRIOR_HEROIC_STRIKE", "WARRIOR", "Удар героя", 47450, "Interface\\Icons\\Ability_Rogue_SinisterCalling"),
    dpsAbility("WARRIOR_WHIRLWIND", "WARRIOR", "Вихрь", 1680, "Interface\\Icons\\Ability_Warrior_Whirlwind"),
    dpsAbility("WARRIOR_HAMSTRING", "WARRIOR", "Подрезать сухожилия", 47465, "Interface\\Icons\\Ability_ShockWave"),
    dpsAbility("WARRIOR_CHARGE", "WARRIOR", "Рывок", 11578, "Interface\\Icons\\Ability_Warrior_Charge"),
    dpsAbility("WARRIOR_INTERCEPT", "WARRIOR", "Перехват", 20252, "Interface\\Icons\\Ability_Rogue_Sprint"),
    dpsAbility("WARRIOR_PUMMEL", "WARRIOR", "Затереть", 6552, "Interface\\Icons\\INV_Gauntlets_04"),
    dpsAbility("WARRIOR_SHOCKWAVE", "WARRIOR", "Ударная волна", 46968, "Interface\\Icons\\Ability_Warrior_Shockwave"),
    dpsAbility("WARRIOR_CONCUSSION_BLOW", "WARRIOR", "Оглушающий удар", 12809, "Interface\\Icons\\Ability_ThunderClap"),
    dpsAbility("WARRIOR_SPELL_REFLECTION", "WARRIOR", "Отражение заклинания", 23920, "Interface\\Icons\\Ability_Warrior_ShieldReflection"),

    -- PALADIN
    dpsAbility("PALADIN_DIVINE_STORM", "PALADIN", "Божественная буря", 53385, "Interface\\Icons\\Ability_Paladin_DivineStorm"),
    dpsAbility("PALADIN_CRUSADER_STRIKE", "PALADIN", "Удар воина Света", 35395, "Interface\\Icons\\Spell_Holy_CrusaderStrike"),
    dpsAbility("PALADIN_HAMMER_WRATH", "PALADIN", "Молот гнева", 48806, "Interface\\Icons\\Ability_Paladin_HammerOfWrath"),
    dpsAbility("PALADIN_AVENGING_WRATH", "PALADIN", "Гнев карателя", 31884, "Interface\\Icons\\Spell_Holy_AvengineWrath"),
    dpsAbility("PALADIN_JUDGEMENT", "PALADIN", "Правосудие", 20271, "Interface\\Icons\\Spell_Holy_RighteousFury"),
    dpsAbility("PALADIN_CONSECRATION", "PALADIN", "Освящение", 48819, "Interface\\Icons\\Spell_Holy_Consecration"),
    dpsAbility("PALADIN_EXORCISM", "PALADIN", "Экзорцизм", 48801, "Interface\\Icons\\Spell_Holy_Exorcism"),
    dpsAbility("PALADIN_HAMMER_JUSTICE", "PALADIN", "Молот правосудия", 10308, "Interface\\Icons\\Spell_Holy_SealOfMight"),
    dpsAbility("PALADIN_REPENTANCE", "PALADIN", "Покаяние", 20066, "Interface\\Icons\\Spell_Holy_PrimordialSiphon"),
    dpsAbility("PALADIN_DIVINE_SACRIFICE", "PALADIN", "Божественная жертва", 64205, "Interface\\Icons\\Spell_Holy_DivineSacrifice"),
    dpsAbility("PALADIN_HAND_FREEDOM", "PALADIN", "Длань свободы", 1044, "Interface\\Icons\\Spell_Holy_SealOfValor"),
    dpsAbility("PALADIN_SEAL_COMMAND", "PALADIN", "Печать повиновения", 20375, "Interface\\Icons\\Ability_Paladin_SealOfCommand"),

    -- HUNTER
    dpsAbility("HUNTER_CHIMERA_SHOT", "HUNTER", "Укус химеры", 53209, "Interface\\Icons\\Ability_Hunter_ChimeraShot2"),
    dpsAbility("HUNTER_AIMED_SHOT", "HUNTER", "Прицельный выстрел", 49050, "Interface\\Icons\\INV_Spear_07"),
    dpsAbility("HUNTER_KILL_SHOT", "HUNTER", "Убийственный выстрел", 61006, "Interface\\Icons\\Ability_Hunter_KillShot"),
    dpsAbility("HUNTER_RAPID_FIRE", "HUNTER", "Быстрая стрельба", 3045, "Interface\\Icons\\Ability_Hunter_RapidKilling"),
    dpsAbility("HUNTER_STEADY_SHOT", "HUNTER", "Верный выстрел", 49052, "Interface\\Icons\\Ability_Hunter_SteadyShot"),
    dpsAbility("HUNTER_ARCANE_SHOT", "HUNTER", "Чародейский выстрел", 49045, "Interface\\Icons\\Ability_Hunter_ArcaneShot"),
    dpsAbility("HUNTER_SERPENT_STING", "HUNTER", "Укус змеи", 49001, "Interface\\Icons\\Ability_Hunter_CobraShot"),
    dpsAbility("HUNTER_EXPLOSIVE_SHOT", "HUNTER", "Разрывной выстрел", 60053, "Interface\\Icons\\Ability_Hunter_ExplosiveShot"),
    dpsAbility("HUNTER_SILENCING_SHOT", "HUNTER", "Глушащий выстрел", 34490, "Interface\\Icons\\Ability_Hunter_SilencingShot"),
    dpsAbility("HUNTER_WING_CLIP", "HUNTER", "Подрезать крылья", 49056, "Interface\\Icons\\Ability_Rogue_FanofKnives"),
    dpsAbility("HUNTER_FREEZING_TRAP", "HUNTER", "Замораживающая ловушка", 14311, "Interface\\Icons\\Spell_Frost_FreezingBreath"),
    dpsAbility("HUNTER_BESTIAL_WRATH", "HUNTER", "Звериный гнев", 19574, "Interface\\Icons\\Ability_Druid_Enrage"),
    dpsAbility("HUNTER_DISENGAGE", "HUNTER", "Отрыв", 781, "Interface\\Icons\\Ability_Rogue_Feint"),

    -- ROGUE
    dpsAbility("ROGUE_EVISCERATE", "ROGUE", "Потрошение", 48668, "Interface\\Icons\\Ability_Rogue_Eviscerate"),
    dpsAbility("ROGUE_KILLING_SPREE", "ROGUE", "Кровавая бойня", 51690, "Interface\\Icons\\Ability_Rogue_KillingSpree"),
    dpsAbility("ROGUE_SHADOW_DANCE", "ROGUE", "Танец теней", 51713, "Interface\\Icons\\Ability_Rogue_ShadowDance"),
    dpsAbility("ROGUE_ADRENALINE_RUSH", "ROGUE", "Выброс адреналина", 13750, "Interface\\Icons\\Spell_Shadow_ShadowandFlame"),
    dpsAbility("ROGUE_MUTILATE", "ROGUE", "Расправа", 48666, "Interface\\Icons\\Ability_Rogue_Mutilate"),
    dpsAbility("ROGUE_SINISTER_STRIKE", "ROGUE", "Коварный удар", 48638, "Interface\\Icons\\Spell_Shadow_RitualOfSacrifice"),
    dpsAbility("ROGUE_HAMMER_SHIV", "ROGUE", "Шив", 5938, "Interface\\Icons\\INV_ThrowingKnife_04"),
    dpsAbility("ROGUE_KICK", "ROGUE", "Пинок", 1766, "Interface\\Icons\\Ability_Kick"),
    dpsAbility("ROGUE_KIDNEY_SHOT", "ROGUE", "Парализующий удар", 408, "Interface\\Icons\\Ability_Rogue_KidneyShot"),
    dpsAbility("ROGUE_GOUGE", "ROGUE", "Ошеломление", 1776, "Interface\\Icons\\Ability_Gouge"),
    dpsAbility("ROGUE_CHEAP_SHOT", "ROGUE", "Подлый трюк", 1833, "Interface\\Icons\\Ability_Rogue_Ambush"),
    dpsAbility("ROGUE_BLIND", "ROGUE", "Ослепление", 2094, "Interface\\Icons\\Spell_Shadow_MindSteal"),
    dpsAbility("ROGUE_VANISH", "ROGUE", "Исчезновение", 26889, "Interface\\Icons\\Ability_Vanish"),

    -- PRIEST SHADOW
    dpsAbility("PRIEST_MIND_BLAST", "PRIEST", "Взрыв разума", 48127, "Interface\\Icons\\Spell_Shadow_UnholyFrenzy"),
    dpsAbility("PRIEST_SHADOW_WORD_DEATH", "PRIEST", "Слово Тьмы: Смерть", 48158, "Interface\\Icons\\Spell_Shadow_DemonicFortitude"),
    dpsAbility("PRIEST_VAMPIRIC_TOUCH", "PRIEST", "Слово Тьмы: Боль", 48125, "Interface\\Icons\\Spell_Shadow_VampiricTouch"),
    dpsAbility("PRIEST_MIND_FLAY", "PRIEST", "Пытка разума", 48156, "Interface\\Icons\\Spell_Shadow_MindFlay"),
    dpsAbility("PRIEST_DEVOURING_PLAGUE", "PRIEST", "Всепожирающая чума", 48300, "Interface\\Icons\\Spell_Shadow_DevouringPlague"),
    dpsAbility("PRIEST_HOLY_FIRE", "PRIEST", "Священный огонь", 48135, "Interface\\Icons\\Spell_Holy_SearingLight"),
    dpsAbility("PRIEST_SILENCE", "PRIEST", "Безмолвие", 15487, "Interface\\Icons\\Spell_Shadow_ImpPhaseShift"),
    dpsAbility("PRIEST_PSYCHIC_SCREAM", "PRIEST", "Психический крик", 10894, "Interface\\Icons\\Spell_Shadow_PsychicScream"),
    dpsAbility("PRIEST_DISPERSION", "PRIEST", "Исчезновение", 47585, "Interface\\Icons\\Spell_Shadow_Dispersion"),

    -- SHAMAN
    dpsAbility("SHAMAN_LAVA_BURST", "SHAMAN", "Выброс лавы", 60043, "Interface\\Icons\\Spell_Shaman_LavaBurst"),
    dpsAbility("SHAMAN_STORMSTRIKE", "SHAMAN", "Удар бури", 17364, "Interface\\Icons\\Ability_Shaman_Stormstrike"),
    dpsAbility("SHAMAN_EARTH_SHOCK", "SHAMAN", "Земной шок", 49231, "Interface\\Icons\\Spell_Nature_EarthShock"),
    dpsAbility("SHAMAN_BLOODLUST", "SHAMAN", "Жажда крови", 2825, "Interface\\Icons\\Spell_Nature_BloodLust"),
    dpsAbility("SHAMAN_FLAME_SHOCK", "SHAMAN", "Огненный шок", 49233, "Interface\\Icons\\Spell_Fire_FlameShock"),
    dpsAbility("SHAMAN_FROST_SHOCK", "SHAMAN", "Ледяной шок", 49236, "Interface\\Icons\\Spell_Frost_FrostShock"),
    dpsAbility("SHAMAN_CHAIN_LIGHTNING", "SHAMAN", "Цепная молния", 49271, "Interface\\Icons\\Spell_Nature_ChainLightning"),
    dpsAbility("SHAMAN_LIGHTNING_BOLT", "SHAMAN", "Молния", 49238, "Interface\\Icons\\Spell_Nature_Lightning"),
    dpsAbility("SHAMAN_WINDFURY", "SHAMAN", "Неистовство ветра", 58804, "Interface\\Icons\\Spell_Nature_Cyclone"),
    dpsAbility("SHAMAN_WIND_SHEAR", "SHAMAN", "Пронизывающий ветер", 57994, "Interface\\Icons\\Ability_Shaman_WindShear"),
    dpsAbility("SHAMAN_HEX", "SHAMAN", "Сглаз", 51514, "Interface\\Icons\\Spell_Shaman_Hex"),
    dpsAbility("SHAMAN_EARTHBIND", "SHAMAN", "Тотем оков земли", 2484, "Interface\\Icons\\Spell_Nature_NatureGrasp"),
    dpsAbility("SHAMAN_PURGE", "SHAMAN", "Развеивание", 8012, "Interface\\Icons\\Spell_Nature_Purge"),

    -- MAGE
    dpsAbility("MAGE_FROSTBOLT", "MAGE", "Стрела ледяного огня", 47610, "Interface\\Icons\\Spell_Frost_Frostbolt02"),
    dpsAbility("MAGE_ARCANE_BLAST", "MAGE", "Чародейская вспышка", 42897, "Interface\\Icons\\Spell_Arcane_Blast"),
    dpsAbility("MAGE_DEEP_FREEZE", "MAGE", "Глубокая заморозка", 44572, "Interface\\Icons\\Ability_Mage_DeepFreeze"),
    dpsAbility("MAGE_ICY_VEINS", "MAGE", "Ледяные жилы", 12472, "Interface\\Icons\\Spell_Frost_IceLance"),
    dpsAbility("MAGE_FIREBALL", "MAGE", "Огненный шар", 42833, "Interface\\Icons\\Spell_Fire_FlameBolt"),
    dpsAbility("MAGE_ICE_LANCE", "MAGE", "Ледяное копье", 42914, "Interface\\Icons\\Spell_Frost_IceLance"),
    dpsAbility("MAGE_FIRE_BLAST", "MAGE", "Огненная вспышка", 42873, "Interface\\Icons\\Spell_Fire_FireBlast"),
    dpsAbility("MAGE_PYROBLAST", "MAGE", "Огненная глыба", 42891, "Interface\\Icons\\Spell_Fire_Fireball02"),
    dpsAbility("MAGE_LIVING_BOMB", "MAGE", "Живая бомба", 55360, "Interface\\Icons\\Ability_Mage_LivingBomb"),
    dpsAbility("MAGE_COUNTERSPELL", "MAGE", "Антимагия", 2139, "Interface\\Icons\\Spell_Frost_IceShock"),
    dpsAbility("MAGE_FROST_NOVA", "MAGE", "Кольцо льда", 42917, "Interface\\Icons\\Spell_Frost_FrostNova"),
    dpsAbility("MAGE_POLYMORPH", "MAGE", "Превращение", 12826, "Interface\\Icons\\Spell_Nature_Polymorph"),
    dpsAbility("MAGE_BLINK", "MAGE", "Скачок", 1953, "Interface\\Icons\\Spell_Arcane_Blink"),

    -- WARLOCK
    dpsAbility("WARLOCK_CHAOS_BOLT", "WARLOCK", "Хаос", 47847, "Interface\\Icons\\Spell_Shadow_ChaosBolt"),
    dpsAbility("WARLOCK_CONFLAGRATE", "WARLOCK", "Поджигание", 47843, "Interface\\Icons\\Spell_Shadow_ShadowandFlame"),
    dpsAbility("WARLOCK_SHADOW_BOLT", "WARLOCK", "Стрела Тьмы", 47809, "Interface\\Icons\\Spell_Shadow_ShadowBolt"),
    dpsAbility("WARLOCK_DEATH_COIL", "WARLOCK", "Лик смерти", 47860, "Interface\\Icons\\Spell_Shadow_DeathCoil"),
    dpsAbility("WARLOCK_CORRUPTION", "WARLOCK", "Порча", 47813, "Interface\\Icons\\Spell_Shadow_AbominationExplosion"),
    dpsAbility("WARLOCK_IMMOLATE", "WARLOCK", "Жертвенный огонь", 47811, "Interface\\Icons\\Spell_Fire_Immolation"),
    dpsAbility("WARLOCK_INCINERATE", "WARLOCK", "Испепеление", 47838, "Interface\\Icons\\Spell_Fire_Incinerate"),
    dpsAbility("WARLOCK_HAUNT", "WARLOCK", "Преследование", 59164, "Interface\\Icons\\Spell_Shadow_DeathCoil"),
    dpsAbility("WARLOCK_FEAR", "WARLOCK", "Страх", 6215, "Interface\\Icons\\Spell_Shadow_Possession"),
    dpsAbility("WARLOCK_SHADOWFLAME", "WARLOCK", "Пламя Тьмы", 47897, "Interface\\Icons\\Spell_Shadow_Shadowflame"),
    dpsAbility("WARLOCK_SOUL_FIRE", "WARLOCK", "Ожог души", 47825, "Interface\\Icons\\Spell_Fire_SoulFire"),

    -- DRUID
    dpsAbility("DRUID_STARFALL", "DRUID", "Звездопад", 48469, "Interface\\Icons\\Spell_Arcane_StarFire"),
    dpsAbility("DRUID_WRATH", "DRUID", "Гнев", 48461, "Interface\\Icons\\Spell_Nature_StarFall"),
    dpsAbility("DRUID_FERAL_CHARGE", "DRUID", "Агрессивный рывок", 49377, "Interface\\Icons\\Ability_Druid_FeralCharge"),
    dpsAbility("DRUID_BERSERK", "DRUID", "Берсерк", 50334, "Interface\\Icons\\Ability_Druid_Berserk"),
    dpsAbility("DRUID_MOONFIRE", "DRUID", "Лунный огонь", 48463, "Interface\\Icons\\Spell_Nature_StarFall"),
    dpsAbility("DRUID_STARFIRE", "DRUID", "Звездный огонь", 48465, "Interface\\Icons\\Spell_Arcane_StarFire"),
    dpsAbility("DRUID_INSECT_SWARM", "DRUID", "Рой насекомых", 48468, "Interface\\Icons\\Spell_Nature_InsectSwarm"),
    dpsAbility("DRUID_FERAL_RIP", "DRUID", "Разорвать", 49800, "Interface\\Icons\\Ability_Druid_Rip"),
    dpsAbility("DRUID_MAIM", "DRUID", "Калечащая атака", 49802, "Interface\\Icons\\Ability_Druid_Maim"),
    dpsAbility("DRUID_SHRED", "DRUID", "Растерзать", 48572, "Interface\\Icons\\Spell_Shadow_VampiricAura"),
    dpsAbility("DRUID_FERAL_CHARGE_CAT", "DRUID", "Рывок в форме кошки", 49376, "Interface\\Icons\\Ability_Druid_FeralCharge"),
    dpsAbility("DRUID_CYCLONE", "DRUID", "Циклон", 33786, "Interface\\Icons\\Spell_Nature_EarthBind"),
    dpsAbility("DRUID_BASH", "DRUID", "Оглушение", 8983, "Interface\\Icons\\Ability_Druid_Bash"),

    -- DEATH KNIGHT
    dpsAbility("DEATHKNIGHT_FROST_STRIKE", "DEATHKNIGHT", "Ледяной удар", 55268, "Interface\\Icons\\Spell_DeathKnight_FrostStrike"),
    dpsAbility("DEATHKNIGHT_HOWLING_BLAST", "DEATHKNIGHT", "Воющий ветер", 51411, "Interface\\Icons\\Spell_Frost_ArcticWinds"),
    dpsAbility("DEATHKNIGHT_DEATH_STRIKE", "DEATHKNIGHT", "Удар смерти", 49998, "Interface\\Icons\\Spell_DeathKnight_BloodStrike"),
    dpsAbility("DEATHKNIGHT_DANCING_RUNE_WEAPON", "DEATHKNIGHT", "Танцующее руническое оружие", 49028, "Interface\\Icons\\INV_Sword_07"),
    dpsAbility("DEATHKNIGHT_OBLITERATE", "DEATHKNIGHT", "Уничтожение", 51425, "Interface\\Icons\\Spell_DeathKnight_Obliterate"),
    dpsAbility("DEATHKNIGHT_DEATH_COIL", "DEATHKNIGHT", "Лик смерти", 49895, "Interface\\Icons\\Spell_Shadow_DeathCoil"),
    dpsAbility("DEATHKNIGHT_ICY_TOUCH", "DEATHKNIGHT", "Ледяное прикосновение", 49909, "Interface\\Icons\\Spell_DeathKnight_IcyTouch"),
    dpsAbility("DEATHKNIGHT_PLAGUE_STRIKE", "DEATHKNIGHT", "Удар чумы", 49921, "Interface\\Icons\\Spell_DeathKnight_PlagueStrike"),
    dpsAbility("DEATHKNIGHT_DEATH_AND_DECAY", "DEATHKNIGHT", "Лик смерти и разложение", 49938, "Interface\\Icons\\Spell_Shadow_DeathAndDecay"),
    dpsAbility("DEATHKNIGHT_STRANGULATE", "DEATHKNIGHT", "Удушение", 47476, "Interface\\Icons\\Spell_Shadow_SoulLeech_3"),
    dpsAbility("DEATHKNIGHT_MIND_FREEZE", "DEATHKNIGHT", "Антимагия", 47528, "Interface\\Icons\\Spell_DeathKnight_MindFreeze"),
    dpsAbility("DEATHKNIGHT_DEATH_GRIP", "DEATHKNIGHT", "Хватка смерти", 49576, "Interface\\Icons\\Spell_DeathKnight_Strangulate"),
    dpsAbility("DEATHKNIGHT_CHAINS_ICE", "DEATHKNIGHT", "Цепи льда", 45524, "Interface\\Icons\\Spell_Frost_ChainsOfIce"),
    dpsAbility("DEATHKNIGHT_ARMY_DEAD", "DEATHKNIGHT", "Армия мертвых", 42650, "Interface\\Icons\\Spell_DeathKnight_ArmyOfTheDead"),
}

local function ensureDPSAbilityConfig(definition)
    DamageLifeDB = DamageLifeDB or {}
    DamageLifeDB.abilitySettings = DamageLifeDB.abilitySettings or {}
    local config = DamageLifeDB.abilitySettings[definition.key]
    if type(config) ~= "table" then
        config = {}
        DamageLifeDB.abilitySettings[definition.key] = config
    end
    if type(config.phrases) ~= "table" then config.phrases = {} end
    if type(config.phraseEnabled) ~= "table" then config.phraseEnabled = {} end
    if config.emote == nil then config.emote = false end
    if config.whisper == nil then config.whisper = false end
    for index, phrase in ipairs(definition.defaults or dpsPhrases) do
        if config.phrases[index] == nil then config.phrases[index] = phrase end
        if index > 1 and config.phraseEnabled[index] == nil then config.phraseEnabled[index] = true end
    end
    if DamageLifeDB[definition.setting] == nil then DamageLifeDB[definition.setting] = true end
    return config
end

local definitionsByClass = {}
for classKey in pairs(compactClassInfo) do definitionsByClass[classKey] = {} end
for _, definition in ipairs(DamageLifeClassAbilityDefinitions or {}) do
    if definitionsByClass[definition.class] then table.insert(definitionsByClass[definition.class], definition) end
end
for _, definition in ipairs(DamageLifeClassAbilityDefinitions or {}) do
    ensureDPSAbilityConfig(definition)
end

for classKey, info in pairs(compactClassInfo) do
    local pageKey, pageInfo = classKey, info
    local p = makePage(pageKey)
    pageTitle(p, info[1], "Выберите способность. У каждой способности своя отдельная страница настроек.", info[2])
    p.master = check(p, "LSCompactClassMaster" .. pageKey, compactMasterLabels[pageKey], 6, -80, info[3], function(enabled)
        if p.SetDetailsExpanded then p:SetDetailsExpanded(enabled) end
    end)

    local preservedChildren, preservedRegions = {}, {}
    for _, child in ipairs({ p:GetChildren() }) do preservedChildren[child] = true end
    for _, region in ipairs({ p:GetRegions() }) do preservedRegions[region] = true end

    local abilityRows = math.max(1, math.ceil(#definitionsByClass[pageKey] / 3))
    local editorTitleY = -201 - (abilityRows - 1) * 44
    local editorTitle = p:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
    editorTitle:SetPoint("TOPLEFT", 58, editorTitleY); editorTitle:SetWidth(560); editorTitle:SetJustifyH("LEFT")
    local editorIcon = p:CreateTexture(nil, "ARTWORK")
    editorIcon:SetSize(30, 30); editorIcon:SetPoint("TOPLEFT", 20, editorTitleY + 7)
    p.editorTitle, p.editorIcon = editorTitle, editorIcon
    local editorSeparator = CreateFrame("Frame", nil, p)
    editorSeparator:SetSize(620, 2); editorSeparator:SetPoint("TOPLEFT", 15, editorTitleY + 14)
    DamageLifeTheme:CreateGradientLine(editorSeparator, "TOP", 0, 620, 2)
    p.editorSeparator = editorSeparator

    p.abilityButtons, p.abilityChecks = {}, {}
    p.selectedAbility = definitionsByClass[pageKey][1]
    for abilityIndex, rawDefinition in ipairs(definitionsByClass[pageKey]) do
        local definition = rawDefinition
        local col, row = (abilityIndex - 1) % 3, math.floor((abilityIndex - 1) / 3)
        local x, y = 5 + col * 220, -135 - row * 44
        local button = CreateFrame("Button", nil, p)
        button:SetSize(210, 38); button:SetPoint("TOPLEFT", x, y); button:SetText(compactAbilityLabels[definition.key] or definition.label)
        button:SetScript("OnClick", function() if p.SelectAbility then p:SelectAbility(definition) end end)
        DamageLifeTheme:StyleNavButton(button)
        local buttonText = button:GetFontString()
        buttonText:ClearAllPoints(); buttonText:SetPoint("LEFT", 42, 0); buttonText:SetPoint("RIGHT", -38, 0)
        buttonText:SetJustifyH("LEFT"); buttonText:SetWordWrap(false)
        local icon = button:CreateTexture(nil, "OVERLAY")
        icon:SetDrawLayer("OVERLAY", 2)
        icon:SetSize(24, 24); icon:SetPoint("LEFT", 8, 0)
        local iconPath = select(3, GetSpellInfo(definition.spellId)) or definition.icon or "Interface\Icons\INV_Misc_QuestionMark"
        icon:SetTexture(iconPath)
        local classFrame = button:CreateTexture(nil, "ARTWORK")
        classFrame:SetSize(32, 32); classFrame:SetPoint("LEFT", 4, 0)
        local classFrameName = definition.class == "DEATHKNIGHT" and "DEATHKNIGHT" or definition.class
        classFrame:SetTexture("Interface\\AddOns\\DamageLife\\Textures\\ClassFrame_" .. classFrameName .. ".tga")
        classFrame:SetVertexColor(1, 1, 1, 0.95)
        icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
        local enabled = check(p, "LSAbilityEnabled" .. definition.key, "", 0, 0, definition.setting)
        enabled:ClearAllPoints(); enabled:SetPoint("RIGHT", button, "RIGHT", -3, 0)
        enabled:SetFrameLevel(button:GetFrameLevel() + 3); enabled:EnableMouse(true); enabled:SetHitRectInsets(-4, -4, -4, -4)
        enabled:SetScript("OnClick", function(self)
            local isEnabled = self:GetChecked() and true or false
            DamageLifeDB[definition.setting] = isEnabled
            if p.selectedAbility and p.selectedAbility.key == definition.key and p.SetEditorExpanded then p:SetEditorExpanded(isEnabled) end
        end)
            rawset(p.abilityButtons, definition.key, button); rawset(p.abilityChecks, definition.key, enabled)
    end

    p.emoteCheck = check(p, "LSAbilityEmote" .. pageKey, "Объявлять применение в эмоции", 15, editorTitleY - 48, info[3])
    p.emoteCheck:SetScript("OnClick", function(self)
        local definition = p.selectedAbility
        if definition then
            local config = ensureDPSAbilityConfig(definition)
            config.emote = self:GetChecked() and true or false
        end
    end)
    p.whisperCheck = check(p, "LSAbilityWhisper" .. pageKey, "Сообщать цели в личку", 15, editorTitleY - 83, info[3])
    p.whisperCheck:SetScript("OnClick", function(self)
        local definition = p.selectedAbility
        if definition and not definition.groupWide then
            local config = ensureDPSAbilityConfig(definition)
            config.whisper = self:GetChecked() and true or false
        end
    end)
    p.groupHint = p:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
    p.groupHint:SetPoint("TOPLEFT", 25, editorTitleY - 118); p.groupHint:SetWidth(610); p.groupHint:SetJustifyH("LEFT")
    p.groupHint:SetText("Боевой эффект: используйте настройки фразы и звука для тестирования интерфейса.")

    local phraseHint = p:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
    phraseHint:SetPoint("TOPLEFT", 20, editorTitleY - 151); phraseHint:SetWidth(610); phraseHint:SetJustifyH("LEFT")
    phraseHint:SetText("{target} — цель, {spell} — ссылка на способность.")
    local baseLabel = p:CreateFontString(nil, "ARTWORK", "GameFontNormalSmall")
    baseLabel:SetPoint("TOPLEFT", 20, editorTitleY - 181); baseLabel:SetText("Базовая")
    p.phraseHint, p.baseLabel = phraseHint, baseLabel

    p.abilityPhraseChecks, p.abilityPhraseEdits = {}, {}
    p.abilityPhraseEdits[1] = edit(p, 85, editorTitleY - 193, 550, "", function(value)
        local definition = p.selectedAbility
        if definition then
            local config = ensureDPSAbilityConfig(definition)
            config.phrases[1] = value
        end
    end, { maxLetters = 70 })
    for phraseIndex = 2, 6 do
        local index = phraseIndex
        local y = editorTitleY - 193 - (phraseIndex - 1) * 36
        local phraseCheck = check(p, "LSAbilityPhrase" .. pageKey .. index, "", 15, y - 8, info[3])
        phraseCheck:SetScript("OnClick", function(self)
            local definition = p.selectedAbility
            if definition then
                local config = ensureDPSAbilityConfig(definition)
                config.phraseEnabled[index] = self:GetChecked() and true or false
            end
        end)
        p.abilityPhraseChecks[index] = phraseCheck
        p.abilityPhraseEdits[index] = edit(p, 50, y, 585, "", function(value)
            local definition = p.selectedAbility
            if definition then
                local config = ensureDPSAbilityConfig(definition)
                config.phrases[index] = value
            end
        end, { maxLetters = 70 })
    end
    local lastPhraseTop = editorTitleY - 193 - 5 * 36
    p.soundCheck = check(p, "LSAbilitySound" .. pageKey, "Свой звук способности", 15, lastPhraseTop - 45, info[3])
    p.soundCheck:SetScript("OnClick", function(self)
        local definition = p.selectedAbility
        if definition and DamageLifeAbilitySounds then DamageLifeAbilitySounds:SetEnabled(definition.key, self:GetChecked()) end
    end)
    p.soundPath = p:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
    p.soundPath:SetPoint("TOPLEFT", 45, lastPhraseTop - 112); p.soundPath:SetWidth(475); p.soundPath:SetJustifyH("LEFT")
    p.soundFileLabel = p:CreateFontString(nil, "ARTWORK", "GameFontNormalSmall")
    p.soundFileLabel:SetPoint("TOPLEFT", 45, lastPhraseTop - 80); p.soundFileLabel:SetText("Имя файла")
    p.soundFileEdit = edit(p, 125, lastPhraseTop - 70, 330, "", function(value)
        local definition = p.selectedAbility
        if definition and DamageLifeAbilitySounds and not DamageLifeAbilitySounds:SetFileName(definition.key, "Class", value) then
            DEFAULT_CHAT_FRAME:AddMessage("|cffff5555DamageLife:|r Поддерживаются файлы .ogg, .mp3 и .wav")
        end
    end, { maxLetters = 120 })
    p.soundPreview = CreateFrame("Button", nil, p, "UIPanelButtonTemplate")
    p.soundPreview:SetSize(110, 25); p.soundPreview:SetPoint("TOPLEFT", 525, lastPhraseTop - 48); p.soundPreview:SetText("Проверить")
    p.soundPreview:SetScript("OnClick", function()
        local definition = p.selectedAbility
        if definition and DamageLifeAbilitySounds then DamageLifeAbilitySounds:Play(definition.key, "Class", true) end
    end)
    p.lsContentHeight = math.max(600, -lastPhraseTop + 158)

    p.editorObjects = { editorTitle, editorIcon, editorSeparator, p.emoteCheck, phraseHint, baseLabel, p.abilityPhraseEdits[1], p.soundCheck, p.soundPath, p.soundFileLabel, p.soundFileEdit, p.soundPreview }
    for i = 2, 6 do
        table.insert(p.editorObjects, p.abilityPhraseChecks[i])
        table.insert(p.editorObjects, p.abilityPhraseEdits[i])
    end
    function p:SetEditorExpanded(expanded)
        for _, object in ipairs(self.editorObjects) do if expanded then object:Show() else object:Hide() end end
        if not expanded then
            self.whisperCheck:Hide(); self.groupHint:Hide()
        elseif self.selectedAbility and self.selectedAbility.whisperOnly then
            self.emoteCheck:Hide(); self.groupHint:Hide(); self.whisperCheck:Show()
        elseif self.selectedAbility and self.selectedAbility.groupWide then
            self.whisperCheck:Hide(); self.groupHint:Show()
        else
            self.groupHint:Hide(); self.whisperCheck:Show()
        end
    end

    function p:SelectAbility(definition)
        if not definition then return end
        self.selectedAbility = definition
        DamageLifeDB.selectedAbilityTabs = DamageLifeDB.selectedAbilityTabs or {}
        DamageLifeDB.selectedAbilityTabs[pageKey] = definition.key
        local config = ensureDPSAbilityConfig(definition)
        editorTitle:SetText(T("ABILITY_" .. definition.key, definition.label))
        editorIcon:SetTexture(select(3, GetSpellInfo(definition.spellId)) or definition.icon or "Interface\Icons\INV_Misc_QuestionMark")
        local announceLabel = _G[p.emoteCheck:GetName() .. "Text"]
        if announceLabel then
            announceLabel:SetText(definition.announcementChannel == "YELL" and T("ABILITY_YELL", "Объявлять применение криком (/к)") or T("ABILITY_EMOTE", "Объявлять применение в эмоции"))
        end
        if definition.announcementChannel == "YELL" then
            self.groupHint:SetText(T("ABILITY_GROUP_YELL", "Боевой эффект: фраза и звук пока используются только для тестирования интерфейса."))
        else
            self.groupHint:SetText(T("ABILITY_GROUP", "Боевой эффект: используйте настройки фразы и звука для тестирования интерфейса."))
        end
        for abilityKey, button in pairs(self.abilityButtons) do DamageLifeTheme:SetNavSelected(button, abilityKey == definition.key) end
        self.emoteCheck:SetChecked(config.emote)
        if definition.whisperOnly then
            self.emoteCheck:Hide(); self.groupHint:Hide(); self.whisperCheck:Show(); self.whisperCheck:SetChecked(config.whisper)
        elseif definition.groupWide then
            self.whisperCheck:Hide(); self.groupHint:Show()
        else
            self.groupHint:Hide(); self.whisperCheck:Show(); self.whisperCheck:SetChecked(config.whisper)
        end
        for i = 1, 6 do
            if i > 1 then self.abilityPhraseChecks[i]:SetChecked(config.phraseEnabled[i]) end
            if not self.abilityPhraseEdits[i]:HasFocus() then self.abilityPhraseEdits[i]:SetText(config.phrases[i] or "") end
        end
        if DamageLifeAbilitySounds then
            self.soundCheck:SetChecked(DamageLifeAbilitySounds:IsEnabled(definition.key))
            if not self.soundFileEdit:HasFocus() then self.soundFileEdit:SetText(DamageLifeAbilitySounds:GetFileName(definition.key, "Class")) end
            self.soundPath:SetText("Файл: " .. DamageLifeAbilitySounds:GetFolderHint(definition.key, "Class"))
        end
        self:SetEditorExpanded(DamageLifeDB[definition.setting])
    end

    p.detailObjects = {}
    for _, child in ipairs({ p:GetChildren() }) do if not preservedChildren[child] then table.insert(p.detailObjects, child) end end
    for _, region in ipairs({ p:GetRegions() }) do if not preservedRegions[region] then table.insert(p.detailObjects, region) end end
    function p:SetDetailsExpanded(expanded)
        for _, object in ipairs(self.detailObjects) do if expanded then object:Show() else object:Hide() end end
        if expanded and self.selectedAbility then
            ensureDPSAbilityConfig(self.selectedAbility)
            self:SelectAbility(self.selectedAbility)
        end
    end
    local classPage = p
    refreshers[pageKey] = function()
        classPage.master:SetChecked(DamageLifeDB[pageInfo[3]])
        for _, definition in ipairs(definitionsByClass[pageKey]) do classPage.abilityChecks[definition.key]:SetChecked(DamageLifeDB[definition.setting]) end
        local selectedKey = DamageLifeDB.selectedAbilityTabs and DamageLifeDB.selectedAbilityTabs[pageKey]
        if selectedKey then
            for _, definition in ipairs(definitionsByClass[pageKey]) do if definition.key == selectedKey then classPage.selectedAbility = definition; break end end
        end
        classPage:SetDetailsExpanded(DamageLifeDB[pageInfo[3]])
    end
end

-- Старые развёрнутые страницы оставлены ниже только как миграционный код и не создаются.
--[[
if false then
local classInfo = {
    PRIEST = { "Жрец", "|cffffffff", "priestBuffsEnabled", { "Подавление боли", "Придание сил", "Оберегающий дух" } },
    PALADIN = { "Паладин", "|cfff58cba", "paladinBuffsEnabled", { "Возложение рук", "Частица Света", "Длань защиты", "Божественное вмешательство", "Длань свободы", "Длань жертвенности" } },
    DRUID = { "Друид", "|cffff7d0a", "druidBuffsEnabled", { "Озарение" } },
    SHAMAN = { "Шаман", "|cff0070de", "shamanBuffsEnabled", { "Щит земли", "Жажда крови" } },
}
for key, info in pairs(classInfo) do
    local classKey, classInfoRow = key, info
    local p = makePage(key); pageTitle(p, info[1], "Важные способности этого класса отслеживаются, объявляются в эмоции и могут учитываться в статистике.", info[2])
    local masterLabel
    if key == "PRIEST" then masterLabel = "Включить отслеживание защитных способностей жреца"
    elseif key == "PALADIN" then masterLabel = "Включить отслеживание способностей паладина"
    elseif key == "DRUID" then masterLabel = "Включить отслеживание способностей друида"
    elseif key == "SHAMAN" then masterLabel = "Включить отслеживание способностей шамана"
    else masterLabel = "Включить отслеживание защитных способностей класса" end
    p.master = check(p, "LSClassMaster" .. key, masterLabel, 6, -80, info[3], function(enabled)
        if p.SetDetailsExpanded then p:SetDetailsExpanded(enabled) end
    end)
    local preservedChildren, preservedRegions = {}, {}
    for _, child in ipairs({ p:GetChildren() }) do preservedChildren[child] = true end
    for _, region in ipairs({ p:GetRegions() }) do preservedRegions[region] = true end
    local h = p:CreateFontString(nil, "ARTWORK", "GameFontNormal"); h:SetPoint("TOPLEFT", 12, -135); h:SetText("Отслеживаемые способности:")
    if key == "PRIEST" then
        local priestIconFallbacks = {}
        priestIconFallbacks[33206] = "Interface\\Icons\\Spell_Holy_PainSupression"
        priestIconFallbacks[10060] = "Interface\\Icons\\Spell_Holy_PowerInfusion"
        priestIconFallbacks[47788] = "Interface\\Icons\\Spell_Holy_GuardianSpirit"
        local function addSpellIcon(spellId, y)
            local iconPath = select(3, GetSpellInfo(spellId)) or priestIconFallbacks[spellId]
            local icon = p:CreateTexture(nil, "ARTWORK"); icon:SetSize(24, 24); icon:SetPoint("TOPLEFT", 22, y); icon:SetTexture(iconPath); return icon
        end
        addSpellIcon(33206, -160); p.pain = check(p, "LSPriestPainSuppression", "Подавление боли", 48, -158, "painSuppressionEnabled")
        addSpellIcon(10060, -195); p.power = check(p, "LSPriestPowerInfusion", "Придание сил", 48, -193, "powerInfusionEnabled")
        addSpellIcon(47788, -230); p.guardian = check(p, "LSPriestGuardianSpirit", "Оберегающий дух", 48, -228, "guardianSpiritEnabled")
        p.buffChat = check(p, "LSPriestBuffChat", "Писать применение способности в эмоцию", 20, -272, "priestBuffChatEnabled")
        p.buffWhisper = check(p, "LSPriestBuffWhisper", "Сообщать игроку в личку о наложенном бафе", 20, -305, "priestBuffWhisperEnabled")
        local phraseHint = p:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall"); phraseHint:SetPoint("TOPLEFT", 28, -345); phraseHint:SetWidth(540); phraseHint:SetJustifyH("LEFT")
        phraseHint:SetText("Свои фразы: {target} — ник цели, {spell} — кликабельная ссылка способности.")
        p.priestPhraseChecks, p.priestPhraseEdits = {}, {}
        local baseLabel = p:CreateFontString(nil, "ARTWORK", "GameFontNormalSmall"); baseLabel:SetPoint("TOPLEFT", 25, -382); baseLabel:SetText("Базовая")
        p.priestPhraseEdits[1] = edit(p, 95, -372, 475, "", function(value) DamageLifeDB.priestBuffPhrases[1] = value end)
        for phraseIndex = 2, 6 do
            local index = phraseIndex
            local y = -372 - (phraseIndex - 1) * 38
            p.priestPhraseChecks[index] = check(p, "LSPriestPhrase" .. index, "", 20, y - 8, "priestBuffPhraseEnabled")
            p.priestPhraseChecks[index]:SetScript("OnClick", function(self) DamageLifeDB.priestBuffPhraseEnabled[index] = self:GetChecked() and true or false end)
            p.priestPhraseEdits[index] = edit(p, 55, y, 515, "", function(value) DamageLifeDB.priestBuffPhrases[index] = value end)
        end
    elseif key == "PALADIN" then
        local paladinSpells = {
            { 48788, "Возложение рук", "layOnHandsEnabled", "Interface\\Icons\\Spell_Holy_LayOnHands" },
            { 53563, "Частица Света", "beaconOfLightEnabled", "Interface\\Icons\\Ability_Paladin_BeaconofLight" },
            { 10278, "Длань защиты", "handOfProtectionEnabled", "Interface\\Icons\\Spell_Holy_SealOfProtection" },
            { 19752, "Божественное вмешательство", "divineInterventionEnabled", "Interface\\Icons\\Spell_Nature_TimeStop" },
            { 1044, "Длань свободы", "handOfFreedomEnabled", "Interface\\Icons\\Spell_Holy_SealOfValor" },
            { 6940, "Длань жертвенности", "handOfSacrificeEnabled", "Interface\\Icons\\Spell_Holy_SealOfSacrifice" },
        }
        p.paladinSpellChecks = {}
        for spellIndex, spell in ipairs(paladinSpells) do
            local y = -155 - (spellIndex - 1) * 29
            local iconPath = select(3, GetSpellInfo(spell[1])) or spell[4]
            local icon = p:CreateTexture(nil, "ARTWORK"); icon:SetSize(23, 23); icon:SetPoint("TOPLEFT", 22, y - 2); icon:SetTexture(iconPath)
            local spellKey = tostring(spell[3])
            rawset(p.paladinSpellChecks, spellKey, check(p, "LSPaladinSpell" .. spellIndex, spell[2], 48, y, spellKey))
        end
        p.paladinChat = check(p, "LSPaladinBuffChat", "Писать применение способности в эмоцию", 20, -337, "paladinBuffChatEnabled")
        p.paladinWhisper = check(p, "LSPaladinBuffWhisper", "Сообщать игроку в личку о наложенном бафе", 20, -370, "paladinBuffWhisperEnabled")
        local phraseHint = p:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall"); phraseHint:SetPoint("TOPLEFT", 28, -407); phraseHint:SetWidth(540); phraseHint:SetJustifyH("LEFT")
        phraseHint:SetText("Свои фразы: {target} — ник цели, {spell} — кликабельная ссылка способности.")
        p.paladinPhraseChecks, p.paladinPhraseEdits = {}, {}
        local baseLabel = p:CreateFontString(nil, "ARTWORK", "GameFontNormalSmall"); baseLabel:SetPoint("TOPLEFT", 25, -440); baseLabel:SetText("Базовая")
        p.paladinPhraseEdits[1] = edit(p, 95, -430, 475, "", function(value) DamageLifeDB.paladinBuffPhrases[1] = value end)
        for phraseIndex = 2, 6 do
            local index = phraseIndex; local y = -430 - (phraseIndex - 1) * 34
            p.paladinPhraseChecks[index] = check(p, "LSPaladinPhrase" .. index, "", 20, y - 8, "paladinBuffPhraseEnabled")
            p.paladinPhraseChecks[index]:SetScript("OnClick", function(self) DamageLifeDB.paladinBuffPhraseEnabled[index] = self:GetChecked() and true or false end)
            p.paladinPhraseEdits[index] = edit(p, 55, y, 515, "", function(value) DamageLifeDB.paladinBuffPhrases[index] = value end)
        end
    elseif key == "DRUID" then
        local spellId = 29166
        local iconPath = select(3, GetSpellInfo(spellId)) or "Interface\\Icons\\Spell_Nature_Lightning"
        local icon = p:CreateTexture(nil, "ARTWORK"); icon:SetSize(24, 24); icon:SetPoint("TOPLEFT", 22, -162); icon:SetTexture(iconPath)
        p.innervate = check(p, "LSDruidInnervate", "Озарение", 48, -160, "innervateEnabled")
        p.druidChat = check(p, "LSDruidBuffChat", "Писать применение способности в эмоцию", 20, -215, "druidBuffChatEnabled")
        p.druidWhisper = check(p, "LSDruidBuffWhisper", "Сообщать игроку в личку о наложенном бафе", 20, -248, "druidBuffWhisperEnabled")
    elseif key == "SHAMAN" then
        local shamanSpells = {
            { 49284, "Щит земли", "earthShieldEnabled", "Interface\\Icons\\Spell_Nature_SkinofEarth" },
            { 2825, "Жажда крови / Героизм", "bloodlustEnabled", "Interface\\Icons\\Spell_Nature_BloodLust" },
        }
        p.shamanSpellChecks = {}
        for spellIndex, spell in ipairs(shamanSpells) do
            local y = -160 - (spellIndex - 1) * 35
            local iconPath = select(3, GetSpellInfo(spell[1])) or spell[4]
            local icon = p:CreateTexture(nil, "ARTWORK"); icon:SetSize(24, 24); icon:SetPoint("TOPLEFT", 22, y - 2); icon:SetTexture(iconPath)
            rawset(p.shamanSpellChecks, tostring(spell[3]), check(p, "LSShamanSpell" .. spellIndex, spell[2], 48, y, tostring(spell[3])))
        end
        p.shamanChat = check(p, "LSShamanBuffChat", "Писать применение способности в эмоцию", 20, -250, "shamanBuffChatEnabled")
        p.shamanWhisper = check(p, "LSShamanBuffWhisper", "Сообщать игроку в личку о наложенном бафе", 20, -283, "shamanBuffWhisperEnabled")
        local bloodlustHint = p:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall"); bloodlustHint:SetPoint("TOPLEFT", 28, -325); bloodlustHint:SetWidth(560); bloodlustHint:SetJustifyH("LEFT")
        bloodlustHint:SetText("Жажда крови объявляется один раз для всей группы и не рассылает личные сообщения каждому участнику.")
    else
        for i, spell in ipairs(info[4]) do local line = p:CreateFontString(nil, "ARTWORK", "GameFontHighlight"); line:SetPoint("TOPLEFT", 25, -165 - (i - 1) * 27); line:SetText("• " .. spell) end
    end
    p.detailObjects = {}
    for _, child in ipairs({ p:GetChildren() }) do if not preservedChildren[child] then table.insert(p.detailObjects, child) end end
    for _, region in ipairs({ p:GetRegions() }) do if not preservedRegions[region] then table.insert(p.detailObjects, region) end end
    function p:SetDetailsExpanded(expanded)
        for _, object in ipairs(self.detailObjects) do if expanded then object:Show() else object:Hide() end end
    end
    local classPage = p
    refreshers[classKey] = function()
        local masterEnabled = rawget(DamageLifeDB, classInfoRow[3])
        classPage.master:SetChecked(masterEnabled)
        classPage:SetDetailsExpanded(masterEnabled)
        if classKey == "PRIEST" then
            classPage.pain:SetChecked(DamageLifeDB.painSuppressionEnabled)
            classPage.power:SetChecked(DamageLifeDB.powerInfusionEnabled)
            classPage.guardian:SetChecked(DamageLifeDB.guardianSpiritEnabled)
            classPage.buffChat:SetChecked(DamageLifeDB.priestBuffChatEnabled)
            classPage.buffWhisper:SetChecked(DamageLifeDB.priestBuffWhisperEnabled)
            for i = 1, 6 do
                if i > 1 then classPage.priestPhraseChecks[i]:SetChecked(DamageLifeDB.priestBuffPhraseEnabled[i]) end
                if not classPage.priestPhraseEdits[i]:HasFocus() then classPage.priestPhraseEdits[i]:SetText(DamageLifeDB.priestBuffPhrases[i] or "") end
            end
        elseif classKey == "PALADIN" then
            for setting, spellCheck in pairs(classPage.paladinSpellChecks) do spellCheck:SetChecked(DamageLifeDB[setting]) end
            classPage.paladinChat:SetChecked(DamageLifeDB.paladinBuffChatEnabled)
            classPage.paladinWhisper:SetChecked(DamageLifeDB.paladinBuffWhisperEnabled)
            for i = 1, 6 do
                if i > 1 then classPage.paladinPhraseChecks[i]:SetChecked(DamageLifeDB.paladinBuffPhraseEnabled[i]) end
                if not classPage.paladinPhraseEdits[i]:HasFocus() then classPage.paladinPhraseEdits[i]:SetText(DamageLifeDB.paladinBuffPhrases[i] or "") end
            end
        elseif classKey == "DRUID" then
            classPage.innervate:SetChecked(DamageLifeDB.innervateEnabled)
            classPage.druidChat:SetChecked(DamageLifeDB.druidBuffChatEnabled)
            classPage.druidWhisper:SetChecked(DamageLifeDB.druidBuffWhisperEnabled)
        elseif classKey == "SHAMAN" then
            for setting, spellCheck in pairs(classPage.shamanSpellChecks) do spellCheck:SetChecked(DamageLifeDB[setting]) end
            classPage.shamanChat:SetChecked(DamageLifeDB.shamanBuffChatEnabled)
            classPage.shamanWhisper:SetChecked(DamageLifeDB.shamanBuffWhisperEnabled)
        end
    end
end
end

-- Настройки оформления — первый раздел общей страницы.
]]
local preferences = makePage("PREFERENCES")
pageTitle(preferences, "Внешний вид", "Настройка внешнего вида интерфейса DamageLife.")

local fontLabel = preferences:CreateFontString(nil, "ARTWORK", "GameFontNormal")
fontLabel:SetPoint("TOPLEFT", 32, -104); fontLabel:SetText("Шрифт интерфейса")
local fontHint = preferences:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
fontHint:SetPoint("TOPLEFT", 32, -174); fontHint:SetWidth(610); fontHint:SetJustifyH("LEFT")
fontHint:SetTextColor(0.72, 0.72, 0.72); fontHint:SetText("Выбранный шрифт применяется ко всем окнам DamageLife и сохраняется для следующего входа в игру.")

local fontDefs = {
    { key = "STANDARD", label = "Standard" },
    { key = "FRITZ", label = "Fritz Quadrata Cyri" },
    { key = "MONTSERRAT", label = "Montserrat" },
    { key = "BEBAS", label = "Bebas Neue Regular" },
    { key = "AKZIDENZ", label = "Akzidenz-Grotesk Pro", needsFile = true },
    { key = "MORPHEUS", label = "Morpheus" },
}
local fontButton = CreateFrame("Button", nil, preferences)
fontButton:SetSize(350, 34); fontButton:SetPoint("TOPLEFT", 32, -128); fontButton:SetText("Fritz Quadrata Cyri")
local fontButtonText = fontButton:GetFontString(); fontButtonText:ClearAllPoints(); fontButtonText:SetPoint("LEFT", 12, 0); fontButtonText:SetPoint("RIGHT", -34, 0); fontButtonText:SetJustifyH("LEFT")
local fontArrow = fontButton:CreateFontString(nil, "OVERLAY", "GameFontNormal")
fontArrow:SetPoint("RIGHT", -12, 0); fontArrow:SetText("")
DamageLifeTheme:StyleButton(fontButton)

local fontPopup = CreateFrame("Frame", nil, preferences)
fontPopup:SetSize(350, 202); fontPopup:SetPoint("TOPLEFT", fontButton, "BOTTOMLEFT", 0, -3); fontPopup:SetFrameStrata("TOOLTIP")
fontPopup:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", edgeSize = 10, insets = { left = 3, right = 3, top = 3, bottom = 3 } })
fontPopup:SetBackdropColor(0.018, 0.012, 0.008, 0.98); fontPopup:SetBackdropBorderColor(0.7, 0.5, 0.08, 1); fontPopup:Hide()
local fontRows = {}
local function selectFont(definition)
    DamageLifeDB.fontKey = definition.key
    fontButton:SetText(definition.label)
    for key, row in pairs(fontRows) do DamageLifeTheme:SetNavSelected(row, key == definition.key) end
    fontPopup:Hide()
    DamageLifeTheme:SetFont(definition.key)
end
for i, definition in ipairs(fontDefs) do
    local fontDefinition = definition
    local row = CreateFrame("Button", nil, fontPopup); row:SetSize(338, 31); row:SetPoint("TOPLEFT", 6, -6 - (i - 1) * 31); row:SetText(fontDefinition.label)
    DamageLifeTheme:StyleNavButton(row)
    local rowText = row:GetFontString(); rowText:ClearAllPoints(); rowText:SetPoint("LEFT", 12, 0); rowText:SetPoint("RIGHT", -12, 0); rowText:SetJustifyH("LEFT")
    row:SetScript("OnClick", function() selectFont(fontDefinition) end)
    if fontDefinition.needsFile then
        row:SetScript("OnEnter", function(self)
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT"); GameTooltip:SetText("Akzidenz-Grotesk Pro", 1, 0.82, 0)
            GameTooltip:AddLine("Для этого коммерческого шрифта нужен лицензированный файл. Пока используется Standard.", 1, 1, 1, true); GameTooltip:Show()
        end)
        row:SetScript("OnLeave", function() GameTooltip:Hide() end)
    end
    fontRows[fontDefinition.key] = row
end
fontButton:SetScript("OnClick", function() if fontPopup:IsShown() then fontPopup:Hide() else fontPopup:Show() end end)

refreshers.PREFERENCES = function()
    local wanted = DamageLifeDB.fontKey or "FRITZ"
    local selectedDefinition = fontDefs[2]
    for _, definition in ipairs(fontDefs) do if definition.key == wanted then selectedDefinition = definition; break end end
    selectFont(selectedDefinition)
end

-- Единая прокручиваемая страница всех общих настроек.
local overview = makePage("OVERVIEW")
local overviewScroll = createSafeScrollFrame("LSOverviewScrollFrame", overview)
overviewScroll:SetPoint("TOPLEFT", 0, 0); overviewScroll:SetPoint("BOTTOMRIGHT", -24, 0)
local overviewChild = CreateFrame("Frame", nil, overviewScroll); overviewChild:SetSize(650, 2200); overviewScroll:SetScrollChild(overviewChild); overviewScroll:lsRebind()
local overviewSections = {
    { page = preferences, height = 220 },
    { page = general, height = 470 },
    { page = targetWindowsPage, height = 500 },
    { page = display, height = 340 },
    { page = series, height = 540 },
    { page = announce, height = 555 },
}
local overviewOffset = 0
for _, section in ipairs(overviewSections) do
    section.page:SetParent(overviewChild); section.page:ClearAllPoints(); section.page:SetPoint("TOPLEFT", overviewChild, "TOPLEFT", 0, -overviewOffset); section.page:SetSize(650, section.height)
    for _, region in ipairs({ section.page:GetRegions() }) do
        if region:IsObjectType("FontString") and region:GetWidth() > 640 then region:SetWidth(620) end
    end
    overviewOffset = overviewOffset + section.height
end
overviewChild:SetHeight(overviewOffset)
overviewScroll:SetScript("OnMouseWheel", function(self, delta)
    local nextValue = self:GetVerticalScroll() - delta * 55
    if nextValue < 0 then nextValue = 0 end
    local maximum = self:GetVerticalScrollRange(); if nextValue > maximum then nextValue = maximum end
    self:SetVerticalScroll(nextValue)
end)
refreshers.OVERVIEW = function()
    for _, key in ipairs({ "PREFERENCES", "GENERAL", "TARGET_WINDOWS", "DISPLAY", "SERIES", "ANNOUNCE" }) do
        if refreshers[key] then refreshers[key]() end
        pages[key]:Show()
    end
end

-- Единая страница классов с внутренними вкладками.
local classes = makePage("CLASSES")
local classHolder = CreateFrame("Frame", nil, classes); classHolder:SetPoint("TOPLEFT", 0, -98); classHolder:SetPoint("BOTTOMRIGHT", 0, 0)
local classScrolls = {}
local classTabs, selectedClassPage = {}, DamageLifeDB and DamageLifeDB.selectedClassTab or "WARRIOR"
local classTabDefs = {
    { "WARRIOR", "Воин" }, { "PALADIN", "Паладин" }, { "HUNTER", "Охотник" }, { "ROGUE", "Разбойник" }, { "PRIEST", "Жрец" },
    { "SHAMAN", "Шаман" }, { "MAGE", "Маг" }, { "WARLOCK", "Чернокнижник" }, { "DRUID", "Друид" }, { "DEATHKNIGHT", "Рыцарь смерти" },
}
for _, definition in ipairs(classTabDefs) do
    local classKey = definition[1]
    local classPage = pages[classKey]
    local classScroll = createSafeScrollFrame("DamageLifeClassScroll" .. classKey, classHolder)
    classScroll:SetPoint("TOPLEFT", 0, 0); classScroll:SetPoint("BOTTOMRIGHT", -24, 0)
    classPage:SetParent(classScroll); classPage:ClearAllPoints(); classPage:SetPoint("TOPLEFT", 0, 0)
    classPage:SetSize(660, classPage.lsContentHeight or 600); classScroll:SetScrollChild(classPage); classScroll:lsRebind()
    classScroll:SetScript("OnMouseWheel", function(self, delta)
        local nextValue = self:GetVerticalScroll() - delta * 48
        if nextValue < 0 then nextValue = 0 end
        local maximum = self:GetVerticalScrollRange(); if nextValue > maximum then nextValue = maximum end
        self:SetVerticalScroll(nextValue)
    end)
    classScrolls[classKey] = classScroll
end
local function showClassPage(key)
    selectedClassPage = key; DamageLifeDB.selectedClassTab = key
    for _, definition in ipairs(classTabDefs) do
        local classKey = definition[1]
        if classKey == key then classScrolls[classKey]:Show(); pages[classKey]:Show() else classScrolls[classKey]:Hide(); pages[classKey]:Hide() end
        DamageLifeTheme:SetNavSelected(classTabs[classKey], classKey == key)
        local classButtonText = classTabs[classKey] and classTabs[classKey]:GetFontString()
        if classButtonText then
            local rgb = compactClassInfo[classKey] and compactClassInfo[classKey][2]
            if type(rgb) == "table" then
                classButtonText:SetTextColor(rgb[1] or 1, rgb[2] or 0.82, rgb[3] or 0, rgb[4] or 1)
            end
        end
    end
    if refreshers[key] then refreshers[key]() end
end
for i, definition in ipairs(classTabDefs) do
    local key = definition[1]
    local column = (i - 1) % 5
    local row = math.floor((i - 1) / 5)
    local button = CreateFrame("Button", nil, classes)
    button:SetSize(126, 38)
    button:SetPoint("TOPLEFT", 2 + column * 132, -6 - row * 40)
    button:SetText(definition[2])
    button:SetScript("OnClick", function() showClassPage(key) end)
    DamageLifeTheme:StyleNavButton(button)
    classTabs[key] = button
end
refreshers.CLASSES = function()
    local wanted = DamageLifeDB.selectedClassTab or selectedClassPage or "PRIEST"
    if not pages[wanted] then wanted = "WARRIOR" end
    showClassPage(wanted)
end

-- Built-in control notifications. The list comes from one registry so adding
-- another spell does not require a new combat-log handler or page.
local controlPage = makePage("CONTROL")
pageTitle(controlPage, "Контроль", "Уведомления о применении эффектов контроля по вашей цели.")
local controlEnabled = check(controlPage, "LSControlAlertsEnabled", "Включить уведомления контроля", 6, -78, "controlAlertsEnabled", function(enabled)
    if DamageLifeControlAlerts then DamageLifeControlAlerts:SetEnabled(enabled) end
    if controlPage.SetDetailsExpanded then controlPage:SetDetailsExpanded(enabled) end
end)
local controlHint = controlPage:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
controlHint:SetPoint("TOPLEFT", 32, -112); controlHint:SetWidth(450); controlHint:SetJustifyH("LEFT")
controlHint:SetText("Выберите эффект контроля. Для каждого эффекта каналы задаются отдельно.")

local controlDefinitions = (DamageLifeControlAlerts and DamageLifeControlAlerts:GetDefinitions()) or {}
local controlButtons, controlChecks = {}, {}
local selectedControl = nil
local controlRows = math.ceil(#controlDefinitions / 3)
local controlEditorY = -160 - controlRows * 44
local controlEditorIcon = controlPage:CreateTexture(nil, "ARTWORK")
controlEditorIcon:SetSize(32, 32); controlEditorIcon:SetPoint("TOPLEFT", 20, controlEditorY + 7)
local controlEditorTitle = controlPage:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
controlEditorTitle:SetPoint("TOPLEFT", 60, controlEditorY); controlEditorTitle:SetWidth(560); controlEditorTitle:SetJustifyH("LEFT")
local controlSeparator = CreateFrame("Frame", nil, controlPage)
controlSeparator:SetSize(620, 2); controlSeparator:SetPoint("TOPLEFT", 15, controlEditorY + 14)
DamageLifeTheme:CreateGradientLine(controlSeparator, "TOP", 0, 620, 2)
local controlMessageHint = controlPage:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
controlMessageHint:SetPoint("TOPLEFT", 20, controlEditorY - 86); controlMessageHint:SetWidth(620); controlMessageHint:SetJustifyH("LEFT")
controlMessageHint:SetText("Шаблон для всех эффектов: Контролирую {target} с помощью {spell}!")
local controlMessageLabel = controlPage:CreateFontString(nil, "ARTWORK", "GameFontNormalSmall")
controlMessageLabel:SetPoint("TOPLEFT", 20, controlEditorY - 126); controlMessageLabel:SetText("Сообщение")
local controlMessageEdit = edit(controlPage, 105, controlEditorY - 116, 410, "", function(value)
    if not DamageLifeControlAlerts then return end
    if selectedControl then DamageLifeControlAlerts:SetMessage(selectedControl, value)
    else DamageLifeControlAlerts:SetInterruptMessage(value) end
end, { maxLetters = 100 })

local function nestedCheck(name, text, x, y, callback)
    local c = CreateFrame("CheckButton", name, controlPage, "InterfaceOptionsCheckButtonTemplate")
    c:SetPoint("TOPLEFT", x, y); _G[name .. "Text"]:SetText(text)
    c:SetScript("OnClick", function(self) callback(self:GetChecked() and true or false) end)
    return c
end
local controlSayCheck = nestedCheck("LSControlSayChannel", "Сказать", 20, controlEditorY - 42, function(enabled)
    if not DamageLifeControlAlerts then return end
    if selectedControl then DamageLifeControlAlerts:SetChannelEnabled(selectedControl, "say", enabled)
    else DamageLifeControlAlerts:SetInterruptChannelEnabled("say", enabled) end
end)
local controlGroupCheck = nestedCheck("LSControlGroupChannel", "Группа", 180, controlEditorY - 42, function(enabled)
    if not DamageLifeControlAlerts then return end
    if selectedControl then DamageLifeControlAlerts:SetChannelEnabled(selectedControl, "group", enabled)
    else DamageLifeControlAlerts:SetInterruptChannelEnabled("group", enabled) end
end)
local controlInterruptCheck = nestedCheck("LSControlInterruptEnabled", "Сообщать о сбитии каста", 345, controlEditorY - 42, function(enabled)
    if DamageLifeControlAlerts then DamageLifeControlAlerts:SetInterruptEnabled(enabled) end
end)
local controlPreview = CreateFrame("Button", nil, controlPage)
controlPreview:SetSize(110, 26); controlPreview:SetPoint("TOPLEFT", 525, controlEditorY - 116); controlPreview:SetText("Проверить")
controlPreview:SetScript("OnClick", function()
    if DamageLifeControlAlerts then DamageLifeControlAlerts:Preview(selectedControl) end
end)
DamageLifeTheme:StyleButton(controlPreview)
local controlSoundCheck = nestedCheck("LSControlCustomSound", "Свой звук контроля", 20, controlEditorY - 160, function(enabled)
    if selectedControl and DamageLifeAbilitySounds then DamageLifeAbilitySounds:SetEnabled(selectedControl.key, enabled) end
end)
local controlSoundPath = controlPage:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
controlSoundPath:SetPoint("TOPLEFT", 50, controlEditorY - 228); controlSoundPath:SetWidth(465); controlSoundPath:SetJustifyH("LEFT")
local controlSoundFileLabel = controlPage:CreateFontString(nil, "ARTWORK", "GameFontNormalSmall")
controlSoundFileLabel:SetPoint("TOPLEFT", 50, controlEditorY - 198); controlSoundFileLabel:SetText("Имя файла")
local controlSoundFileEdit = edit(controlPage, 130, controlEditorY - 188, 315, "", function(value)
    if selectedControl and DamageLifeAbilitySounds and not DamageLifeAbilitySounds:SetFileName(selectedControl.key, "Control", value) then
        DEFAULT_CHAT_FRAME:AddMessage("|cffff5555DamageLife:|r Поддерживаются файлы .ogg, .mp3 и .wav")
    end
end, { maxLetters = 120 })
local controlSoundPreview = CreateFrame("Button", nil, controlPage, "UIPanelButtonTemplate")
controlSoundPreview:SetSize(110, 25); controlSoundPreview:SetPoint("TOPLEFT", 525, controlEditorY - 164); controlSoundPreview:SetText("Проверить звук")
controlSoundPreview:SetScript("OnClick", function()
    if selectedControl and DamageLifeAbilitySounds then DamageLifeAbilitySounds:Play(selectedControl.key, "Control", true) end
end)

local interruptDefinitions = (DamageLifeControlAlerts and DamageLifeControlAlerts:GetInterruptDefinitions()) or {}
local interruptTitle = controlPage:CreateFontString(nil, "ARTWORK", "GameFontNormalSmall")
interruptTitle:SetPoint("TOPLEFT", 20, controlEditorY - 82); interruptTitle:SetText("Какие прерывания учитывать")
local interruptChecks = {}
for index, definition in ipairs(interruptDefinitions) do
    local interruptDefinition = definition
    local col, row = (index - 1) % 3, math.floor((index - 1) / 3)
    local name = "LSInterruptEffect" .. definition.key
    local c = nestedCheck(name, DamageLifeControlAlerts:GetLabel(definition), 20 + col * 205, controlEditorY - 102 - row * 30, function(enabled)
        if DamageLifeControlAlerts then DamageLifeControlAlerts:SetInterruptEffectEnabled(interruptDefinition, enabled) end
    end)
    interruptChecks[definition.key] = c
end
local controlEditorObjects = { controlEditorIcon, controlEditorTitle, controlSeparator, controlSayCheck, controlGroupCheck,
    controlInterruptCheck, controlMessageHint, controlMessageLabel, controlMessageEdit, controlPreview }
local generalEditorObjects = { interruptTitle }
for _, c in pairs(interruptChecks) do generalEditorObjects[#generalEditorObjects + 1] = c end
local dispelCheck = nestedCheck("LSControlDispelNotice", "Сообщать в /сказать, когда союзник снял с вас контроль", 20, controlEditorY - 72, function(enabled)
    if DamageLifeControlAlerts then DamageLifeControlAlerts:SetDispelEnabled(enabled) end
end)
generalEditorObjects[#generalEditorObjects + 1] = dispelCheck
controlEditorObjects[#controlEditorObjects + 1] = controlSoundCheck
controlEditorObjects[#controlEditorObjects + 1] = controlSoundPath
controlEditorObjects[#controlEditorObjects + 1] = controlSoundFileLabel
controlEditorObjects[#controlEditorObjects + 1] = controlSoundFileEdit
controlEditorObjects[#controlEditorObjects + 1] = controlSoundPreview

local function showControlTooltip(button, definition)
    GameTooltip:SetOwner(button, "ANCHOR_RIGHT")
    local spellId = definition.iconSpellId or definition.spellIds[1]
    if spellId and GameTooltip.SetHyperlink then GameTooltip:SetHyperlink("spell:" .. spellId)
    else GameTooltip:SetText(DamageLifeControlAlerts:GetLabel(definition), 1, 0.82, 0) end
    GameTooltip:Show()
end

local function setControlEditorExpanded(expanded)
    for _, object in ipairs(controlEditorObjects) do if expanded then object:Show() else object:Hide() end end
    if not expanded then for _, object in ipairs(generalEditorObjects) do object:Hide() end end
end

local function selectControl(definition)
    selectedControl = definition
    DamageLifeDB.selectedControlTab = definition and definition.key or "GENERAL"
    for key, button in pairs(controlButtons) do DamageLifeTheme:SetNavSelected(button, key == DamageLifeDB.selectedControlTab) end
    if definition then
        for _, object in ipairs(generalEditorObjects) do object:Hide() end
        controlMessageHint:ClearAllPoints(); controlMessageHint:SetPoint("TOPLEFT", 20, controlEditorY - 86)
        controlMessageLabel:ClearAllPoints(); controlMessageLabel:SetPoint("TOPLEFT", 20, controlEditorY - 126)
        controlMessageEdit:ClearAllPoints(); controlMessageEdit:SetPoint("TOPLEFT", 105, controlEditorY - 116)
        controlPreview:ClearAllPoints(); controlPreview:SetPoint("TOPLEFT", 525, controlEditorY - 116)
        controlEditorTitle:SetText(DamageLifeControlAlerts:GetLabel(definition))
        controlEditorIcon:SetTexture(select(3, GetSpellInfo(definition.iconSpellId or definition.spellIds[1])) or "Interface\\Icons\\INV_Misc_QuestionMark")
        local sayEnabled, groupEnabled = DamageLifeControlAlerts:GetChannels(definition)
        controlSayCheck:SetChecked(sayEnabled); controlGroupCheck:SetChecked(groupEnabled)
        controlInterruptCheck:Hide()
        controlMessageHint:SetText(T("CONTROL_EFFECT_HINT", "Единый шаблон: Контролирую {target} с помощью {spell}!"))
        if not controlMessageEdit:HasFocus() then controlMessageEdit:SetText(DamageLifeControlAlerts:GetMessage(definition) or "Контролирую {target} с помощью {spell}!") end
        if DamageLifeAbilitySounds then
            controlSoundCheck:SetChecked(DamageLifeAbilitySounds:IsEnabled(definition.key))
            if not controlSoundFileEdit:HasFocus() then controlSoundFileEdit:SetText(DamageLifeAbilitySounds:GetFileName(definition.key, "Control")) end
            controlSoundPath:SetText("Файл: " .. DamageLifeAbilitySounds:GetFolderHint(definition.key, "Control"))
            controlSoundCheck:Show(); controlSoundPath:Show(); controlSoundFileLabel:Show(); controlSoundFileEdit:Show(); controlSoundPreview:Show()
        end
        setControlEditorExpanded(DamageLifeControlAlerts:IsEffectEnabled(definition)); controlInterruptCheck:Hide()
    else
        local interrupt = DamageLifeControlAlerts:GetInterruptSettings()
        controlEditorTitle:SetText(T("CONTROL_GENERAL", "Общее"))
        controlEditorIcon:SetTexture("Interface\\Icons\\Ability_Kick")
        controlSayCheck:SetChecked(interrupt and interrupt.say ~= false)
        controlGroupCheck:SetChecked(interrupt and interrupt.group == true)
        controlInterruptCheck:SetChecked(interrupt and interrupt.enabled ~= false)
        local dispel = DamageLifeControlAlerts:GetDispelSettings()
        dispelCheck:SetChecked(dispel and dispel.enabled ~= false)
        controlSoundCheck:Hide(); controlSoundPath:Hide(); controlSoundFileLabel:Hide(); controlSoundFileEdit:Hide(); controlSoundPreview:Hide()
        for _, definition in ipairs(interruptDefinitions) do
            local c = interruptChecks[definition.key]
            c:SetChecked(DamageLifeControlAlerts:IsInterruptEnabled(definition)); c:Show()
        end
        interruptTitle:Show()
        controlMessageHint:ClearAllPoints(); controlMessageHint:SetPoint("TOPLEFT", 20, controlEditorY - 226)
        controlMessageLabel:ClearAllPoints(); controlMessageLabel:SetPoint("TOPLEFT", 20, controlEditorY - 266)
        controlMessageEdit:ClearAllPoints(); controlMessageEdit:SetPoint("TOPLEFT", 105, controlEditorY - 256)
        controlPreview:ClearAllPoints(); controlPreview:SetPoint("TOPLEFT", 525, controlEditorY - 256)
        controlMessageHint:SetText(T("CONTROL_INTERRUPT_HINT", "Сообщение при сбитии вашего каста. Доступно: {spell}, {interrupt} и {source}."))
        if not controlMessageEdit:HasFocus() then controlMessageEdit:SetText(interrupt and interrupt.message or "") end
        setControlEditorExpanded(true)
        controlSoundCheck:Hide(); controlSoundPath:Hide(); controlSoundFileLabel:Hide(); controlSoundFileEdit:Hide(); controlSoundPreview:Hide()
    end
end

local generalButton = CreateFrame("Button", nil, controlPage)
generalButton:SetSize(145, 32); generalButton:SetPoint("TOPLEFT", 500, -100); generalButton:SetText("Общее")
generalButton:SetScript("OnClick", function() selectControl(nil) end); DamageLifeTheme:StyleNavButton(generalButton)
controlButtons.GENERAL = generalButton

for index, definition in ipairs(controlDefinitions) do
    local effectDefinition = definition
    local gridIndex = index
    local col, row = (gridIndex - 1) % 3, math.floor((gridIndex - 1) / 3)
    local x, y = 5 + col * 220, -145 - row * 44
    local button = CreateFrame("Button", nil, controlPage)
    button:SetSize(218, 38); button:SetPoint("TOPLEFT", x, y)
    button:SetText(DamageLifeControlAlerts:GetLabel(definition))
    DamageLifeTheme:StyleNavButton(button)
    local buttonText = button:GetFontString(); buttonText:ClearAllPoints(); buttonText:SetPoint("LEFT", 39, 0); buttonText:SetPoint("RIGHT", -25, 0)
    buttonText:SetJustifyH("LEFT"); buttonText:SetWordWrap(false)
    local icon = button:CreateTexture(nil, "OVERLAY")
    icon:SetSize(26, 26); icon:SetPoint("LEFT", 7, 0)
    icon:SetTexture(select(3, GetSpellInfo(definition.iconSpellId or definition.spellIds[1])) or "Interface\\Icons\\INV_Misc_QuestionMark")
    icon:SetTexCoord(0.07, 0.93, 0.07, 0.93)
    local enabled = check(controlPage, "LSControlAlert" .. definition.key, "", 0, 0, definition.setting)
    enabled:ClearAllPoints(); enabled:SetPoint("RIGHT", button, "RIGHT", -3, 0)
    enabled:SetFrameLevel(button:GetFrameLevel() + 3); enabled:EnableMouse(true); enabled:SetHitRectInsets(-4, -4, -4, -4)
    enabled:SetScript("OnClick", function(self)
        local isEnabled = self:GetChecked() and true or false
        if DamageLifeControlAlerts then DamageLifeControlAlerts:SetEffectEnabled(effectDefinition, isEnabled) end
        if selectedControl and selectedControl.key == effectDefinition.key then selectControl(effectDefinition) end
    end)
    button:SetScript("OnClick", function() selectControl(effectDefinition) end)
    button:SetScript("OnEnter", function(self) showControlTooltip(self, effectDefinition) end)
    button:SetScript("OnLeave", function() GameTooltip:Hide() end)
    controlButtons[definition.key], controlChecks[definition.key] = button, enabled
end
controlPage.controlChecks, controlPage.controlEnabled, controlPage.controlButtons = controlChecks, controlEnabled, controlButtons
function controlPage:SetDetailsExpanded(expanded)
    if expanded then controlHint:Show() else controlHint:Hide() end
    for _, button in pairs(controlButtons) do if expanded then button:Show() else button:Hide() end end
    for _, effectCheck in pairs(controlChecks) do if expanded then effectCheck:Show() else effectCheck:Hide() end end
    if expanded then selectControl(selectedControl) else setControlEditorExpanded(false) end
end
refreshers.CONTROL = function()
    if DamageLifeControlAlerts and DamageLifeControlAlerts.GetDefinitions then
        local masterEnabled = DamageLifeDB.controlAlertsEnabled ~= false
        if type(DamageLifeDB.controlAlerts) == "table" then masterEnabled = DamageLifeDB.controlAlerts.enabled ~= false end
        controlEnabled:SetChecked(masterEnabled)
        for _, definition in ipairs(DamageLifeControlAlerts:GetDefinitions()) do
            if controlChecks[definition.key] then
                controlChecks[definition.key]:SetChecked(DamageLifeControlAlerts:IsEffectEnabled(definition))
            end
        end
        local selectedKey = DamageLifeDB.selectedControlTab or "GENERAL"
        selectedControl = nil
        if selectedKey ~= "GENERAL" then
            for _, definition in ipairs(controlDefinitions) do if definition.key == selectedKey then selectedControl = definition; break end end
        end
        controlPage:SetDetailsExpanded(masterEnabled)
    end
end

-- Safe profiles: plain data only. Imported text is parsed, never executed.
local profilesPage = makePage("PROFILES")
pageTitle(profilesPage, "Профили", "Экспортируйте настройки в текст или импортируйте их на другом персонаже.")
local profileBox = CreateFrame("EditBox", "DamageLifeProfileText", profilesPage)
profileBox:SetPoint("TOPLEFT", 18, -92); profileBox:SetSize(620, 350)
profileBox:SetMultiLine(true); profileBox:SetAutoFocus(false); profileBox:SetFontObject(ChatFontNormal)
profileBox:SetTextInsets(10, 10, 10, 10); profileBox:SetMaxLetters(200000)
profileBox:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", tile = true, tileSize = 8, edgeSize = 8, insets = { left = 2, right = 2, top = 2, bottom = 2 } })
profileBox:SetBackdropColor(0.012, 0.012, 0.012, 0.95); profileBox:SetBackdropBorderColor(0.65, 0.48, 0.08, 1)
profileBox:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
local profileStatus = profilesPage:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
profileStatus:SetPoint("TOPLEFT", 20, -458); profileStatus:SetWidth(610); profileStatus:SetJustifyH("LEFT")
profileStatus:SetText("Экспорт не содержит временную боевую статистику и счётчик поля боя.")
local exportProfile = CreateFrame("Button", nil, profilesPage, "UIPanelButtonTemplate")
exportProfile:SetSize(145, 28); exportProfile:SetPoint("TOPLEFT", 18, -500); exportProfile:SetText("Экспорт")
exportProfile:SetScript("OnClick", function()
    if DamageLifeProfiles then profileBox:SetText(DamageLifeProfiles:Export()); profileBox:SetFocus(); profileBox:HighlightText() end
end)
local importProfile = CreateFrame("Button", nil, profilesPage, "UIPanelButtonTemplate")
importProfile:SetSize(145, 28); importProfile:SetPoint("LEFT", exportProfile, "RIGHT", 12, 0); importProfile:SetText("Импорт")
importProfile:SetScript("OnClick", function()
    if not DamageLifeProfiles then return end
    local ok, message = DamageLifeProfiles:Import(profileBox:GetText())
    profileStatus:SetTextColor(ok and 0.3 or 1, ok and 1 or 0.25, ok and 0.3 or 0.25)
    profileStatus:SetText(message)
end)
local selectProfile = CreateFrame("Button", nil, profilesPage, "UIPanelButtonTemplate")
selectProfile:SetSize(145, 28); selectProfile:SetPoint("LEFT", importProfile, "RIGHT", 12, 0); selectProfile:SetText("Выделить всё")
selectProfile:SetScript("OnClick", function() profileBox:SetFocus(); profileBox:HighlightText() end)

local menu = {
    {"OVERVIEW", "Общие"}, {"EVENTS", "Боевые события"}, {"CLASSES", "Классы"}, {"CONTROL", "Контроль"},
    {"VOICE", "Озвучка"}, {"PROFILES", "Профили"}, {"ABOUT", "О проекте"},
}
local function showPage(key)
    selectedPage = key
    for pageKey, p in pairs(pages) do if pageKey == key then p:Show() else p:Hide() end end
    for buttonKey, b in pairs(menuButtons) do DamageLifeTheme:SetNavSelected(b, buttonKey == key) end
    if refreshers[key] then refreshers[key]() end
end
for i, item in ipairs(menu) do
    local b = CreateFrame("Button", nil, sidebar); b:SetSize(146, 38); b:SetPoint("TOPLEFT", 2, -4 - (i - 1) * 50); b:SetText(item[2]); b.pageKey = item[1]; b:SetScript("OnClick", function(self) showPage(self.pageKey) end); DamageLifeTheme:StyleNavButton(b); menuButtons[item[1]] = b
end

local function setPageLanguage(page, titleKey, titleFallback, noteKey, noteFallback)
    if not page or not page.lsTitle or not page.lsNote then return end
    page.lsTitle:SetText(T(titleKey, titleFallback))
    page.lsTitle:SetTextColor(parseTitleColor(page.lsTitleColor))
    page.lsNote:SetText(T(noteKey, noteFallback))
end
local function setCheckLanguage(control, key, fallback)
    local label = control and control:GetName() and _G[control:GetName() .. "Text"]
    if label then label:SetText(T(key, fallback)) end
end
local function setSliderLanguage(control, key, fallback)
    control.lsLabel = T(key, fallback)
    local label = _G[control:GetName() .. "Text"]
    if label then label:SetText(control.lsLabel .. ": " .. (control:GetValue() / (control.lsDivisor or 1))) end
end
local classLocaleKeys = { WARRIOR = "CLASS_WARRIOR", PALADIN = "CLASS_PALADIN", HUNTER = "CLASS_HUNTER", ROGUE = "CLASS_ROGUE", PRIEST = "CLASS_PRIEST", SHAMAN = "CLASS_SHAMAN", MAGE = "CLASS_MAGE", WARLOCK = "CLASS_WARLOCK", DRUID = "CLASS_DRUID", DEATHKNIGHT = "CLASS_DEATHKNIGHT" }
local classFallbacks = { WARRIOR = "Воин", PALADIN = "Паладин", HUNTER = "Охотник", ROGUE = "Разбойник", PRIEST = "Жрец", SHAMAN = "Шаман", MAGE = "Маг", WARLOCK = "Чернокнижник", DRUID = "Друид", DEATHKNIGHT = "Рыцарь смерти" }

local function applyPreferencesLanguage()
    setPageLanguage(preferences, "PREFERENCES_TITLE", "Внешний вид", "PREFERENCES_NOTE", "Настройка внешнего вида интерфейса DamageLife.")
    fontLabel:SetText(T("FONT_LABEL", "Шрифт интерфейса"))
    fontHint:SetText(T("FONT_HINT", "Выбранный шрифт применяется ко всем окнам DamageLife и сохраняется для следующего входа в игру."))
end

local function applyClassesLanguage()
    for classKey in pairs(compactClassInfo) do
        local className = T(classLocaleKeys[classKey], classFallbacks[classKey])
        classTabs[classKey]:SetText(className)
        setPageLanguage(pages[classKey], classLocaleKeys[classKey], classFallbacks[classKey], "CLASS_NOTE", "Выберите вкладку способности. У каждой способности своя отдельная страница настроек.")
        setCheckLanguage(pages[classKey].master, "CLASS_TRACK", compactMasterLabels[classKey])
        local masterLabel = pages[classKey].master:GetName() and _G[pages[classKey].master:GetName() .. "Text"]
        if masterLabel and (DamageLifeDB.language or "ruRU") ~= "ruRU" then masterLabel:SetText(string.format(T("CLASS_TRACK", "Enable %s ability tracking"), className)) end
        setCheckLanguage(pages[classKey].emoteCheck, "ABILITY_EMOTE", "Объявлять применение в эмоции"); setCheckLanguage(pages[classKey].whisperCheck, "ABILITY_WHISPER", "Сообщать цели в личку")
        pages[classKey].groupHint:SetText(T("ABILITY_GROUP", "Боевой эффект: используйте настройки фразы и звука для тестирования интерфейса.")); pages[classKey].phraseHint:SetText(T("ABILITY_HINT", "{target} — цель, {spell} — ссылка на способность.")); pages[classKey].baseLabel:SetText(T("BASE_PHRASE", "Базовая"))
        for _, definition in ipairs(definitionsByClass[classKey]) do pages[classKey].abilityButtons[definition.key]:SetText(T("ABILITY_" .. definition.key, compactAbilityLabels[definition.key] or definition.label)) end
        if pages[classKey].selectedAbility then pages[classKey]:SelectAbility(pages[classKey].selectedAbility) end
    end
end

local function applyControlLanguage()
    setPageLanguage(controlPage, "CONTROL_TITLE", "Контроль", "CONTROL_NOTE", "Уведомления о применении эффектов контроля по вашей цели.")
    setCheckLanguage(controlEnabled, "CONTROL_ENABLE", "Включить уведомления контроля")
    controlHint:SetText(T("CONTROL_HINT", "Выберите общие настройки или эффект контроля. Каналы «Сказать» и «Группа» задаются отдельно."))
    controlButtons.GENERAL:SetText(T("CONTROL_GENERAL", "Общее"))
    setCheckLanguage(controlSayCheck, "CONTROL_SAY", "Сказать")
    setCheckLanguage(controlGroupCheck, "CONTROL_GROUP", "Группа")
    setCheckLanguage(controlInterruptCheck, "CONTROL_INTERRUPT", "Сообщать о сбитии каста")
    controlMessageLabel:SetText(T("CONTROL_MESSAGE", "Сообщение"))
    for _, definition in ipairs((DamageLifeControlAlerts and DamageLifeControlAlerts:GetDefinitions()) or {}) do
        local label = DamageLifeControlAlerts:GetLabel(definition)
        if controlButtons[definition.key] then controlButtons[definition.key]:SetText(label) end
    end
    for _, definition in ipairs((DamageLifeControlAlerts and DamageLifeControlAlerts:GetInterruptDefinitions()) or {}) do
        local c = interruptChecks[definition.key]
        if c and c:GetName() and _G[c:GetName() .. "Text"] then _G[c:GetName() .. "Text"]:SetText(DamageLifeControlAlerts:GetLabel(definition)) end
    end
    interruptTitle:SetText(T("CONTROL_INTERRUPTS", "Какие прерывания учитывать"))
    controlPreview:SetText(T("CONTROL_PREVIEW", "Проверить"))
    if selectedPage == "CONTROL" then selectControl(selectedControl) end
end

applyLanguage = function()
    local nav = {
        OVERVIEW = { "NAV_GENERAL", "Общие" }, EVENTS = { "NAV_EVENTS", "Боевые события" }, CLASSES = { "NAV_CLASSES", "Классы" },
        VOICE = { "NAV_VOICE", "Озвучка" }, PROFILES = { "NAV_PROFILES", "Профили" }, ABOUT = { "NAV_ABOUT", "О проекте" },
    }
    nav.CONTROL = { "NAV_CONTROL", "Контроль" }
    for key, values in pairs(nav) do if menuButtons[key] then menuButtons[key]:SetText(T(values[1], values[2])) end end

    applyPreferencesLanguage()

    setPageLanguage(profilesPage, "PROFILES_TITLE", "Профили", "PROFILES_NOTE", "Экспортируйте настройки в текст или импортируйте их на другом персонаже.")
    exportProfile:SetText(T("PROFILES_EXPORT", "Экспорт")); importProfile:SetText(T("PROFILES_IMPORT", "Импорт")); selectProfile:SetText(T("PROFILES_SELECT", "Выделить всё"))

    setPageLanguage(general, "GENERAL_TITLE", "Основные параметры", "GENERAL_NOTE", "Главные параметры DamageLife, места подсчёта и быстрые действия.")
    setPageLanguage(targetWindowsPage, "TARGET_WINDOWS_TITLE", "Окна целей", "TARGET_WINDOWS_NOTE", "Настройка количества, расположения и режима предпросмотра окон анализа целей.")
    setCheckLanguage(targetWindowsEnabled, "TARGET_WINDOWS_ENABLE", "Показывать окна целей")
    setSliderLanguage(targetWindowsCount, "TARGET_WINDOWS_COUNT", "Количество окон целей")
    targetWindowsShow:SetText(DamageLifeTargetWindowManager and DamageLifeTargetWindowManager:IsPreview() and T("TARGET_WINDOWS_HIDE", "Скрыть") or T("TARGET_WINDOWS_SHOW", "Показать"))
    targetWindowsReset:SetText(T("TARGET_WINDOWS_RESET", "Сбросить положения"))
    targetWindowsHint:SetText(T("TARGET_WINDOWS_HINT", "Нажмите «Показать», чтобы открыть режим размещения. Окна можно перемещать мышью. Изменение количества 1–5 во время предпросмотра сразу добавляет или убирает окна."))
    -- Target Windows is embedded directly into the General page.
    setPageLanguage(eventsPage, "EVENTS_TITLE", "Боевые события", "EVENTS_NOTE", "Четыре типа ключевых DPS-событий используют единый шаблон уведомлений и отдельное визуальное оформление.")
    setCheckLanguage(generalEnabled, "GENERAL_ENABLE", "Включить DamageLife")
    generalFilterTitle:SetText(T("GENERAL_WHERE", "Где считать боевые события"))
    local filterLanguages = { allowWorld = {"WORLD", "Открытый мир"}, allowBattlegrounds = {"BATTLEGROUNDS", "Поля боя"}, allowArenas = {"ARENAS", "Арены"}, allowDungeons = {"DUNGEONS", "Подземелья"}, allowRaids = {"RAIDS", "Рейды"} }
    for key, values in pairs(filterLanguages) do setCheckLanguage(generalFilterChecks[key], values[1], values[2]) end
    setSliderLanguage(low, "LOW_THRESHOLD", "Порог начала боевого события"); setSliderLanguage(safe, "SAFE_THRESHOLD", "Безопасный порог"); setSliderLanguage(windowTime, "RESCUE_WINDOW", "Окно события, сек.")
    test:SetText(T("TEST_ANNOUNCE", "Проверить анонс")); reset:SetText(T("RESET_STATS", "Сбросить статистику"))

    setPageLanguage(series, "SERIES_TITLE", "Серии", "SERIES_NOTE", "Время серии и названия пятнадцати ступеней.")
    setSliderLanguage(streakWindow, "STREAK_WINDOW", "Время серии, сек."); streakResetInfo:SetText(T("SERIES_RESET", "Серия автоматически сбрасывается после смерти и выхода из боя или поля боя."))
    setPageLanguage(announce, "ANNOUNCE_TITLE", "Анонсы и эмоции", "ANNOUNCE_NOTE", "Используйте {target} как имя цели. Галочка слева включает фразу, кнопка справа показывает пример.")
    setCheckLanguage(emoteOn, "EMOTE_ENABLE", "Отправлять эмоции"); setCheckLanguage(groupOnly, "EMOTE_GROUP", "Эмоции только в группе, рейде, БГ или арене")
    setSliderLanguage(emoteCd, "EMOTE_DELAY", "Задержка эмоций"); setSliderLanguage(targetCd, "TARGET_REPEAT", "Повтор одной цели")
    for _, button in ipairs(phrasePreviews) do button:SetText(T("PREVIEW", "Пример")) end

    setPageLanguage(display, "SAVES_TITLE", "Боевые события", "SCREEN_NOTE", "Плашку боевого события можно показывать, перемещать и масштабировать.")
    setCheckLanguage(screenOn, "SCREEN_ENABLE", "Экранное уведомление"); setCheckLanguage(localChat, "LOCAL_CHAT", "Локальная запись в чат")
    widgetLock:SetText(DamageLifeDB.widgetLocked and T("UNLOCK_SHORT", "Открепить") or T("LOCK_SHORT", "Закрепить")); resetPosition:SetText(T("RESET_POSITION", "Сбросить положение"))
    setSliderLanguage(scale, "WIDGET_SCALE", "Масштаб"); previewWidget:SetText(T("SHOW_SHORT", "Показать"))
    syncLayoutToggle()


    setPageLanguage(about, "ABOUT_TITLE", "О проекте", "ABOUT_NOTE", "Информация о DamageLife, его идее и разработке.")
    local aboutFallback = "|cffffcc00DamageLife|r — аддон для дамагеров, который анализирует боевые ситуации, помогает оценивать личный вклад в урон, добивание, бурст и контроль и превращает ключевые боевые моменты в понятные анонсы.\n\n|cffffcc00Автор идеи и разработка|r\nVegasy\n\n|cffffcc00Тестировщики Аддона:|r\n|cffffffffPandora|r\n\n|cffffcc00Дата начала разработки|r\n5 августа 2026 года\n\n|cffffcc00Текущая версия|r\n%s\n\nПроект развивается через реальные боевые проверки. Главная цель — честно определять не просто общий объём урона, а ключевые моменты, когда действия дамагера действительно повлияли на исход боевой ситуации: бурст, добивание, контроль и давление на цель.\n\nКоманды: /dl — открыть настройки."
    aboutText:SetText(string.format(T("ABOUT_BODY", aboutFallback), DamageLife_GetCurrentVersion()))

    applyControlLanguage()

    setPageLanguage(voicePage, "VOICE_TITLE", "Озвучка способностей", "VOICE_NOTE", "Отдельные голосовые уведомления для боевых событий и важных боевых действий.")
    local voiceLanguage = {
        { "VOICE_RESCUE", "Критический удар", "VOICE_RESCUE_NOTE", "Проигрывается как голосовое уведомление боевого события." },
        { "VOICE_HOPE", "Бурст", "VOICE_HOPE_NOTE", "Голосовое уведомление для мощного боевого события." },
        { "VOICE_DIVINE", "Добивание", "VOICE_DIVINE_NOTE", "Голосовое уведомление для завершающего удара." },
        { "VOICE_DEATH", "Контроль", "VOICE_DEATH_NOTE", "Голосовое уведомление для контрольного эффекта." },
    }
    for index, values in ipairs(voiceLanguage) do
        setCheckLanguage(voiceRows[index].check, values[1], values[2])
        voiceRows[index].noteText:SetText(T(values[3], values[4])); voiceRows[index].preview:SetText(T("VOICE_PREVIEW", "Прослушать"))
    end

    applyClassesLanguage()
end

DamageLifeTheme:StyleTree(window, close)
DamageLifeTheme:ApplyFontTree(window)
window:SetScript("OnShow", function()
    showPage(selectedPage)
    local wanted = DamageLifeDB.language or "ruRU"
    for _, definition in ipairs(languageDefs) do if definition.key == wanted then selectLanguage(definition); break end end
end)
tinsert(UISpecialFrames, "DamageLifeConfigFrame")
function DamageLife_OpenConfig() if window:IsShown() then window:Hide() else window:Show() end end
