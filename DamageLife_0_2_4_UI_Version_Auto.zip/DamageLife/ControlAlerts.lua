-- ControlAlerts.lua
-- Unified replacement for the old SaySapped combat-log listener.
-- The module deliberately uses DamageLifeCombatEngine so the addon has one
-- COMBAT_LOG_EVENT_UNFILTERED router and can be extended without duplicate
-- combat-log frames.

DamageLifeControlAlerts = DamageLifeControlAlerts or {}
local Alerts = DamageLifeControlAlerts

local definitions = {
    { key="SAP", setting="controlSapEnabled", class="ROGUE", label="Sap", labelRu="Ошеломление", labels={deDE="Kopfnuss",frFR="Assommer",esES="Porrazo"}, iconSpellId=6770, defaultMessage="На мне {spell}!", spellIds={6770,2070,11297,51724} },
    { key="HAMMER_OF_JUSTICE", setting="controlHammerOfJusticeEnabled", class="PALADIN", label="Hammer of Justice", labelRu="Молот правосудия", labels={deDE="Hammer der Gerechtigkeit",frFR="Marteau de la justice",esES="Martillo de Justicia"}, iconSpellId=853, defaultMessage="На мне {spell}!", spellIds={853,5588,5589,10308} },
    { key="CYCLONE", setting="controlCycloneEnabled", class="DRUID", label="Cyclone", labelRu="Смерч", labels={deDE="Wirbelsturm",frFR="Cyclone",esES="Ciclón"}, iconSpellId=33786, defaultMessage="На мне {spell}!", spellIds={33786} },
    { key="FEAR", setting="controlFearEnabled", class="WARLOCK", label="Fear", labelRu="Страх", labels={deDE="Furcht",frFR="Peur",esES="Miedo"}, iconSpellId=5782, defaultMessage="На мне {spell}!", spellIds={5782,6213,6215} },
    { key="PSYCHIC_SCREAM", setting="controlPsychicScreamEnabled", class="PRIEST", label="Psychic Scream", labelRu="Ментальный крик", labels={deDE="Psychischer Schrei",frFR="Cri psychique",esES="Alarido psíquico"}, iconSpellId=8122, defaultMessage="На мне {spell}!", spellIds={8122,8124,10888,10890} },
    { key="COUNTERSPELL_SILENCE", setting="controlCounterspellSilenceEnabled", class="MAGE", label="Counterspell Silence", labelRu="Немота от антимагии", labels={deDE="Gegenzauber: Stille",frFR="Contresort : silence",esES="Contrahechizo: silencio"}, iconSpellId=18469, defaultMessage="На мне {spell}!", spellIds={18469} },
    { key="SILENCE", setting="controlSilenceEnabled", class="PRIEST", label="Silence", labelRu="Безмолвие", labels={deDE="Stille",frFR="Silence",esES="Silencio"}, iconSpellId=15487, defaultMessage="На мне {spell}!", spellIds={15487} },
    { key="STRANGULATE", setting="controlStrangulateEnabled", class="DEATHKNIGHT", label="Strangulate", labelRu="Удушение", labels={deDE="Strangulieren",frFR="Strangulation",esES="Estrangular"}, iconSpellId=47476, defaultMessage="На мне {spell}!", spellIds={47476} },
    { key="PSYCHIC_HORROR", setting="controlPsychicHorrorEnabled", class="PRIEST", label="Psychic Horror", labelRu="Глубинный ужас", labels={deDE="Psychischer Schrecken",frFR="Horreur psychique",esES="Horror psíquico"}, iconSpellId=64044, defaultMessage="На мне {spell}!", spellIds={64044} },
    { key="REPENTANCE", setting="controlRepentanceEnabled", class="PALADIN", label="Repentance", labelRu="Покаяние", labels={deDE="Buße",frFR="Repentir",esES="Arrepentimiento"}, iconSpellId=20066, defaultMessage="На мне {spell}!", spellIds={20066} },
    { key="SEDUCTION", setting="controlSeductionEnabled", class="WARLOCK", label="Seduction", labelRu="Соблазн", labels={deDE="Verführung",frFR="Séduction",esES="Seducción"}, iconSpellId=6358, defaultMessage="На мне {spell}!", spellIds={6358} },
    { key="SPELL_LOCK", setting="controlSpellLockEnabled", class="WARLOCK", label="Spell Lock", labelRu="Запрет чар", labels={deDE="Zaubersperre",frFR="Verrou magique",esES="Bloqueo de hechizo"}, iconSpellId=19647, defaultMessage="На мне {spell}!", spellIds={19244,19647,24259} },
    { key="POLYMORPH", setting="controlPolymorphEnabled", class="MAGE", label="Polymorph", labelRu="Превращение", labels={deDE="Verwandlung",frFR="Métamorphose",esES="Polimorfia"}, iconSpellId=118, defaultMessage="На мне {spell}!", spellIds={118,12824,12825,12826,28271,28272,61305,61721,61780} },
    { key="HEX", setting="controlHexEnabled", class="SHAMAN", label="Hex", labelRu="Сглаз", labels={deDE="Verhexen",frFR="Maléfice",esES="Maleficio"}, iconSpellId=51514, defaultMessage="На мне {spell}!", spellIds={51514} },
    { key="BLIND", setting="controlBlindEnabled", class="ROGUE", label="Blind", labelRu="Ослепление", labels={deDE="Blenden",frFR="Cécité",esES="Ceguera"}, iconSpellId=2094, defaultMessage="На мне {spell}!", spellIds={2094} },
}

local bySpellId = {}
for _, definition in ipairs(definitions) do
    for _, spellId in ipairs(definition.spellIds) do bySpellId[spellId] = definition end
end

-- Abilities that produce SPELL_INTERRUPT in the 3.3.5 combat log. They are
-- kept separate from aura controls because an interrupt has no lasting aura.
local interruptDefinitions = {
    { key="KICK", label="Kick", labelRu="Пинок", labels={deDE="Tritt",frFR="Coup de pied",esES="Patada"}, iconSpellId=1766, spellIds={1766} },
    { key="PUMMEL", label="Pummel", labelRu="Зуботычина", labels={deDE="Zuschlagen",frFR="Volée de coups",esES="Zurrar"}, iconSpellId=6552, spellIds={6552,26090} },
    { key="SHIELD_BASH", label="Shield Bash", labelRu="Удар щитом", labels={deDE="Schildhieb",frFR="Coup de bouclier",esES="Azote de escudo"}, iconSpellId=72, spellIds={72,1671,1672,29704} },
    { key="COUNTERSPELL", label="Counterspell", labelRu="Антимагия", labels={deDE="Gegenzauber",frFR="Contresort",esES="Contrahechizo"}, iconSpellId=2139, spellIds={2139} },
    { key="WIND_SHEAR", label="Wind Shear", labelRu="Пронизывающий ветер", labels={deDE="Windstoß",frFR="Cisaille de vent",esES="Corte de viento"}, iconSpellId=57994, spellIds={57994} },
    { key="MIND_FREEZE", label="Mind Freeze", labelRu="Заморозка разума", labels={deDE="Gedankenfrost",frFR="Gel de l’esprit",esES="Helada mental"}, iconSpellId=47528, spellIds={47528} },
    { key="SPELL_LOCK", label="Spell Lock", labelRu="Запрет чар", labels={deDE="Zaubersperre",frFR="Verrou magique",esES="Bloqueo de hechizo"}, iconSpellId=19647, spellIds={19244,19647} },
    { key="FERAL_CHARGE", label="Feral Charge - Bear", labelRu="Звериная атака — медведь", labels={deDE="Wilde Attacke – Bär",frFR="Charge farouche — ours",esES="Carga feral: oso"}, iconSpellId=16979, spellIds={16979} },
    { key="DEATH_GRIP", label="Death Grip", labelRu="Хватка смерти", labels={deDE="Todesgriff",frFR="Poigne de la mort",esES="Atracción letal"}, iconSpellId=49560, spellIds={49560} },
    { key="NETHER_SHOCK", label="Nether Shock", labelRu="Удар Пустоты", labels={deDE="Netherstoß",frFR="Horion du Néant",esES="Choque abisal"}, iconSpellId=53589, spellIds={53589} },
}
local interruptBySpellId = {}
for _, definition in ipairs(interruptDefinitions) do
    for _, spellId in ipairs(definition.spellIds) do interruptBySpellId[spellId] = definition end
end

function Alerts:GetDefinitions() return definitions end
function Alerts:GetInterruptDefinitions() return interruptDefinitions end
function Alerts:GetLabel(definition, language)
    if type(definition) ~= "table" then return "" end
    language = language or DamageLifeDB and DamageLifeDB.language or "ruRU"
    if language == "ruRU" then return definition.labelRu or definition.label end
    return definition.labels and definition.labels[language] or definition.label
end

local function ensureSettings()
    if not DamageLifeDB then return false end
    if type(DamageLifeDB.controlAlerts) ~= "table" then DamageLifeDB.controlAlerts = {} end
    local settings = DamageLifeDB.controlAlerts
    local migrateFlat = not settings._flatMigrated
    if migrateFlat and DamageLifeDB.controlAlertsEnabled ~= nil then
        settings.enabled = DamageLifeDB.controlAlertsEnabled ~= false
    elseif settings.enabled == nil then
        settings.enabled = DamageLifeDB.controlAlertsEnabled ~= false
    end
    if type(settings.effects) ~= "table" then settings.effects = {} end
    if type(settings.messages) ~= "table" then settings.messages = {} end
    if type(settings.channels) ~= "table" then settings.channels = {} end
    for _, definition in ipairs(definitions) do
        if migrateFlat and DamageLifeDB[definition.setting] ~= nil then
            settings.effects[definition.key] = DamageLifeDB[definition.setting] ~= false
        elseif settings.effects[definition.key] == nil then
            settings.effects[definition.key] = DamageLifeDB[definition.setting] ~= false
        end
        -- Keep the old keys as compatibility aliases for existing profiles and
        -- older versions of Settings.lua during an update without /reload.
        DamageLifeDB[definition.setting] = settings.effects[definition.key]
        if type(settings.messages[definition.key]) ~= "string" or settings.messages[definition.key] == "" or settings.messages[definition.key] == "На мне {spell}!" then
            settings.messages[definition.key] = definition.defaultMessage
        end
        if type(settings.channels[definition.key]) ~= "table" then
            settings.channels[definition.key] = { say = false, group = false }
        end
    end
    if type(settings.interrupt) ~= "table" then settings.interrupt = {} end
    if settings.interrupt.enabled == nil then settings.interrupt.enabled = true end
    if type(settings.interrupt.message) ~= "string" or settings.interrupt.message == "" then
        settings.interrupt.message = "Мне сбили {spell} с помощью {interrupt}!"
    end
    if settings.interrupt.say == nil then settings.interrupt.say = false end
    if settings.interrupt.group == nil then settings.interrupt.group = false end
    if type(settings.interrupt.effects) ~= "table" then settings.interrupt.effects = {} end
    for _, definition in ipairs(interruptDefinitions) do
        if settings.interrupt.effects[definition.key] == nil then settings.interrupt.effects[definition.key] = true end
    end
    if type(settings.dispel) ~= "table" then settings.dispel = {} end
    if settings.dispel.enabled == nil then settings.dispel.enabled = true end
    if type(settings.dispel.message) ~= "string" or settings.dispel.message == "" then
        settings.dispel.message = "{source} снял с меня {spell}!"
    end
    settings.channel = settings.channel or DamageLifeDB.controlAlertChannel or "SAY"
    settings._flatMigrated = true
    DamageLifeDB.controlAlertsEnabled = settings.enabled
    DamageLifeDB.controlAlertChannel = settings.channel
    return true
end

function Alerts:SetEnabled(enabled)
    if not ensureSettings() then return end
    DamageLifeDB.controlAlerts.enabled = enabled and true or false
    DamageLifeDB.controlAlertsEnabled = DamageLifeDB.controlAlerts.enabled
end

function Alerts:SetEffectEnabled(definition, enabled)
    if type(definition) == "string" then
        for _, candidate in ipairs(definitions) do
            if candidate.key == definition then definition = candidate; break end
        end
    end
    if type(definition) ~= "table" or not ensureSettings() then return end
    DamageLifeDB.controlAlerts.effects[definition.key] = enabled and true or false
    DamageLifeDB[definition.setting] = DamageLifeDB.controlAlerts.effects[definition.key]
end

function Alerts:IsEffectEnabled(definition)
    if type(definition) ~= "table" or not ensureSettings() then return false end
    return DamageLifeDB.controlAlerts.effects[definition.key] ~= false
end

function Alerts:GetMessage(definition)
    if type(definition) ~= "table" or not ensureSettings() then return "" end
    return DamageLifeDB.controlAlerts.messages[definition.key] or definition.defaultMessage or ""
end

function Alerts:SetMessage(definition, message)
    if type(definition) ~= "table" or not ensureSettings() then return end
    message = tostring(message or "")
    DamageLifeDB.controlAlerts.messages[definition.key] = message ~= "" and message or definition.defaultMessage
end

function Alerts:GetChannels(definition)
    if type(definition) ~= "table" or not ensureSettings() then return true, false end
    local channels = DamageLifeDB.controlAlerts.channels[definition.key]
    return channels.say ~= false, channels.group == true
end

function Alerts:SetChannelEnabled(definition, channel, enabled)
    if type(definition) ~= "table" or not ensureSettings() then return end
    local channels = DamageLifeDB.controlAlerts.channels[definition.key]
    if channel == "say" or channel == "group" then channels[channel] = enabled and true or false end
end

function Alerts:GetInterruptSettings()
    if not ensureSettings() then return nil end
    return DamageLifeDB.controlAlerts.interrupt
end

function Alerts:SetInterruptEnabled(enabled)
    if ensureSettings() then DamageLifeDB.controlAlerts.interrupt.enabled = enabled and true or false end
end

function Alerts:SetInterruptMessage(message)
    if not ensureSettings() then return end
    message = tostring(message or "")
    DamageLifeDB.controlAlerts.interrupt.message = message ~= "" and message or "Мне сбили {spell} с помощью {interrupt}!"
end

function Alerts:SetInterruptChannelEnabled(channel, enabled)
    if not ensureSettings() then return end
    if channel == "say" or channel == "group" then
        DamageLifeDB.controlAlerts.interrupt[channel] = enabled and true or false
    end
end

function Alerts:IsInterruptEnabled(definition)
    if type(definition) ~= "table" or not ensureSettings() then return false end
    return DamageLifeDB.controlAlerts.interrupt.effects[definition.key] ~= false
end

function Alerts:SetInterruptEffectEnabled(definition, enabled)
    if type(definition) ~= "table" or not ensureSettings() then return end
    DamageLifeDB.controlAlerts.interrupt.effects[definition.key] = enabled and true or false
end

function Alerts:GetDispelSettings()
    if not ensureSettings() then return nil end
    return DamageLifeDB.controlAlerts.dispel
end

function Alerts:SetDispelEnabled(enabled)
    if ensureSettings() then DamageLifeDB.controlAlerts.dispel.enabled = enabled and true or false end
end

function Alerts:IsEnabled(definition)
    return ensureSettings() and DamageLifeDB.controlAlerts.enabled ~= false
        and self:IsEffectEnabled(definition)
end

function Alerts:IsMasterEnabled()
    return ensureSettings() and DamageLifeDB.controlAlerts.enabled ~= false
end

local playerGUID
local function refreshPlayerGUID()
    playerGUID = UnitGUID and UnitGUID("player") or playerGUID
end

local function sendConfiguredMessage(message, sayEnabled, groupEnabled)
    if sayEnabled then SendChatMessage(message, "SAY") end
    if groupEnabled then
        -- PARTY deliberately means /p even while the player is in a raid: on
        -- 3.3.5 this reaches only the player's five-person raid subgroup.
        local grouped = (GetNumRaidMembers and GetNumRaidMembers() > 0)
            or (GetNumPartyMembers and GetNumPartyMembers() > 0)
        if grouped then SendChatMessage(message, "PARTY") end
    end
end

local function announce(definition, event)
    local message = Alerts:GetMessage(definition)
    local spellName = event and event.spellName or GetSpellInfo(definition.iconSpellId) or definition.label
    local targetName = event and event.destName or (UnitName and UnitName("target")) or "цель"
    local sourceName = event and event.sourceName or (UnitName and UnitName("player")) or ""
    message = string.gsub(message, "{spell}", spellName or "")
    message = string.gsub(message, "{target}", targetName or "")
    message = string.gsub(message, "{source}", sourceName or "")
    local sayEnabled, groupEnabled = Alerts:GetChannels(definition)
    sendConfiguredMessage(message, sayEnabled, groupEnabled)
    if DamageLifeAbilitySounds then DamageLifeAbilitySounds:Play(definition.key, "Control") end
end

local lastDispelKey, lastDispelTime = "", 0
local function announceFriendlyDispel(definition, event)
    local config = Alerts:GetDispelSettings()
    if not config or config.enabled == false then return end
    if not event.sourceGUID or event.sourceGUID == playerGUID then return end
    if bit and COMBATLOG_OBJECT_REACTION_FRIENDLY and bit.band(event.sourceFlags or 0, COMBATLOG_OBJECT_REACTION_FRIENDLY) == 0 then return end
    local now = GetTime and GetTime() or 0
    local key = tostring(event.sourceGUID) .. ":" .. tostring(event.extraSpellId or definition.key)
    if key == lastDispelKey and now - lastDispelTime < 0.5 then return end
    lastDispelKey, lastDispelTime = key, now
    local message = config.message or "{source} снял с меня {spell}!"
    message = string.gsub(message, "{source}", event.sourceName or "Союзник")
    message = string.gsub(message, "{spell}", event.extraSpellName or Alerts:GetLabel(definition))
    SendChatMessage(message, "SAY")
end

local lastInterruptKey, lastInterruptTime = "", 0
local function announceInterrupt(event)
    local settings = Alerts:GetInterruptSettings()
    if not settings or settings.enabled == false then return end
    local definition = interruptBySpellId[event.spellId]
    if definition and settings.effects[definition.key] == false then return end
    local now = GetTime and GetTime() or 0
    local key = tostring(event.extraSpellId or event.extraSpellName or "") .. ":" .. tostring(event.sourceGUID or "")
    if key == lastInterruptKey and now - lastInterruptTime < 0.3 then return end
    lastInterruptKey, lastInterruptTime = key, now
    local message = settings.message or "Мне сбили {spell} с помощью {interrupt}!"
    message = string.gsub(message, "{spell}", event.extraSpellName or "")
    message = string.gsub(message, "{interrupt}", event.spellName or "")
    message = string.gsub(message, "{source}", event.sourceName or "")
    sendConfiguredMessage(message, settings.say ~= false, settings.group == true)
end


function Alerts:Preview(definition)
    if not ensureSettings() then return end
    local message, sayEnabled, groupEnabled
    if definition then
        message = self:GetMessage(definition)
        local spellName = GetSpellInfo(definition.iconSpellId) or self:GetLabel(definition)
        message = string.gsub(message, "{spell}", spellName or "")
        message = string.gsub(message, "{target}", UnitName("target") or "Цель")
        message = string.gsub(message, "{source}", UnitName("player") or "Игрок")
        sayEnabled, groupEnabled = self:GetChannels(definition)
    else
        local settings = self:GetInterruptSettings()
        message = settings.message or "Мне сбили {spell} с помощью {interrupt}!"
        message = string.gsub(message, "{spell}", GetSpellInfo(48063) or "Великое исцеление")
        message = string.gsub(message, "{interrupt}", GetSpellInfo(1766) or "Пинок")
        message = string.gsub(message, "{source}", UnitName("player") or "Игрок")
        sayEnabled, groupEnabled = settings.say ~= false, settings.group == true
    end
    sendConfiguredMessage(message, sayEnabled, groupEnabled)
end

local activeControls = {}
local function onCombatEvent(event)
    if not event or not playerGUID then refreshPlayerGUID() end
    if not event or not playerGUID then return end
    if event.type == "SPELL_DISPEL" then
        if event.destGUID == playerGUID and event.sourceGUID ~= playerGUID then
            local removed = bySpellId[event.extraSpellId]
            if removed and Alerts:IsMasterEnabled() then announceFriendlyDispel(removed, event) end
        end
        return
    end
    if event.sourceGUID ~= playerGUID or event.destGUID == playerGUID then return end
    if event.type == "SPELL_INTERRUPT" then
        if Alerts:IsMasterEnabled() then announceInterrupt(event) end
        return
    end
    local definition = bySpellId[event.spellId]
    if not definition then return end
    if event.type == "SPELL_AURA_REMOVED" or event.type == "SPELL_AURA_BROKEN" or event.type == "SPELL_AURA_BROKEN_SPELL" then
        activeControls[definition.key] = nil
        return
    end
    if event.type ~= "SPELL_AURA_APPLIED" and event.type ~= "SPELL_AURA_REFRESH" then return end
    local now = GetTime and GetTime() or 0
    if activeControls[definition.key] and now - activeControls[definition.key] < 120 then return end
    activeControls[definition.key] = now
    if Alerts:IsEnabled(definition) then announce(definition, event) end
end

if DamageLifeCombatEngine then
    DamageLifeCombatEngine:RegisterSubscriber("ControlAlerts", onCombatEvent, 30)
end

local eventFrame = CreateFrame("Frame")
eventFrame:RegisterEvent("ADDON_LOADED")
eventFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
eventFrame:RegisterEvent("PLAYER_LOGIN")
eventFrame:SetScript("OnEvent", function(self, event, addon)
    if event == "ADDON_LOADED" and addon ~= "DamageLife" then return end
    if event == "PLAYER_ENTERING_WORLD" then
        for key in pairs(activeControls) do activeControls[key] = nil end
    end
    ensureSettings(); refreshPlayerGUID()
end)

ensureSettings()
