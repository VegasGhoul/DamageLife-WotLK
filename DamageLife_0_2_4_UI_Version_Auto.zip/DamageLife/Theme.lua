DamageLifeTheme = DamageLifeTheme or {}
local Theme = DamageLifeTheme

Theme.colors = {
    gold = { 1.00, 0.82, 0.00, 1.00 },
    goldSoft = { 0.80, 0.65, 0.00, 1.00 },
    combat = { 0.76, 0.10, 0.14, 1.00 },
    combatSoft = { 0.76, 0.10, 0.14, 0.28 },
    background = { 0.008, 0.012, 0.020, 0.94 },
    panel = { 0.015, 0.022, 0.032, 0.86 },
    panelSoft = { 0.025, 0.035, 0.050, 0.72 },
    border = { 0.22, 0.25, 0.29, 0.90 },
    text = { 0.94, 0.94, 0.94, 1.00 },
    muted = { 0.62, 0.64, 0.67, 1.00 },
    disabled = { 0.35, 0.36, 0.38, 1.00 },
}

local WHITE = "Interface\\Buttons\\WHITE8X8"
local BORDER = "Interface\\Tooltips\\UI-Tooltip-Border"
local TEXTURES = "Interface\\AddOns\\DamageLife\\Textures\\"
local PANEL_TEXTURE = TEXTURES .. "PanelStone.tga"
local FRAME_TEXTURE = TEXTURES .. "FrameBorder.tga"
local BUTTON_NORMAL = TEXTURES .. "ButtonNormal.tga"
local BUTTON_HOVER = TEXTURES .. "ButtonHover.tga"
local BUTTON_PRESSED = TEXTURES .. "ButtonPressed.tga"
local BUTTON_DISABLED = TEXTURES .. "ButtonDisabled.tga"
local BUTTON_SELECTED = TEXTURES .. "ButtonSelected.tga"
local CHECK_ON = TEXTURES .. "Checkbox_on.tga"
local CHECK_OFF = TEXTURES .. "Checkbox_off.tga"
local CHECK_DISABLED = TEXTURES .. "Checkbox_disabled.tga"
Theme.fontDefinitions = {
    STANDARD = { label = "Standard", path = "Fonts\\FRIZQT__.TTF", bonus = 0 },
    FRITZ = { label = "Fritz Quadrata Cyri", path = "Interface\\AddOns\\DamageLife\\Fonts\\FritzQuadrataCyri-Regular.ttf", bonus = 2 },
    MONTSERRAT = { label = "Montserrat", path = "Interface\\AddOns\\DamageLife\\Fonts\\Montserrat-Regular.ttf", bonus = 1 },
    BEBAS = { label = "Bebas Neue Regular", path = "Interface\\AddOns\\DamageLife\\Fonts\\BebasNeue-Regular.ttf", bonus = 2 },
    -- Akzidenz-Grotesk Pro is proprietary. Until a licensed file is supplied,
    -- the option deliberately falls back to the standard client font.
    AKZIDENZ = { label = "Akzidenz-Grotesk Pro", path = "Fonts\\FRIZQT__.TTF", bonus = 0, needsFile = true },
    MORPHEUS = { label = "Morpheus", path = "Fonts\\MORPHEUS.TTF", bonus = 1, cyrillicFallback = "Fonts\\FRIZQT__.TTF" },
}

Theme.fontKey = "FRITZ"
Theme.font = Theme.fontDefinitions.FRITZ.path
Theme.fontSizeBonus = Theme.fontDefinitions.FRITZ.bonus

function Theme:ApplyFont(fontString)
    if not fontString or not fontString.GetFont or not fontString.SetFont then return end
    if fontString.lsKeepFont then return end
    local currentFont, size, flags = fontString:GetFont()
    if not size then return end
    if not fontString.lsBaseFontSize then
        fontString.lsBaseFontSize = size
    end
    fontString:SetFont(self.font, fontString.lsBaseFontSize + self.fontSizeBonus, flags or "")
end

function Theme:ApplyFontTree(frame)
    if not frame then return end
    local regions = { frame:GetRegions() }
    for _, region in ipairs(regions) do
        if region:GetObjectType() == "FontString" then self:ApplyFont(region) end
    end
    local objectType = frame:GetObjectType()
    if (objectType == "EditBox" or objectType == "ScrollingMessageFrame") and frame.GetFont then self:ApplyFont(frame) end
    local children = { frame:GetChildren() }
    for _, child in ipairs(children) do self:ApplyFontTree(child) end
end

local function themedFont(name, source)
    local font = _G[name] or CreateFont(name)
    local _, size, flags = source:GetFont()
    font.lsBaseFontSize, font.lsFontFlags = size, flags or ""
    font:SetFont(Theme.font, size + Theme.fontSizeBonus, flags or "")
    local r, g, b, a = source:GetTextColor()
    font:SetTextColor(r, g, b, a)
    if source.GetShadowColor and font.SetShadowColor then
        local sr, sg, sb, sa = source:GetShadowColor()
        font:SetShadowColor(sr, sg, sb, sa)
    end
    if source.GetShadowOffset and font.SetShadowOffset then
        local x, y = source:GetShadowOffset()
        font:SetShadowOffset(x, y)
    end
    return font
end

Theme.fontObjects = {
    normalSmall = themedFont("DamageLifeFontNormalSmall", GameFontHighlightSmall),
    highlightSmall = themedFont("DamageLifeFontHighlightSmall", GameFontNormalSmall),
    disabledSmall = themedFont("DamageLifeFontDisabledSmall", GameFontDisableSmall),
    navigation = themedFont("DamageLifeFontNavigation", GameFontHighlight),
    navigationHover = themedFont("DamageLifeFontNavigationHover", GameFontNormal),
}

function Theme:GetFontDefinition(key)
    return self.fontDefinitions[key] or self.fontDefinitions.FRITZ
end

function Theme:SetFont(key)
    local definition = self:GetFontDefinition(key)
    self.fontKey = self.fontDefinitions[key] and key or "FRITZ"
    self.font = definition.path
    if definition.cyrillicFallback and DamageLifeDB and (DamageLifeDB.language or "ruRU") == "ruRU" then
        self.font = definition.cyrillicFallback
    end
    self.fontSizeBonus = definition.bonus or 0

    for _, fontObject in pairs(self.fontObjects or {}) do
        local _, currentSize, currentFlags = fontObject:GetFont()
        local baseSize = fontObject.lsBaseFontSize or currentSize or 12
        fontObject:SetFont(self.font, baseSize + self.fontSizeBonus, fontObject.lsFontFlags or currentFlags or "")
    end

    self:ApplyFontTree(_G.DamageLifeConfigFrame)
    self:ApplyFontTree(_G.DamageLifeSaveWidget)
end

local function color(texture, value)
    if not texture or not value then return end
    texture:SetVertexColor(value[1] or 1, value[2] or 1, value[3] or 1, value[4] or 1)
end

function Theme:SetBackdrop(frame, background, border)
    frame:SetBackdrop({
        bgFile = PANEL_TEXTURE,
        edgeFile = FRAME_TEXTURE,
        tile = true,
        tileSize = 16,
        edgeSize = 12,
        insets = { left = 3, right = 3, top = 3, bottom = 3 },
    })
    background = background or self.colors.panel
    border = border or self.colors.border
    frame:SetBackdropColor(background[1], background[2], background[3], background[4])
    frame:SetBackdropBorderColor(border[1], border[2], border[3], border[4])
end

function Theme:CreateGradientLine(parent, anchor, offset, width, height)
    local left = parent:CreateTexture(nil, "OVERLAY")
    local right = parent:CreateTexture(nil, "OVERLAY")
    left:SetTexture(WHITE); right:SetTexture(WHITE)
    width = width or math.max(20, parent:GetWidth() - 24)
    height = height or 2

    if anchor == "BOTTOM" then
        left:SetPoint("RIGHT", parent, "BOTTOM", 0, offset or 0)
        right:SetPoint("LEFT", parent, "BOTTOM", 0, offset or 0)
    else
        left:SetPoint("RIGHT", parent, "TOP", 0, offset or 0)
        right:SetPoint("LEFT", parent, "TOP", 0, offset or 0)
    end
    left:SetSize(width / 2, height); right:SetSize(width / 2, height)
    left:SetGradientAlpha("HORIZONTAL", 1, 0.82, 0, 0, 1, 0.82, 0, 1)
    right:SetGradientAlpha("HORIZONTAL", 1, 0.82, 0, 1, 1, 0.82, 0, 0)
    return left, right
end

function Theme:StyleWindow(frame)
    frame:SetBackdrop(nil)

    -- The WoW 3.3.5 client composites addon textures over the game world.
    -- Keep the stone texture visible, but add a dense dark underlay so the
    -- DamageLife window remains readable even over bright terrain/effects.
    local underlay = frame:CreateTexture(nil, "BACKGROUND")
    underlay:SetTexture(WHITE)
    underlay:SetAllPoints(frame)
    underlay:SetVertexColor(0.008, 0.010, 0.014, 0.94)

    local background = frame:CreateTexture(nil, "BORDER")
    background:SetTexture(PANEL_TEXTURE)
    background:SetAllPoints(frame)
    background:SetVertexColor(0.95, 0.95, 0.95, 0.30)

    local topLeft, topRight = self:CreateGradientLine(frame, "TOP", 0, frame:GetWidth(), 2)
    local bottomLeft, bottomRight = self:CreateGradientLine(frame, "BOTTOM", 0, frame:GetWidth(), 2)
    frame.lsWindowTextures = { underlay, background, topLeft, topRight, bottomLeft, bottomRight }
end

function Theme:StylePanel(frame, strong)
    self:SetBackdrop(frame, strong and self.colors.panel or self.colors.panelSoft, self.colors.border)
end

local function setButtonTextColor(button, value)
    local text = button:GetFontString()
    if text then text:SetTextColor(value[1], value[2], value[3], value[4] or 1) end
end

function Theme:StyleButton(button)
    if button.lsThemeStyled then return end
    button.lsThemeStyled = true

    button:SetNormalTexture(BUTTON_NORMAL)
    button:SetPushedTexture(BUTTON_PRESSED)
    button:SetHighlightTexture(BUTTON_HOVER)
    button:SetDisabledTexture(BUTTON_DISABLED)
    color(button:GetNormalTexture(), { 1, 1, 1, 0.98 })
    color(button:GetPushedTexture(), { 1, 1, 1, 1.00 })
    color(button:GetHighlightTexture(), { 1, 1, 1, 1.00 })
    color(button:GetDisabledTexture(), { 1, 1, 1, 0.78 })
    self:SetBackdrop(button, { 0, 0, 0, 0 }, self.colors.border)

    button:SetNormalFontObject(self.fontObjects.normalSmall)
    button:SetHighlightFontObject(self.fontObjects.highlightSmall)
    button:SetDisabledFontObject(self.fontObjects.disabledSmall)
    self:ApplyFont(button:GetFontString())
    setButtonTextColor(button, self.colors.text)

    button:HookScript("OnEnter", function(self)
        if self:IsEnabled() then
            self:SetBackdropBorderColor(1, 0.82, 0, 0.95)
            setButtonTextColor(self, Theme.colors.gold)
        end
    end)
    button:HookScript("OnLeave", function(self)
        if not self.lsSelected then
            local c = self:IsEnabled() and Theme.colors.border or Theme.colors.disabled
            self:SetBackdropBorderColor(c[1], c[2], c[3], c[4] or 1)
            setButtonTextColor(self, self:IsEnabled() and Theme.colors.text or Theme.colors.disabled)
        end
    end)
end

function Theme:StyleNavButton(button)
    button.lsNavButton = true
    button.lsThemeStyled = true
    button:SetBackdrop(nil)
    button:SetNormalTexture(BUTTON_NORMAL); button:SetPushedTexture(BUTTON_PRESSED); button:SetDisabledTexture(BUTTON_DISABLED)
    local highlight = button:CreateTexture(nil, "HIGHLIGHT")
    highlight:SetTexture(BUTTON_HOVER)
    highlight:SetAllPoints(button)
    highlight:SetVertexColor(1, 0.58, 0.08, 0.38)
    button:SetHighlightTexture(highlight)
    button:SetNormalFontObject(self.fontObjects.navigation); button:SetHighlightFontObject(self.fontObjects.navigationHover)
    self:ApplyFont(button:GetFontString())
    setButtonTextColor(button, self.colors.text)
    local selected = button:CreateTexture(nil, "BACKGROUND")
    selected:SetTexture(BUTTON_SELECTED)
    selected:SetAllPoints(button); selected:SetVertexColor(1, 1, 1, 1); selected:Hide()
    button.lsSelectedTexture = selected
end

function Theme:SetNavSelected(button, selected)
    button.lsSelected = selected and true or false
    if selected then
        button.lsSelectedTexture:Show()
        setButtonTextColor(button, self.colors.gold)
    else
        button.lsSelectedTexture:Hide()
        setButtonTextColor(button, self.colors.text)
    end
end

function Theme:StyleCheckButton(checkButton)
    if checkButton.lsThemeStyled then return end
    checkButton.lsThemeStyled = true
    local name = checkButton:GetName() or ""
    local text = _G[name .. "Text"] or checkButton.label

    if string.find(name, "LSBuiltinSound", 1, true) then
        if text then text:SetTextColor(self.colors.text[1], self.colors.text[2], self.colors.text[3]) end
        return
    end

    checkButton:SetNormalTexture(CHECK_OFF)
    checkButton:SetPushedTexture(CHECK_ON)
    checkButton:SetHighlightTexture(CHECK_ON, "ADD")
    checkButton:SetCheckedTexture(CHECK_ON)
    checkButton:SetDisabledCheckedTexture(CHECK_DISABLED)
    local normal = checkButton:GetNormalTexture()
    local checked = checkButton:GetCheckedTexture()
    local highlight = checkButton:GetHighlightTexture()
    if normal then normal:SetVertexColor(1, 1, 1, 1) end
    if checked then checked:SetVertexColor(1, 1, 1, 1) end
    if highlight then highlight:SetVertexColor(1, 1, 1, 0.90) end
    if text then text:SetTextColor(self.colors.text[1], self.colors.text[2], self.colors.text[3]) end
end

function Theme:StyleSlider(slider)
    if slider.lsThemeStyled then return end
    slider.lsThemeStyled = true

    local regions = { slider:GetRegions() }
    for _, region in ipairs(regions) do
        if region:GetObjectType() == "Texture" then region:SetTexture(nil) end
    end

    local track = slider:CreateTexture(nil, "BACKGROUND")
    track:SetTexture(WHITE); track:SetPoint("LEFT", slider, "LEFT", 5, 0); track:SetPoint("RIGHT", slider, "RIGHT", -5, 0); track:SetHeight(4)
    track:SetVertexColor(0.10, 0.12, 0.15, 1)
    local trackGlow = slider:CreateTexture(nil, "BORDER")
    trackGlow:SetTexture(WHITE); trackGlow:SetPoint("LEFT", track, "LEFT", 0, 0); trackGlow:SetPoint("RIGHT", track, "RIGHT", 0, 0); trackGlow:SetHeight(1)
    trackGlow:SetVertexColor(1, 0.82, 0, 0.45)

    slider:SetThumbTexture(WHITE)
    local thumb = slider:GetThumbTexture()
    if thumb then
        thumb:SetSize(9, 19); thumb:SetVertexColor(1, 0.82, 0, 1)
    end

    local name = slider:GetName()
    if name then
        local title = _G[name .. "Text"]
        local low = _G[name .. "Low"]
        local high = _G[name .. "High"]
        if title then title:SetTextColor(self.colors.text[1], self.colors.text[2], self.colors.text[3]) end
        if low then low:SetTextColor(self.colors.muted[1], self.colors.muted[2], self.colors.muted[3]) end
        if high then high:SetTextColor(self.colors.muted[1], self.colors.muted[2], self.colors.muted[3]) end
    end
end

function Theme:StyleEditBox(editBox)
    if editBox.lsThemeStyled then return end
    editBox.lsThemeStyled = true
    self:SetBackdrop(editBox, { 0.01, 0.015, 0.025, 0.96 }, self.colors.border)
    editBox:SetTextColor(self.colors.text[1], self.colors.text[2], self.colors.text[3])
    editBox:HookScript("OnEditFocusGained", function(self) self:SetBackdropBorderColor(1, 0.82, 0, 1) end)
    editBox:HookScript("OnEditFocusLost", function(self) self:SetBackdropBorderColor(0.22, 0.25, 0.29, 0.9) end)
end

function Theme:StyleTree(frame, excluded)
    local children = { frame:GetChildren() }
    for _, child in ipairs(children) do
        local objectType = child:GetObjectType()
        if child ~= excluded then
            if objectType == "Button" and not child.lsNavButton then
                self:StyleButton(child)
            elseif objectType == "CheckButton" then
                self:StyleCheckButton(child)
            elseif objectType == "Slider" then
                self:StyleSlider(child)
            elseif objectType == "EditBox" then
                self:StyleEditBox(child)
            end
        end
        self:StyleTree(child, excluded)
    end
end

Theme:ApplyFontTree(_G.DamageLifeSaveWidget)
