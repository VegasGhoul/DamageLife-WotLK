local menuButton
local minimapButton
local retryElapsed = 0
local retryUntil = 0

local function createMinimapButton()
    if minimapButton or not Minimap then return minimapButton end

    minimapButton = CreateFrame("Button", "DamageLifeMinimapButton", Minimap)
    minimapButton:SetSize(32, 32)
    minimapButton:SetFrameStrata("MEDIUM")
    minimapButton:SetFrameLevel((Minimap:GetFrameLevel() or 1) + 8)
    minimapButton:SetPoint("TOPLEFT", Minimap, "TOPLEFT", -4, -4)
    minimapButton:RegisterForClicks("LeftButtonUp")

    minimapButton.outerGlow = minimapButton:CreateTexture(nil, "BACKGROUND")
    minimapButton.outerGlow:SetTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")
    minimapButton.outerGlow:SetBlendMode("ADD")
    minimapButton.outerGlow:SetSize(34, 34)
    minimapButton.outerGlow:SetPoint("CENTER")
    minimapButton.outerGlow:SetVertexColor(0.78, 0.56, 0.14, 0.16)

    minimapButton.backing = minimapButton:CreateTexture(nil, "BORDER")
    minimapButton.backing:SetTexture("Interface\\Minimap\\UI-Minimap-Background")
    minimapButton.backing:SetSize(31, 31)
    minimapButton.backing:SetPoint("CENTER")
    minimapButton.backing:SetVertexColor(0.025, 0.035, 0.045, 0.96)

    minimapButton.innerGradient = minimapButton:CreateTexture(nil, "BORDER")
    minimapButton.innerGradient:SetTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")
    minimapButton.innerGradient:SetBlendMode("ADD")
    minimapButton.innerGradient:SetSize(29, 29)
    minimapButton.innerGradient:SetPoint("CENTER")
    minimapButton.innerGradient:SetVertexColor(0.32, 0.22, 0.06, 0.12)

    minimapButton.goldRing = minimapButton:CreateTexture(nil, "ARTWORK")
    minimapButton.goldRing:SetTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")
    minimapButton.goldRing:SetBlendMode("ADD")
    minimapButton.goldRing:SetSize(32, 32)
    minimapButton.goldRing:SetPoint("CENTER")
    minimapButton.goldRing:SetVertexColor(0.88, 0.67, 0.22, 0.30)

    minimapButton.icon = minimapButton:CreateTexture(nil, "ARTWORK")
    minimapButton.icon:SetTexture("Interface\\AddOns\\DamageLife\\Textures\\DamageLifeLogo.tga")
    minimapButton.icon:SetSize(28, 28)
    minimapButton.icon:SetPoint("CENTER")
    minimapButton.icon:SetTexCoord(0.04, 0.96, 0.04, 0.96)

    minimapButton.highlight = minimapButton:CreateTexture(nil, "HIGHLIGHT")
    minimapButton.highlight:SetTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")
    minimapButton.highlight:SetBlendMode("ADD")
    minimapButton.highlight:SetAllPoints(minimapButton)

    minimapButton:SetScript("OnClick", function()
        if DamageLife_OpenConfig then DamageLife_OpenConfig() end
    end)
    minimapButton:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_LEFT")
        GameTooltip:SetText("|cffffd34eDamageLife|r")
        GameTooltip:AddLine("Открыть настройки аддона", 1, 1, 1)
        GameTooltip:Show()
    end)
    minimapButton:SetScript("OnLeave", function() GameTooltip:Hide() end)
    minimapButton:Show()
    return minimapButton
end

local function findAnchor()
    return _G.DragonUIReloadGameMenuButton
        or _G.DragonUIWeakAurasGameMenuButton
        or _G.DragonUIGameMenuButton
        or _G.GameMenuButtonContinue
end

local function positionButton()
    local anchor = findAnchor()
    if not anchor or not anchor.GetParent then return false end

    local parent = anchor:GetParent()
    if not parent then return false end

    if not menuButton then
        menuButton = CreateFrame("Button", "DamageLifeGameMenuButton", parent, "GameMenuButtonTemplate")
        menuButton:SetText("DamageLife")
        if DamageLifeTheme then DamageLifeTheme:StyleButton(menuButton) end
        menuButton:SetScript("OnClick", function()
            if GameMenuFrame and GameMenuFrame:IsShown() then
                HideUIPanel(GameMenuFrame)
            end
            if DamageLife_OpenConfig then DamageLife_OpenConfig() end
        end)
    end

    menuButton:SetParent(parent)
    menuButton:SetFrameStrata(parent:GetFrameStrata())
    menuButton:SetFrameLevel((parent:GetFrameLevel() or 1) + 25)
    menuButton:SetWidth(anchor:GetWidth() > 0 and anchor:GetWidth() or 144)
    menuButton:ClearAllPoints()
    menuButton:SetPoint("TOP", anchor, "BOTTOM", 0, -2)
    menuButton:Show()

    if not parent._damageLifeHeightAdjusted then
        parent:SetHeight(parent:GetHeight() + (menuButton:GetHeight() or 20) + 2)
        parent._damageLifeHeightAdjusted = true
    end
    return true
end

local watcher = CreateFrame("Frame")
local function retryUpdate(self, elapsed)
    if GetTime() > retryUntil then self:SetScript("OnUpdate", nil); return end
    retryElapsed = retryElapsed + elapsed
    if retryElapsed >= 0.10 then
        retryElapsed = 0
        positionButton()
    end
end
watcher:SetScript("OnUpdate", retryUpdate)

local function menuShown()
    retryUntil = GetTime() + 1
    retryElapsed = 0
    watcher:SetScript("OnUpdate", retryUpdate)
    positionButton()
end

local loader = CreateFrame("Frame")
loader:RegisterEvent("PLAYER_LOGIN")
loader:SetScript("OnEvent", function()
    createMinimapButton()
    if GameMenuFrame then
        GameMenuFrame:HookScript("OnShow", menuShown)
    end
    positionButton()
end)
